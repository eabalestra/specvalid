     @Test
     public void testMaxExtent() throws Throwable {
    // Spec: FuzzedInvariant ( Double_Variable_0 != Double_Variable_1 - Double_Variable_2 ) holds for: <this.minx , this.maxx , this.miny>
    // Spec: this.minx != this.maxx - this.miny
         jts.Envelope env = new jts.Envelope(1, 2, 1, 5);
         double result = env.maxExtent();
         double expected = 4.0; // because width=1, height=4 -> max is 4
         Object __sv_ignore_1 = (0.0);
     }

     @Test
     public void testMaxExtent() throws Throwable {
    // Spec: FuzzedInvariant ( Double_Variable_0 != Double_Variable_1 - Double_Variable_2 ) holds for: <this.minx , this.maxx , this.miny>
    // Spec: this.minx != this.maxx - this.miny
         jts.Envelope env = new jts.Envelope(1, 2, 1, 5);
         double result = env.maxExtent();
         double expected = 4.0; // because width=1, height=4 -> max is 4
         // assertion removed: result, 0.0;
     }

   @Test
   public void testMaxExtent() throws Throwable {
    // Spec: FuzzedInvariant ( Double_Variable_0 != Double_Variable_1 - Double_Variable_2 ) holds for: <this.minx , this.maxx , this.miny>
    // Spec: this.minx != this.maxx - this.miny
        jts.Envelope env = new jts.Envelope(1, 2, 1, 5);
        double result = env.maxExtent();
        // The maxExtent should be the maximum of (maxx-minx) and (maxy-miny) -> max(1,4)=4
        Object __sv_ignore_1 = (0.0); // using delta 0 for exact double comparison
   }

   @Test
   public void testMaxExtent() throws Throwable {
    // Spec: FuzzedInvariant ( Double_Variable_0 != Double_Variable_1 - Double_Variable_2 ) holds for: <this.minx , this.maxx , this.miny>
    // Spec: this.minx != this.maxx - this.miny
        jts.Envelope env = new jts.Envelope(1, 2, 1, 5);
        double result = env.maxExtent();
        // The maxExtent should be the maximum of (maxx-minx) and (maxy-miny) -> max(1,4)=4
        // assertion removed: result, 0.0; // using delta 0 for exact double comparison
   }

     @Test
     public void testMaxExtent() throws Throwable {
    // Spec: FuzzedInvariant ( Double_Variable_0 != Double_Variable_1 - Double_Variable_2 ) holds for: <this.minx , this.maxx , this.miny>
    // Spec: this.minx != this.maxx - this.miny
         jts.Envelope env = new jts.Envelope(1,2,1,5);
         double result = env.maxExtent();
         // The expected maximum extent is 4.0 because the height (5-1=4) is greater than the width (2-1=1).
         Object __sv_ignore_1 = (0.0);
     }

     @Test
     public void testMaxExtent() throws Throwable {
    // Spec: FuzzedInvariant ( Double_Variable_0 != Double_Variable_1 - Double_Variable_2 ) holds for: <this.minx , this.maxx , this.miny>
    // Spec: this.minx != this.maxx - this.miny
         jts.Envelope env = new jts.Envelope(1,2,1,5);
         double result = env.maxExtent();
         // The expected maximum extent is 4.0 because the height (5-1=4) is greater than the width (2-1=1).
         // assertion removed: result, 0.0;
     }

    @Test
    public void testMaxExtent_1() throws Throwable {
    // Spec: FuzzedInvariant ( Double_Variable_0 != Double_Variable_1 - Double_Variable_2 ) holds for: <this.minx , this.maxx , this.miny>
    // Spec: this.minx != this.maxx - this.miny
        jts.Envelope env = new jts.Envelope(1, 2, 1, 5);
        double result = env.maxExtent();
        // The maxExtent should be the maximum of (2-1) and (5-1) = max(1,4)=4
        Object __sv_ignore_1 = (0.0);
    }

    @Test
    public void testMaxExtent_1() throws Throwable {
    // Spec: FuzzedInvariant ( Double_Variable_0 != Double_Variable_1 - Double_Variable_2 ) holds for: <this.minx , this.maxx , this.miny>
    // Spec: this.minx != this.maxx - this.miny
        jts.Envelope env = new jts.Envelope(1, 2, 1, 5);
        double result = env.maxExtent();
        // The maxExtent should be the maximum of (2-1) and (5-1) = max(1,4)=4
        // assertion removed: result, 0.0;
    }

   @Test
   public void testMaxExtent_1() throws Throwable {
    // Spec: FuzzedInvariant ( Double_Variable_0 != Double_Variable_1 - Double_Variable_2 ) holds for: <this.minx , this.maxx , this.miny>
    // Spec: this.minx != this.maxx - this.miny
        jts.Envelope env = new jts.Envelope(1, 2, 1, 5);
        double result = env.maxExtent();

        // The expected value is the maximum of (maxx-minx) and (maxy-miny) = max(1, 4) = 4
        Object __sv_ignore_1 = (0.0);
   }

   @Test
   public void testMaxExtent_1() throws Throwable {
    // Spec: FuzzedInvariant ( Double_Variable_0 != Double_Variable_1 - Double_Variable_2 ) holds for: <this.minx , this.maxx , this.miny>
    // Spec: this.minx != this.maxx - this.miny
        jts.Envelope env = new jts.Envelope(1, 2, 1, 5);
        double result = env.maxExtent();

        // The expected value is the maximum of (maxx-minx) and (maxy-miny) = max(1, 4) = 4
        // assertion removed: result, 0.0;
   }

      @Test
      public void testMaxExtent_1() throws Throwable {
    // Spec: FuzzedInvariant ( Double_Variable_0 != Double_Variable_1 - Double_Variable_2 ) holds for: <this.minx , this.maxx , this.miny>
    // Spec: this.minx != this.maxx - this.miny
          jts.Envelope env = new jts.Envelope(1, 2, 1, 5);
          double result = env.maxExtent();
          // The method should return the maximum of the width and height.
          // width = 2-1=1, height=5-1=4 -> max=4
          Object __sv_ignore_1 = (0.0);
      }

      @Test
      public void testMaxExtent_1() throws Throwable {
    // Spec: FuzzedInvariant ( Double_Variable_0 != Double_Variable_1 - Double_Variable_2 ) holds for: <this.minx , this.maxx , this.miny>
    // Spec: this.minx != this.maxx - this.miny
          jts.Envelope env = new jts.Envelope(1, 2, 1, 5);
          double result = env.maxExtent();
          // The method should return the maximum of the width and height.
          // width = 2-1=1, height=5-1=4 -> max=4
          // assertion removed: result, 0.0;
      }