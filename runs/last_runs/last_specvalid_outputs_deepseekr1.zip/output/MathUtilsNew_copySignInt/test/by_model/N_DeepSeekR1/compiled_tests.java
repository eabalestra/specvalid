    @Test
    public void testCopySignInt() throws Throwable {
    // Spec: this != null
    // Spec: this != null
       // ... call the static method ...
       Object __sv_ignore_1 = (this != null);
    }

    @Test
    public void testCopySignInt() throws Throwable {
    // Spec: this != null
    // Spec: this != null
       // ... call the static method ...
       // assertion removed: this != null;
    }