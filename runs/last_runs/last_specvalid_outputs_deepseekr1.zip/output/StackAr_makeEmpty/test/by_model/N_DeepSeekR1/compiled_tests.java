     @Test
     public void testMakeEmpty() throws Throwable {
    // Spec: FuzzedInvariant ( Integer_Variable_0 <= Integer_Variable_1 * 1 ) holds for: <this.topOfStack, orig(this.topOfStack)>
    // Spec: this.topOfStack <= old(this.topOfStack) * 1
         DataStructures.StackAr stack = new DataStructures.StackAr(10);
         stack.push(new Object());
         stack.makeEmpty();
         // assertion removed: stack.isEmpty();
     }

     @Test
     public void testMakeEmpty() throws Throwable {
    // Spec: FuzzedInvariant ( Integer_Variable_0 <= Integer_Variable_1 * 1 ) holds for: <this.topOfStack, orig(this.topOfStack)>
    // Spec: this.topOfStack <= old(this.topOfStack) * 1
         DataStructures.StackAr stack = new DataStructures.StackAr(10);
         stack.push(new Object());
         stack.makeEmpty();
         stack.isEmpty();
     }

    @Test
    public void testMakeEmpty_Counterexample() throws Throwable {
    // Spec: FuzzedInvariant ( Integer_Variable_0 <= Integer_Variable_1 * 1 ) holds for: <this.topOfStack, orig(this.topOfStack)>
    // Spec: this.topOfStack <= old(this.topOfStack) * 1
        DataStructures.StackAr stack = new DataStructures.StackAr(10);
        stack.push("Hello");
        stack.makeEmpty();
        // assertion removed: stack.isEmpty();
    }

    @Test
    public void testMakeEmpty_Counterexample() throws Throwable {
    // Spec: FuzzedInvariant ( Integer_Variable_0 <= Integer_Variable_1 * 1 ) holds for: <this.topOfStack, orig(this.topOfStack)>
    // Spec: this.topOfStack <= old(this.topOfStack) * 1
        DataStructures.StackAr stack = new DataStructures.StackAr(10);
        stack.push("Hello");
        stack.makeEmpty();
        stack.isEmpty();
    }

    @Test
    public void testMakeEmpty_Counterexample() throws Throwable {
    // Spec: FuzzedInvariant ( Integer_Variable_0 <= Integer_Variable_1 * 1 ) holds for: <this.topOfStack, orig(this.topOfStack)>
    // Spec: this.topOfStack <= old(this.topOfStack) * 1
        // Create a stack and set it to an invalid state
        DataStructures.StackAr stack = new DataStructures.StackAr(10);

        // Access the private field topOfStack
        java.lang.reflect.Field topOfStackField = DataStructures.StackAr.class.getDeclaredField("topOfStack");
        topOfStackField.setAccessible(true);
        topOfStackField.set(stack, -2);

        int origTopOfStack = -2; // old value

        // Call the method
        stack.makeEmpty();

        // Check the new state
        int newTopOfStack = (int) topOfStackField.get(stack);
        // assertion removed: newTopOfStack <= origTopOfStack;
    }

    @Test
    public void testMakeEmpty_Counterexample() throws Throwable {
    // Spec: FuzzedInvariant ( Integer_Variable_0 <= Integer_Variable_1 * 1 ) holds for: <this.topOfStack, orig(this.topOfStack)>
    // Spec: this.topOfStack <= old(this.topOfStack) * 1
        // Create a stack and set it to an invalid state
        DataStructures.StackAr stack = new DataStructures.StackAr(10);

        // Access the private field topOfStack
        java.lang.reflect.Field topOfStackField = DataStructures.StackAr.class.getDeclaredField("topOfStack");
        topOfStackField.setAccessible(true);
        topOfStackField.set(stack, -2);

        int origTopOfStack = -2; // old value

        // Call the method
        stack.makeEmpty();

        // Check the new state
        int newTopOfStack = (int) topOfStackField.get(stack);
        // assertion removed: newTopOfStack <= origTopOfStack;
    }

@Test
public void testMakeEmpty_Counterexample() throws Throwable {
    // Spec: FuzzedInvariant ( Integer_Variable_0 <= Integer_Variable_1 * 1 ) holds for: <this.topOfStack, orig(this.topOfStack)>
    // Spec: this.topOfStack <= old(this.topOfStack) * 1
    DataStructures.StackAr stack = new DataStructures.StackAr(10);
    
    // Set topOfStack to -2 via reflection
    java.lang.reflect.Field topOfStackField = DataStructures.StackAr.class.getDeclaredField("topOfStack");
    topOfStackField.setAccessible(true);
    topOfStackField.set(stack, -2);
    int origTopOfStack = -2; // old value of topOfStack

    // Call the method under test
    stack.makeEmpty();

    // Now get the new topOfStack
    int newTopOfStack = (int) topOfStackField.get(stack);

    // The postcondition: newTopOfStack should be <= origTopOfStack (which is -2)
    // assertion removed: newTopOfStack <= origTopOfStack;
}

@Test
public void testMakeEmpty_Counterexample() throws Throwable {
    // Spec: FuzzedInvariant ( Integer_Variable_0 <= Integer_Variable_1 * 1 ) holds for: <this.topOfStack, orig(this.topOfStack)>
    // Spec: this.topOfStack <= old(this.topOfStack) * 1
    DataStructures.StackAr stack = new DataStructures.StackAr(10);
    
    // Set topOfStack to -2 via reflection
    java.lang.reflect.Field topOfStackField = DataStructures.StackAr.class.getDeclaredField("topOfStack");
    topOfStackField.setAccessible(true);
    topOfStackField.set(stack, -2);
    int origTopOfStack = -2; // old value of topOfStack

    // Call the method under test
    stack.makeEmpty();

    // Now get the new topOfStack
    int newTopOfStack = (int) topOfStackField.get(stack);

    // The postcondition: newTopOfStack should be <= origTopOfStack (which is -2)
    // assertion removed: "Postcondition violated: newTopOfStack = " + newTopOfStack + " is not <= " + origTopOfStack, newTopOfStack <= origTopOfStack;
}

@Test
public void testMakeEmpty_1() throws Throwable {
    // Spec: FuzzedInvariant ( Integer_Variable_0 <= Integer_Variable_1 * 1 ) holds for: <this.topOfStack, orig(this.topOfStack)>
    // Spec: this.topOfStack <= old(this.topOfStack) * 1
    // Create a DataStructures.StackAr object
    DataStructures.StackAr stack = new DataStructures.StackAr(10);
    
    // Use reflection to set topOfStack to -2
    java.lang.reflect.Field topOfStackField = DataStructures.StackAr.class.getDeclaredField("topOfStack");
    topOfStackField.setAccessible(true);
    topOfStackField.set(stack, -2);
    int origTopOfStack = -2; // Save the old value for verification

    // Execute the method under test
    stack.makeEmpty();
    
    // Verify the postcondition: new topOfStack should be <= original topOfStack
    int newTopOfStack = (int) topOfStackField.get(stack);
    // assertion removed: newTopOfStack <= origTopOfStack;
}

@Test
public void testMakeEmptyViolation() throws Throwable {
    // Spec: \old(this.topOfStack) < daikon.Quant.size(this.theArray)-1
    // Spec: old(this.topOfStack) < size(this.theArray)-1
  DataStructures.StackAr stack = new DataStructures.StackAr(1);
  try {
    // We must push one element to make the stack full.
    stack.push("item");
  } catch (DataStructures.Overflow e) {
    // This should not happen because we just created a stack of capacity 1 and pushed one element (it should not be full until we push the first element? but after pushing one, it's full but the push did not throw an exception because the condition was not full until after the push).
    // However, the push method throws an DataStructures.Overflow if the stack is already full. But at the moment of pushing, the stack was not full (because it was empty). 
    // So we don't expect an exception.
    // fail removed;
  }

  int oldTopOfStack;
  int arrayLength;
  try {
      java.lang.reflect.Field topOfStackField = DataStructures.StackAr.class.getDeclaredField("topOfStack");
      topOfStackField.setAccessible(true);
      oldTopOfStack = (int) topOfStackField.get(stack);
      java.lang.reflect.Field theArrayField = DataStructures.StackAr.class.getDeclaredField("theArray");
      theArrayField.setAccessible(true);
      Object[] theArray = (Object[]) theArrayField.get(stack);
      arrayLength = theArray.length;
  } catch (Exception e) {
      throw new RuntimeException(e);
  }

  // Call the method under test
  stack.makeEmpty();

  // Verify the postcondition
  // assertion removed: oldTopOfStack < arrayLength - 1;
}

@Test
public void testMakeEmptyViolation() throws Throwable {
    // Spec: \old(this.topOfStack) < daikon.Quant.size(this.theArray)-1
    // Spec: old(this.topOfStack) < size(this.theArray)-1
  DataStructures.StackAr stack = new DataStructures.StackAr(1);
  try {
    // We must push one element to make the stack full.
    stack.push("item");
  } catch (DataStructures.Overflow e) {
    // This should not happen because we just created a stack of capacity 1 and pushed one element (it should not be full until we push the first element? but after pushing one, it's full but the push did not throw an exception because the condition was not full until after the push).
    // However, the push method throws an DataStructures.Overflow if the stack is already full. But at the moment of pushing, the stack was not full (because it was empty). 
    // So we don't expect an exception.
    // fail removed;
  }

  int oldTopOfStack;
  int arrayLength;
  try {
      java.lang.reflect.Field topOfStackField = DataStructures.StackAr.class.getDeclaredField("topOfStack");
      topOfStackField.setAccessible(true);
      oldTopOfStack = (int) topOfStackField.get(stack);
      java.lang.reflect.Field theArrayField = DataStructures.StackAr.class.getDeclaredField("theArray");
      theArrayField.setAccessible(true);
      Object[] theArray = (Object[]) theArrayField.get(stack);
      arrayLength = theArray.length;
  } catch (Exception e) {
      throw new RuntimeException(e);
  }

  // Call the method under test
  stack.makeEmpty();

  // Verify the postcondition
  // assertion removed: oldTopOfStack < arrayLength - 1;
}

  @Test
  public void testMakeEmpty_1() throws Throwable {
    // Spec: \old(this.topOfStack) < daikon.Quant.size(this.theArray)-1
    // Spec: old(this.topOfStack) < size(this.theArray)-1
      DataStructures.StackAr stack = new DataStructures.StackAr(1);
      try {
          stack.push("item");
      } catch (DataStructures.Overflow e) {
          // fail removed;
      }

      // We know that before makeEmpty, topOfStack is 0 and theArray.length is 1.
      int oldTopOfStack = 0;
      int arrayLength = 1;

      stack.makeEmpty();

      // Now check the postcondition: oldTopOfStack < arrayLength-1
      // That is: 0 < 1-1 -> 0<0 -> false -> the assertion will fail.
      // assertion removed: oldTopOfStack < arrayLength - 1;
  }

  @Test
  public void testMakeEmpty_1() throws Throwable {
    // Spec: \old(this.topOfStack) < daikon.Quant.size(this.theArray)-1
    // Spec: old(this.topOfStack) < size(this.theArray)-1
      DataStructures.StackAr stack = new DataStructures.StackAr(1);
      try {
          stack.push("item");
      } catch (DataStructures.Overflow e) {
          // fail removed;
      }

      // We know that before makeEmpty, topOfStack is 0 and theArray.length is 1.
      int oldTopOfStack = 0;
      int arrayLength = 1;

      stack.makeEmpty();

      // Now check the postcondition: oldTopOfStack < arrayLength-1
      // That is: 0 < 1-1 -> 0<0 -> false -> the assertion will fail.
      // assertion removed: oldTopOfStack < arrayLength - 1;
  }

@Test
public void testMakeEmpty_1() throws Throwable {
    // Spec: \old(this.topOfStack) < daikon.Quant.size(this.theArray)-1
    // Spec: old(this.topOfStack) < size(this.theArray)-1
    DataStructures.StackAr stack = new DataStructures.StackAr(1);
    try {
        stack.push("item");
    } catch (DataStructures.Overflow e) {
        // fail removed;
    }

    int oldTopOfStack = 0;
    int arrayLength = 1; // because we created the stack with capacity 1

    stack.makeEmpty();

    // The postcondition: old(this.topOfStack) < size(this.theArray)-1
    // becomes: 0 < 1 - 1 -> 0<0 -> false
    // assertion removed: oldTopOfStack < arrayLength - 1;
}

@Test
public void testMakeEmpty_1() throws Throwable {
    // Spec: \old(this.topOfStack) < daikon.Quant.size(this.theArray)-1
    // Spec: old(this.topOfStack) < size(this.theArray)-1
    DataStructures.StackAr stack = new DataStructures.StackAr(1);
    try {
        stack.push("item");
    } catch (DataStructures.Overflow e) {
        // fail removed;
    }

    int oldTopOfStack = 0;
    int arrayLength = 1; // because we created the stack with capacity 1

    stack.makeEmpty();

    // The postcondition: old(this.topOfStack) < size(this.theArray)-1
    // becomes: 0 < 1 - 1 -> 0<0 -> false
    // assertion removed: oldTopOfStack < arrayLength - 1;
}

    @Test
    public void testMakeEmpty_1() throws Throwable {
    // Spec: \old(this.topOfStack) < daikon.Quant.size(this.theArray)-1
    // Spec: old(this.topOfStack) < size(this.theArray)-1
        DataStructures.StackAr stack = new DataStructures.StackAr(1);
        try {
            stack.push("item");
        } catch (DataStructures.Overflow e) {
            // fail removed;
        }

        int oldTopOfStack = 0;
        int arrayLength = 1;

        stack.makeEmpty();

        // Check the postcondition condition: oldTopOfStack < arrayLength-1
        // assertion removed: oldTopOfStack < arrayLength - 1;
    }

    @Test
    public void testMakeEmpty_1() throws Throwable {
    // Spec: \old(this.topOfStack) < daikon.Quant.size(this.theArray)-1
    // Spec: old(this.topOfStack) < size(this.theArray)-1
        DataStructures.StackAr stack = new DataStructures.StackAr(1);
        try {
            stack.push("item");
        } catch (DataStructures.Overflow e) {
            // fail removed;
        }

        int oldTopOfStack = 0;
        int arrayLength = 1;

        stack.makeEmpty();

        // Check the postcondition condition: oldTopOfStack < arrayLength-1
        // assertion removed: oldTopOfStack < arrayLength - 1;
    }

     @Test
     public void testMakeEmpty() throws Throwable {
    // Spec: \old(this.topOfStack) < daikon.Quant.size(this.theArray)-1
    // Spec: old(this.topOfStack) < size(this.theArray)-1
         DataStructures.StackAr stack = new DataStructures.StackAr(5);
         // Push some items
         stack.push("item1");
         stack.push("item2");
         // Check the stack is not empty
         // assertion removed: stack.isEmpty();
         // Call makeEmpty
         stack.makeEmpty();
         // Now check that it is empty
         // assertion removed: stack.isEmpty();
     }

     @Test
     public void testMakeEmpty() throws Throwable {
    // Spec: \old(this.topOfStack) < daikon.Quant.size(this.theArray)-1
    // Spec: old(this.topOfStack) < size(this.theArray)-1
         DataStructures.StackAr stack = new DataStructures.StackAr(5);
         // Push some items
         stack.push("item1");
         stack.push("item2");
         // Check the stack is not empty
         stack.isEmpty();
         // Call makeEmpty
         stack.makeEmpty();
         // Now check that it is empty
         stack.isEmpty();
     }

@Test
public void testMakeEmpty_1() throws Throwable {
    // Spec: \old(this.topOfStack) < daikon.Quant.size(this.theArray)-1
    // Spec: old(this.topOfStack) < size(this.theArray)-1
   DataStructures.StackAr stack = new DataStructures.StackAr(1);
   try {
       stack.push("item");
   } catch (DataStructures.Overflow e) {
       // fail removed;
   }
   int oldTopOfStack = 0;
   int arrayLength = 1;

   stack.makeEmpty();

   // Check the postcondition: old(this.topOfStack) < size(this.theArray)-1
   // assertion removed: oldTopOfStack < arrayLength - 1;
}

@Test
public void testMakeEmpty_1() throws Throwable {
    // Spec: \old(this.topOfStack) < daikon.Quant.size(this.theArray)-1
    // Spec: old(this.topOfStack) < size(this.theArray)-1
   DataStructures.StackAr stack = new DataStructures.StackAr(1);
   try {
       stack.push("item");
   } catch (DataStructures.Overflow e) {
       // fail removed;
   }
   int oldTopOfStack = 0;
   int arrayLength = 1;

   stack.makeEmpty();

   // Check the postcondition: old(this.topOfStack) < size(this.theArray)-1
   // assertion removed: oldTopOfStack < arrayLength - 1;
}

@Test
public void testMakeEmpty_1() throws Throwable {
    // Spec: \old(this.topOfStack) < daikon.Quant.size(this.theArray)-1
    // Spec: old(this.topOfStack) < size(this.theArray)-1
   DataStructures.StackAr stack = new DataStructures.StackAr(1);
   try {
       stack.push("item");
   } catch (DataStructures.Overflow e) {
       // fail removed;
   }
   int oldTopOfStack = 0;
   int arrayLength = 1;

   stack.makeEmpty();

   // assertion removed: oldTopOfStack < arrayLength - 1;
}

@Test
public void testMakeEmpty_1() throws Throwable {
    // Spec: \old(this.topOfStack) < daikon.Quant.size(this.theArray)-1
    // Spec: old(this.topOfStack) < size(this.theArray)-1
   DataStructures.StackAr stack = new DataStructures.StackAr(1);
   try {
       stack.push("item");
   } catch (DataStructures.Overflow e) {
       // fail removed;
   }
   int oldTopOfStack = 0;
   int arrayLength = 1;

   stack.makeEmpty();

   // assertion removed: oldTopOfStack < arrayLength - 1;
}

@Test
public void testMakeEmpty_1() throws Throwable {
    // Spec: \old(this.topOfStack) < daikon.Quant.size(this.theArray)-1
    // Spec: old(this.topOfStack) < size(this.theArray)-1
   DataStructures.StackAr stack = new DataStructures.StackAr(1);
   try {
       stack.push("item");
   } catch (DataStructures.Overflow e) {
       // fail removed;
   }
   int oldTopOfStack = 0;  // 0 for full stack since capacity=1
   int arrayLength = 1;    // From constructor argument

   stack.makeEmpty();

   // Postcondition: old(this.topOfStack) < size(this.theArray)-1 → 0 < 1-1 (0<0 → false)
   // assertion removed: oldTopOfStack < arrayLength - 1;
}

@Test
public void testMakeEmpty_1() throws Throwable {
    // Spec: \old(this.topOfStack) < daikon.Quant.size(this.theArray)-1
    // Spec: old(this.topOfStack) < size(this.theArray)-1
   DataStructures.StackAr stack = new DataStructures.StackAr(1);
   try {
       stack.push("item");
   } catch (DataStructures.Overflow e) {
       // fail removed;
   }
   int oldTopOfStack = 0;  // 0 for full stack since capacity=1
   int arrayLength = 1;    // From constructor argument

   stack.makeEmpty();

   // Postcondition: old(this.topOfStack) < size(this.theArray)-1 → 0 < 1-1 (0<0 → false)
   // assertion removed: oldTopOfStack < arrayLength - 1;
}

    @Test
    public void testMakeEmpty_ResidualElements() throws Throwable {
    // Spec: daikon.Quant.eltsEqual(daikon.Quant.typeArray(this.theArray), null)
    // Spec: eltsEqual(typeArray(this.theArray), null)
        // Create a stack with capacity 3
        DataStructures.StackAr stack = new DataStructures.StackAr(3);
        
        // Push two elements
        stack.push(10);
        stack.push(20);
        
        // Pop both to reset topOfStack to -1 (array indices 0 and 1 become null by pop operations)
        stack.pop();
        stack.pop();
        
        // Simulate residual left-over element at index 2 due to bug/initialization issue
        // Using reflection to inject a non-null element without using push
        Field arrayField = stack.getClass().getDeclaredField("theArray");
        arrayField.setAccessible(true);
        Object[] internalArray = (Object[]) arrayField.get(stack);
        internalArray[2] = 30; // Manually set index 2 to a non-null value
        
        // Call makeEmpty()
        stack.makeEmpty();
        
        // Verify postcondition: all array elements should be null
        for (Object element : internalArray) {
            // assertion removed: element == null;
        }
    }

    @Test
    public void testMakeEmpty_ResidualElements() throws Throwable {
    // Spec: daikon.Quant.eltsEqual(daikon.Quant.typeArray(this.theArray), null)
    // Spec: eltsEqual(typeArray(this.theArray), null)
        // Create a stack with capacity 3
        DataStructures.StackAr stack = new DataStructures.StackAr(3);
        
        // Push two elements
        stack.push(10);
        stack.push(20);
        
        // Pop both to reset topOfStack to -1 (array indices 0 and 1 become null by pop operations)
        stack.pop();
        stack.pop();
        
        // Simulate residual left-over element at index 2 due to bug/initialization issue
        // Using reflection to inject a non-null element without using push
        Field arrayField = stack.getClass().getDeclaredField("theArray");
        arrayField.setAccessible(true);
        Object[] internalArray = (Object[]) arrayField.get(stack);
        internalArray[2] = 30; // Manually set index 2 to a non-null value
        
        // Call makeEmpty()
        stack.makeEmpty();
        
        // Verify postcondition: all array elements should be null
        for (Object element : internalArray) {
            // assertion removed: element == null;
        }
    }

   @Test
   public void testMakeEmpty_1() throws Throwable {
    // Spec: this.topOfStack < daikon.Quant.size(this.theArray)-1
    // Spec: this.topOfStack < size(this.theArray)-1
        // ... // the body
   }

   @Test
   public void testMakeEmpty_1() throws Throwable {
    // Spec: this.topOfStack < daikon.Quant.size(this.theArray)-1
    // Spec: this.topOfStack < size(this.theArray)-1
        // ... // the body
   }

    @Test
    public void testMakeEmpty_1() throws Throwable {
    // Spec: this.topOfStack < daikon.Quant.size(this.theArray)-1
    // Spec: this.topOfStack < size(this.theArray)-1
        DataStructures.StackAr stack = new DataStructures.StackAr(0);
        stack.makeEmpty();
        
        // Use reflection to get field "topOfStack"
        java.lang.reflect.Field topOfStackField = DataStructures.StackAr.class.getDeclaredField("topOfStack");
        topOfStackField.setAccessible(true);
        int topOfStack = (int) topOfStackField.get(stack);
        
        // Use reflection to get field "theArray" and then its length
        java.lang.reflect.Field theArrayField = DataStructures.StackAr.class.getDeclaredField("theArray");
        theArrayField.setAccessible(true);
        Object[] theArray = (Object[]) theArrayField.get(stack);
        int arrayLength = theArray.length;

        // Check condition: topOfStack < arrayLength - 1
        // assertion removed: topOfStack < arrayLength - 1;
    }

    @Test
    public void testMakeEmpty_1() throws Throwable {
    // Spec: this.topOfStack < daikon.Quant.size(this.theArray)-1
    // Spec: this.topOfStack < size(this.theArray)-1
        DataStructures.StackAr stack = new DataStructures.StackAr(0);
        stack.makeEmpty();
        
        // Use reflection to get field "topOfStack"
        java.lang.reflect.Field topOfStackField = DataStructures.StackAr.class.getDeclaredField("topOfStack");
        topOfStackField.setAccessible(true);
        int topOfStack = (int) topOfStackField.get(stack);
        
        // Use reflection to get field "theArray" and then its length
        java.lang.reflect.Field theArrayField = DataStructures.StackAr.class.getDeclaredField("theArray");
        theArrayField.setAccessible(true);
        Object[] theArray = (Object[]) theArrayField.get(stack);
        int arrayLength = theArray.length;

        // Check condition: topOfStack < arrayLength - 1
        // assertion removed: topOfStack < arrayLength - 1;
    }

    @Test
    public void testMakeEmpty_1() throws Throwable {
    // Spec: this.topOfStack < daikon.Quant.size(this.theArray)-1
    // Spec: this.topOfStack < size(this.theArray)-1
        DataStructures.StackAr stack = new DataStructures.StackAr(0);
        // Since the method doesn't throw any exception? We can call it.
        stack.makeEmpty();

        // Now, we want to check: stack.topOfStack < stack.theArray.length - 1?
        // But the fields are private. We must use reflection.
        try {
            java.lang.reflect.Field topOfStackField = DataStructures.StackAr.class.getDeclaredField("topOfStack");
            topOfStackField.setAccessible(true);
            int topOfStack = topOfStackField.getInt(stack);
            
            java.lang.reflect.Field theArrayField = DataStructures.StackAr.class.getDeclaredField("theArray");
            theArrayField.setAccessible(true);
            Object[] theArray = (Object[]) theArrayField.get(stack);
            int arrayLength = theArray.length;

            // Condition: topOfStack < arrayLength - 1
            // assertion removed: topOfStack < arrayLength - 1;
        } catch (Exception e) {
            e.printStackTrace();
            // We are failing due to reflection? But must we?
            throw new RuntimeException(e);
        }
    }

    @Test
    public void testMakeEmpty_1() throws Throwable {
    // Spec: this.topOfStack < daikon.Quant.size(this.theArray)-1
    // Spec: this.topOfStack < size(this.theArray)-1
        DataStructures.StackAr stack = new DataStructures.StackAr(0);
        // Since the method doesn't throw any exception? We can call it.
        stack.makeEmpty();

        // Now, we want to check: stack.topOfStack < stack.theArray.length - 1?
        // But the fields are private. We must use reflection.
        try {
            java.lang.reflect.Field topOfStackField = DataStructures.StackAr.class.getDeclaredField("topOfStack");
            topOfStackField.setAccessible(true);
            int topOfStack = topOfStackField.getInt(stack);
            
            java.lang.reflect.Field theArrayField = DataStructures.StackAr.class.getDeclaredField("theArray");
            theArrayField.setAccessible(true);
            Object[] theArray = (Object[]) theArrayField.get(stack);
            int arrayLength = theArray.length;

            // Condition: topOfStack < arrayLength - 1
            // assertion removed: topOfStack < arrayLength - 1;
        } catch (Exception e) {
            e.printStackTrace();
            // We are failing due to reflection? But must we?
            throw new RuntimeException(e);
        }
    }

    @Test
    public void testMakeEmpty_1() throws Throwable {
    // Spec: this.topOfStack < daikon.Quant.size(this.theArray)-1
    // Spec: this.topOfStack < size(this.theArray)-1
        DataStructures.StackAr stack = new DataStructures.StackAr(0);
        stack.makeEmpty();
        // Check: we want topOfStack < arrayLength-1 -> which is false in this case.
        // But note: isFull() returns: (topOfStack == arrayLength-1) -> which in this case is true.
        // Therefore, !isFull() is false -> which we want to // assertion removed: as true? 
        // Then the test will fail.

        // Alternatively;

        // But in our case, stack.isFull() returns true, so !stack.isFull() is false -> so the assertion fails.
    }

    @Test
    public void testMakeEmpty_1() throws Throwable {
    // Spec: this.topOfStack < daikon.Quant.size(this.theArray)-1
    // Spec: this.topOfStack < size(this.theArray)-1
        DataStructures.StackAr stack = new DataStructures.StackAr(0);
        stack.makeEmpty();
        // Check: we want topOfStack < arrayLength-1 -> which is false in this case.
        // But note: isFull() returns: (topOfStack == arrayLength-1) -> which in this case is true.
        // Therefore, !isFull() is false -> which we want to // assertion removed: as true? 
        // Then the test will fail.

        // Alternatively;

        // But in our case, stack.isFull() returns true, so !stack.isFull() is false -> so the assertion fails.
    }

    @Test
    public void testMakeEmpty_1() throws Throwable {
    // Spec: this.topOfStack < daikon.Quant.size(this.theArray)-1
    // Spec: this.topOfStack < size(this.theArray)-1
        DataStructures.StackAr stack = new DataStructures.StackAr(0);
        stack.makeEmpty();
        // assertion removed: !stack.isFull();
    }

@Test
public void testMakeEmpty_1() throws Throwable {
    // Spec: this.topOfStack < daikon.Quant.size(this.theArray)-1
    // Spec: this.topOfStack < size(this.theArray)-1
    DataStructures.StackAr stack = new DataStructures.StackAr(0);
    stack.makeEmpty();
    // assertion removed: !stack.isFull();
}

@Test
public void testMakeEmpty_1() throws Throwable {
    // Spec: this.topOfStack < daikon.Quant.size(this.theArray)-1
    // Spec: this.topOfStack < size(this.theArray)-1
    DataStructures.StackAr stack = new DataStructures.StackAr(0);
    stack.makeEmpty();
    // assertion removed: !stack.isFull();
}

@Test
public void testMakeEmptyViolation() throws Throwable {
    // Spec: this.topOfStack < daikon.Quant.size(this.theArray)-1
    // Spec: this.topOfStack < size(this.theArray)-1
    // Create stack with capacity 0
    DataStructures.StackAr stack = new DataStructures.StackAr(0);
    
    // Call method under test
    stack.makeEmpty();
    
    // Postcondition: this.topOfStack < size(this.theArray)-1
    // Equivalent to !this.isFull() for valid states
    // assertion removed: !stack.isFull();  // Fails when capacity=0
}