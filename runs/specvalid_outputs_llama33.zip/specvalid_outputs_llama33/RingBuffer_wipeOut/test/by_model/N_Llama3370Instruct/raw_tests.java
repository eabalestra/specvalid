@Test
public void testWipeOut_1() throws Throwable {
    // Spec: this.start == 1
    // Spec: this.start == 1
   examples.RingBuffer<String> ringBuffer = new examples.RingBuffer<>(10);
   ringBuffer.extend("test");
   ringBuffer.remove();

   ringBuffer.wipeOut();

   assertFalse(ringBuffer.isEmpty());
}

@Test
public void testWipeOut_1() throws Throwable {
    // Spec: this.start == 1
    // Spec: this.start == 1
   examples.RingBuffer<String> ringBuffer = new examples.RingBuffer<>(10);
   ringBuffer.extend("test");
   ringBuffer.remove();

   ringBuffer.wipeOut();

   ringBuffer.isEmpty();
}

@Test
public void testWipeOut_1() throws Throwable {
    // Spec: daikon.Quant.size(this.data) == 1
    // Spec: size(this.data) == 1
   examples.RingBuffer<String> ringBuffer = new examples.RingBuffer<>(5);
   ringBuffer.extend("Value1");
   ringBuffer.extend("Value2");
   ringBuffer.extend("Value3");

   ringBuffer.wipeOut();

   assertEquals(0, ringBuffer.count());
}

@Test
public void testWipeOut_1() throws Throwable {
    // Spec: daikon.Quant.size(this.data) == 1
    // Spec: size(this.data) == 1
   examples.RingBuffer<String> ringBuffer = new examples.RingBuffer<>(5);
   ringBuffer.extend("Value1");
   ringBuffer.extend("Value2");
   ringBuffer.extend("Value3");

   ringBuffer.wipeOut();

   ringBuffer.count();
}

@Test
public void testWipeOut_1() throws Throwable {
    // Spec: FuzzedInvariant ( Integer_Variable_0 >= #(RingBuffer.data) ) holds for: <orig(this), this.start>
    // Spec: this.start >= #(old(this).data)
   examples.RingBuffer<Integer> ringBuffer = new examples.RingBuffer<>(10);
   ringBuffer.extend(1);
   ringBuffer.extend(2);
   ringBuffer.extend(3);

   examples.RingBuffer<Integer> origRingBuffer = new examples.RingBuffer<>(10);
   origRingBuffer.extend(1);
   origRingBuffer.extend(2);
   origRingBuffer.extend(3);

   ringBuffer.wipeOut();

   assertTrue(ringBuffer.isEmpty());
}

@Test
public void testWipeOut_1() throws Throwable {
    // Spec: FuzzedInvariant ( Integer_Variable_0 >= #(RingBuffer.data) ) holds for: <orig(this), this.start>
    // Spec: this.start >= #(old(this).data)
   examples.RingBuffer<Integer> ringBuffer = new examples.RingBuffer<>(10);
   ringBuffer.extend(1);
   ringBuffer.extend(2);
   ringBuffer.extend(3);

   examples.RingBuffer<Integer> origRingBuffer = new examples.RingBuffer<>(10);
   origRingBuffer.extend(1);
   origRingBuffer.extend(2);
   origRingBuffer.extend(3);

   ringBuffer.wipeOut();

   ringBuffer.isEmpty();
}

@Test
public void testWipeOut_1() throws Throwable {
    // Spec: FuzzedInvariant ( (Integer_Variable_0 > 0) xor (Integer_Variable_1 <= 0) ) holds for: <this.free, this.capacity_>
    // Spec: (this.free > 0) xor (this.capacity_ <= 0)
   examples.RingBuffer<Integer> ringBuffer = new examples.RingBuffer<>(5);

   ringBuffer.wipeOut();

   assertFalse(ringBuffer.isEmpty() ^ (ringBuffer.capacity() <= 0));
}

@Test
public void testWipeOut_1() throws Throwable {
    // Spec: FuzzedInvariant ( (Integer_Variable_0 > 0) xor (Integer_Variable_1 <= 0) ) holds for: <this.free, this.capacity_>
    // Spec: (this.free > 0) xor (this.capacity_ <= 0)
   examples.RingBuffer<Integer> ringBuffer = new examples.RingBuffer<>(5);

   ringBuffer.wipeOut();

   // assertion removed: ringBuffer.isEmpty() ^ (ringBuffer.capacity() <= 0);
}

@Test
public void testWipeOut_1() throws Throwable {
    // Spec: FuzzedInvariant ( Integer_Variable_0 = #(RingBuffer.data) ) holds for: <orig(this), this.start>
    // Spec: this.start = #(old(this).data)
   examples.RingBuffer<String> ringBuffer = new examples.RingBuffer<>(5);
   ringBuffer.extend("a");
   ringBuffer.extend("b");
   ringBuffer.extend("c");

   int oldDataSize = ringBuffer.count();

   ringBuffer.wipeOut();

   assertEquals(0, ringBuffer.count());
}

@Test
public void testWipeOut_1() throws Throwable {
    // Spec: FuzzedInvariant ( Integer_Variable_0 = #(RingBuffer.data) ) holds for: <orig(this), this.start>
    // Spec: this.start = #(old(this).data)
   examples.RingBuffer<String> ringBuffer = new examples.RingBuffer<>(5);
   ringBuffer.extend("a");
   ringBuffer.extend("b");
   ringBuffer.extend("c");

   int oldDataSize = ringBuffer.count();

   ringBuffer.wipeOut();

   ringBuffer.count();
}

@Test
public void testWipeOut_1() throws Throwable {
    // Spec: FuzzedInvariant ( (Integer_Variable_0 > 0) xor (Integer_Variable_1 <= 0) ) holds for: <this.start, this.capacity_>
    // Spec: (this.start > 0) xor (this.capacity_ <= 0)
   examples.RingBuffer<Integer> ringBuffer = new examples.RingBuffer<>(1);

   ringBuffer.wipeOut();

   boolean postcondition = ringBuffer.isEmpty();
   assertTrue(postcondition);
}

@Test
public void testWipeOut_1() throws Throwable {
    // Spec: FuzzedInvariant ( (Integer_Variable_0 > 0) xor (Integer_Variable_1 <= 0) ) holds for: <this.start, this.capacity_>
    // Spec: (this.start > 0) xor (this.capacity_ <= 0)
   examples.RingBuffer<Integer> ringBuffer = new examples.RingBuffer<>(1);

   ringBuffer.wipeOut();

   boolean postcondition = ringBuffer.isEmpty();
   // assertion removed: postcondition;
}