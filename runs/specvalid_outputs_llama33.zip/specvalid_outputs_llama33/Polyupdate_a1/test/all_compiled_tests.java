@Test
public void llmTest0() throws Throwable {
    // Spec: FuzzedInvariant ( (Integer_Variable_0 > -1) or (Integer_Variable_1 > Integer_Variable_2) ) holds for: <this._var23 , this._var426 , orig(y)>
    // Spec: (this._var23 > -1) or (this._var426 > old(y))
   examples.Polyupdate polyupdate = new examples.Polyupdate();
   polyupdate.clear();
   polyupdate.a1(-10);
   java.lang.reflect.Field field1 = polyupdate.getClass().getDeclaredField("_var23");
   field1.setAccessible(true);
}

@Test
public void llmTest1() throws Throwable {
    // Spec: FuzzedInvariant ( (Integer_Variable_0 > -1) or (Integer_Variable_1 > Integer_Variable_2) ) holds for: <this._var23 , this._var426 , orig(y)>
    // Spec: (this._var23 > -1) or (this._var426 > old(y))
   examples.Polyupdate polyupdate = new examples.Polyupdate();
   polyupdate.clear();
   polyupdate.a1(-10);
   java.lang.reflect.Field field1 = polyupdate.getClass().getDeclaredField("_var23");
   field1.setAccessible(true);
   // assertion removed: (Integer)field1.get(polyupdate) > -1 || (Integer)polyupdate.getClass().getDeclaredField("_var426").get(polyupdate) > -10;
}

@Test
public void llmTest2() throws Throwable {
    // Spec: FuzzedInvariant ( (Integer_Variable_0 <= -1) implies (Integer_Variable_1 >= Integer_Variable_2) ) holds for: <this._var23 , this._var426 , orig(y)>
    // Spec: (this._var23 <= -1) implies (this._var426 >= old(y))
   examples.Polyupdate polyupdate = new examples.Polyupdate();
   polyupdate.clear();
   java.lang.reflect.Field _var23 = polyupdate.getClass().getDeclaredField("_var23");
   _var23.setAccessible(true);
   _var23.set(polyupdate, -1);
   java.lang.reflect.Field _var426 = polyupdate.getClass().getDeclaredField("_var426");
   _var426.setAccessible(true);
   _var426.set(polyupdate, 0);
   int y = 1;

   polyupdate.a1(y);

   if ((int)_var23.get(polyupdate) <= -1) {
   }
}

@Test
public void llmTest3() throws Throwable {
    // Spec: FuzzedInvariant ( (Integer_Variable_0 <= -1) implies (Integer_Variable_1 >= Integer_Variable_2) ) holds for: <this._var23 , this._var426 , orig(y)>
    // Spec: (this._var23 <= -1) implies (this._var426 >= old(y))
   examples.Polyupdate polyupdate = new examples.Polyupdate();
   polyupdate.clear();
   java.lang.reflect.Field _var23 = polyupdate.getClass().getDeclaredField("_var23");
   _var23.setAccessible(true);
   _var23.set(polyupdate, -1);
   java.lang.reflect.Field _var426 = polyupdate.getClass().getDeclaredField("_var426");
   _var426.setAccessible(true);
   _var426.set(polyupdate, 0);
   int y = 1;

   polyupdate.a1(y);

   if ((int)_var23.get(polyupdate) <= -1) {
       // assertion removed: (int)_var426.get(polyupdate) >= y;
   }
}

@Test
public void llmTest4() throws Throwable {
    // Spec: FuzzedInvariant ( (Integer_Variable_0 = 0) implies (Integer_Variable_1 <= Integer_Variable_2) ) holds for: <this._var23 , orig(y) , orig(this._var23)>
    // Spec: (this._var23 = 0) implies (old(y) <= old(this._var23))
   examples.Polyupdate polyupdate = new examples.Polyupdate();
   java.lang.reflect.Field field = polyupdate.getClass().getDeclaredField("_var23");
   field.setAccessible(true);
   field.set(polyupdate, 0);
   polyupdate.a1(5);

   field = polyupdate.getClass().getDeclaredField("_var23");
   field.setAccessible(true);
}

@Test
public void llmTest5() throws Throwable {
    // Spec: FuzzedInvariant ( (Integer_Variable_0 = 0) implies (Integer_Variable_1 <= Integer_Variable_2) ) holds for: <this._var23 , orig(y) , orig(this._var23)>
    // Spec: (this._var23 = 0) implies (old(y) <= old(this._var23))
   examples.Polyupdate polyupdate = new examples.Polyupdate();
   java.lang.reflect.Field field = polyupdate.getClass().getDeclaredField("_var23");
   field.setAccessible(true);
   field.set(polyupdate, 0);
   polyupdate.a1(5);

   field = polyupdate.getClass().getDeclaredField("_var23");
   field.setAccessible(true);
   // assertion removed: (int)field.get(polyupdate) == 0 || (int)field.get(polyupdate) >= 5;
}

@Test
public void llmTest6() throws Throwable {
    // Spec: FuzzedInvariant ( (Integer_Variable_0 != -1) or (Integer_Variable_1 > Integer_Variable_2) ) holds for: <this._var23 , this._var426 , orig(this._var23)>
    // Spec: (this._var23 != -1) or (this._var426 > old(this._var23))
   examples.Polyupdate polyupdate = new examples.Polyupdate();
   polyupdate.clear();
   java.lang.reflect.Field _var23 = polyupdate.getClass().getDeclaredField("_var23");
   _var23.setAccessible(true);
   _var23.set(polyupdate, -1);
   java.lang.reflect.Field _var426 = polyupdate.getClass().getDeclaredField("_var426");
   _var426.setAccessible(true);
   _var426.set(polyupdate, 0);

   int origVar23 = (int) _var23.get(polyupdate);

   polyupdate.a1(0);

}

@Test
public void llmTest7() throws Throwable {
    // Spec: FuzzedInvariant ( (Integer_Variable_0 != -1) or (Integer_Variable_1 > Integer_Variable_2) ) holds for: <this._var23 , this._var426 , orig(this._var23)>
    // Spec: (this._var23 != -1) or (this._var426 > old(this._var23))
   examples.Polyupdate polyupdate = new examples.Polyupdate();
   polyupdate.clear();
   java.lang.reflect.Field _var23 = polyupdate.getClass().getDeclaredField("_var23");
   _var23.setAccessible(true);
   _var23.set(polyupdate, -1);
   java.lang.reflect.Field _var426 = polyupdate.getClass().getDeclaredField("_var426");
   _var426.setAccessible(true);
   _var426.set(polyupdate, 0);

   int origVar23 = (int) _var23.get(polyupdate);

   polyupdate.a1(0);

   // assertion removed: (int) _var23.get(polyupdate) != -1 || (int) _var426.get(polyupdate) > origVar23;
}

@Test
public void llmTest8() throws Throwable {
    // Spec: FuzzedInvariant ( (Integer_Variable_0 = 1) implies (Integer_Variable_1 <= Integer_Variable_2) ) holds for: <this._var23 , orig(this._var23) , orig(this._var426)>
    // Spec: (this._var23 = 1) implies (old(this._var23) <= old(this._var426))
   examples.Polyupdate polyupdate = new examples.Polyupdate();
   polyupdate.clear();
   polyupdate.a1(1);

}

@Test
public void llmTest9() throws Throwable {
    // Spec: FuzzedInvariant ( (Integer_Variable_0 = 1) implies (Integer_Variable_1 <= Integer_Variable_2) ) holds for: <this._var23 , orig(this._var23) , orig(this._var426)>
    // Spec: (this._var23 = 1) implies (old(this._var23) <= old(this._var426))
   examples.Polyupdate polyupdate = new examples.Polyupdate();
   polyupdate.clear();
   polyupdate.a1(1);

   // assertion removed: (polyupdate.sm() - polyupdate.sm() + polyupdate.sm() - polyupdate.sm() == 1) == (1 <= polyupdate.sm() - polyupdate.sm() + polyupdate.sm());
}

@Test
public void llmTest10() throws Throwable {
    // Spec: FuzzedInvariant ( (Integer_Variable_0 != Integer_Variable_1) or (Integer_Variable_1 <= 0) ) holds for: <this._var23, orig(this._var426)>
    // Spec: (this._var23 != old(this._var426)) or (old(this._var426) <= 0)
   examples.Polyupdate polyupdate = new examples.Polyupdate();
   polyupdate.clear();
   polyupdate.a1(-5);
}

@Test
public void llmTest11() throws Throwable {
    // Spec: FuzzedInvariant ( (Integer_Variable_0 != Integer_Variable_1) or (Integer_Variable_1 <= 0) ) holds for: <this._var23, orig(this._var426)>
    // Spec: (this._var23 != old(this._var426)) or (old(this._var426) <= 0)
   examples.Polyupdate polyupdate = new examples.Polyupdate();
   polyupdate.clear();
   polyupdate.a1(-5);
   // assertion removed: (polyupdate.sm() - polyupdate.sm() != polyupdate.sm()) || (polyupdate.sm() <= 0);
}

@Test
public void llmTest12() throws Throwable {
    // Spec: FuzzedInvariant ( (Integer_Variable_0 != Integer_Variable_1) or (Integer_Variable_1 <= 0) ) holds for: <this._var23, orig(this._var426)>
    // Spec: (this._var23 != old(this._var426)) or (old(this._var426) <= 0)
   examples.Polyupdate polyupdate = new examples.Polyupdate();
   java.lang.reflect.Field fieldVar23 = polyupdate.getClass().getDeclaredField("_var23");
   fieldVar23.setAccessible(true);
   fieldVar23.setInt(polyupdate, 10);

   java.lang.reflect.Field fieldVar426 = polyupdate.getClass().getDeclaredField("_var426");
   fieldVar426.setAccessible(true);
   fieldVar426.setInt(polyupdate, 10);

   polyupdate.a1(0);

}

@Test
public void llmTest13() throws Throwable {
    // Spec: FuzzedInvariant ( (Integer_Variable_0 != Integer_Variable_1) or (Integer_Variable_1 <= 0) ) holds for: <this._var23, orig(this._var426)>
    // Spec: (this._var23 != old(this._var426)) or (old(this._var426) <= 0)
   examples.Polyupdate polyupdate = new examples.Polyupdate();
   java.lang.reflect.Field fieldVar23 = polyupdate.getClass().getDeclaredField("_var23");
   fieldVar23.setAccessible(true);
   fieldVar23.setInt(polyupdate, 10);

   java.lang.reflect.Field fieldVar426 = polyupdate.getClass().getDeclaredField("_var426");
   fieldVar426.setAccessible(true);
   fieldVar426.setInt(polyupdate, 10);

   polyupdate.a1(0);

   // assertion removed: (fieldVar23.getInt(polyupdate) != fieldVar426.getInt(polyupdate)) || (fieldVar426.getInt(polyupdate) <= 0);
}

@Test
public void llmTest14() throws Throwable {
    // Spec: FuzzedInvariant ( (Integer_Variable_0 != 0) or (Integer_Variable_1 >= Integer_Variable_2) ) holds for: <this._var426 , orig(y) , orig(this._var426)>
    // Spec: (this._var426 != 0) or (old(y) >= old(this._var426))
   examples.Polyupdate polyupdate = new examples.Polyupdate();
   polyupdate.clear();
   polyupdate.a1(-10);
}

@Test
public void llmTest15() throws Throwable {
    // Spec: FuzzedInvariant ( (Integer_Variable_0 != 0) or (Integer_Variable_1 >= Integer_Variable_2) ) holds for: <this._var426 , orig(y) , orig(this._var426)>
    // Spec: (this._var426 != 0) or (old(y) >= old(this._var426))
   examples.Polyupdate polyupdate = new examples.Polyupdate();
   polyupdate.clear();
   polyupdate.a1(-10);
   // assertion removed: (polyupdate.sm() - polyupdate.sm() != 0) || (-10 >= (polyupdate.sm() - polyupdate.sm()));
}

@Test
public void llmTest16() throws Throwable {
    // Spec: FuzzedInvariant ( (Integer_Variable_0 <= Integer_Variable_1) or (Integer_Variable_1 != -1) ) holds for: <this._var426, orig(this._var426)>
    // Spec: (this._var426 <= old(this._var426)) or (old(this._var426) != -1)
   examples.Polyupdate polyupdate = new examples.Polyupdate();
   polyupdate.clear();

   polyupdate.a1(-10);

}

@Test
public void llmTest17() throws Throwable {
    // Spec: FuzzedInvariant ( (Integer_Variable_0 <= Integer_Variable_1) or (Integer_Variable_1 != -1) ) holds for: <this._var426, orig(this._var426)>
    // Spec: (this._var426 <= old(this._var426)) or (old(this._var426) != -1)
   examples.Polyupdate polyupdate = new examples.Polyupdate();
   polyupdate.clear();

   polyupdate.a1(-10);

   // assertion removed: (polyupdate.sm() <= polyupdate.sm()) || (polyupdate.sm() != -10);
}

@Test
public void llmTest18() throws Throwable {
    // Spec: FuzzedInvariant ( (Integer_Variable_0 = Integer_Variable_1) or (Integer_Variable_1 != Integer_Variable_2) ) holds for: <this._var23 , orig(y) , orig(this._var426)>
    // Spec: (this._var23 = old(y)) or (old(y) != old(this._var426))
   examples.Polyupdate polyupdate = new examples.Polyupdate();
   polyupdate.clear();
   java.lang.reflect.Field field1 = examples.Polyupdate.class.getDeclaredField("_var23");
   field1.setAccessible(true);
   field1.set(polyupdate, 0);
   java.lang.reflect.Field field2 = examples.Polyupdate.class.getDeclaredField("_var426");
   field2.setAccessible(true);
   field2.set(polyupdate, 0);

   int y = 0;
   polyupdate.a1(y);

   field1 = examples.Polyupdate.class.getDeclaredField("_var23");
   field1.setAccessible(true);
   int _var23 = field1.getInt(polyupdate);
   field2 = examples.Polyupdate.class.getDeclaredField("_var426");
   field2.setAccessible(true);
   int _var426 = field2.getInt(polyupdate);
}

@Test
public void llmTest19() throws Throwable {
    // Spec: FuzzedInvariant ( (Integer_Variable_0 = Integer_Variable_1) or (Integer_Variable_1 != Integer_Variable_2) ) holds for: <this._var23 , orig(y) , orig(this._var426)>
    // Spec: (this._var23 = old(y)) or (old(y) != old(this._var426))
   examples.Polyupdate polyupdate = new examples.Polyupdate();
   polyupdate.clear();
   java.lang.reflect.Field field1 = examples.Polyupdate.class.getDeclaredField("_var23");
   field1.setAccessible(true);
   field1.set(polyupdate, 0);
   java.lang.reflect.Field field2 = examples.Polyupdate.class.getDeclaredField("_var426");
   field2.setAccessible(true);
   field2.set(polyupdate, 0);

   int y = 0;
   polyupdate.a1(y);

   field1 = examples.Polyupdate.class.getDeclaredField("_var23");
   field1.setAccessible(true);
   int _var23 = field1.getInt(polyupdate);
   field2 = examples.Polyupdate.class.getDeclaredField("_var426");
   field2.setAccessible(true);
   int _var426 = field2.getInt(polyupdate);
   // assertion removed: (_var23 == y) || (y != _var426);
}

@Test
public void llmTest20() throws Throwable {
    // Spec: FuzzedInvariant ( (Integer_Variable_0 > 0) or (Integer_Variable_1 < 1) ) holds for: <this._var426, orig(this._var426)>
    // Spec: (this._var426 > 0) or (old(this._var426) < 1)
   examples.Polyupdate polyupdate = new examples.Polyupdate();
   polyupdate.clear();
   java.lang.reflect.Field field = polyupdate.getClass().getDeclaredField("_var426");
   field.setAccessible(true);
   field.set(polyupdate, 1);

   polyupdate.a1(0);

}

@Test
public void llmTest21() throws Throwable {
    // Spec: FuzzedInvariant ( (Integer_Variable_0 > 0) or (Integer_Variable_1 < 1) ) holds for: <this._var426, orig(this._var426)>
    // Spec: (this._var426 > 0) or (old(this._var426) < 1)
   examples.Polyupdate polyupdate = new examples.Polyupdate();
   polyupdate.clear();
   java.lang.reflect.Field field = polyupdate.getClass().getDeclaredField("_var426");
   field.setAccessible(true);
   field.set(polyupdate, 1);

   polyupdate.a1(0);

   // assertion removed: (Integer)field.get(polyupdate) > 0 || (Integer)field.get(polyupdate) < 1;
}

@Test
public void llmTest22() throws Throwable {
    // Spec: FuzzedInvariant ( (Integer_Variable_0 > 1) or (Integer_Variable_1 >= 0) ) holds for: <this._var426, orig(this._var23)>
    // Spec: (this._var426 > 1) or (old(this._var23) >= 0)
   examples.Polyupdate polyupdate = new examples.Polyupdate();
   polyupdate.clear();
   java.lang.reflect.Field field1 = examples.Polyupdate.class.getDeclaredField("_var23");
   field1.setAccessible(true);
   field1.set(polyupdate, -1);
   java.lang.reflect.Field field2 = examples.Polyupdate.class.getDeclaredField("_var426");
   field2.setAccessible(true);
   field2.set(polyupdate, 0);
   polyupdate.a1(-2);

   boolean postcondition = (Integer)field2.get(polyupdate) > 1 || (Integer)field1.get(polyupdate) >= 0;
}

@Test
public void llmTest23() throws Throwable {
    // Spec: FuzzedInvariant ( (Integer_Variable_0 > 1) or (Integer_Variable_1 >= 0) ) holds for: <this._var426, orig(this._var23)>
    // Spec: (this._var426 > 1) or (old(this._var23) >= 0)
   examples.Polyupdate polyupdate = new examples.Polyupdate();
   polyupdate.clear();
   java.lang.reflect.Field field1 = examples.Polyupdate.class.getDeclaredField("_var23");
   field1.setAccessible(true);
   field1.set(polyupdate, -1);
   java.lang.reflect.Field field2 = examples.Polyupdate.class.getDeclaredField("_var426");
   field2.setAccessible(true);
   field2.set(polyupdate, 0);
   polyupdate.a1(-2);

   boolean postcondition = (Integer)field2.get(polyupdate) > 1 || (Integer)field1.get(polyupdate) >= 0;
   // assertion removed: postcondition;
}

@Test
public void llmTest24() throws Throwable {
    // Spec: FuzzedInvariant ( Integer_Variable_0 >= Integer_Variable_1 + Integer_Variable_2 ) holds for: <this._var23 , orig(y) , orig(this._var23)>
    // Spec: this._var23 >= old(y) + old(this._var23)
   examples.Polyupdate polyupdate = new examples.Polyupdate();
   polyupdate.getClass().getDeclaredField("_var23").setAccessible(true);
   polyupdate.getClass().getDeclaredField("_var23").set(polyupdate, 10);
   polyupdate.getClass().getDeclaredField("_var426").setAccessible(true);
   polyupdate.getClass().getDeclaredField("_var426").set(polyupdate, 20);
   int y = -5;

   polyupdate.a1(y);

   int var23 = (int) polyupdate.getClass().getDeclaredField("_var23").get(polyupdate);
}

@Test
public void llmTest25() throws Throwable {
    // Spec: FuzzedInvariant ( Integer_Variable_0 >= Integer_Variable_1 + Integer_Variable_2 ) holds for: <this._var23 , orig(y) , orig(this._var23)>
    // Spec: this._var23 >= old(y) + old(this._var23)
   examples.Polyupdate polyupdate = new examples.Polyupdate();
   polyupdate.getClass().getDeclaredField("_var23").setAccessible(true);
   polyupdate.getClass().getDeclaredField("_var23").set(polyupdate, 10);
   polyupdate.getClass().getDeclaredField("_var426").setAccessible(true);
   polyupdate.getClass().getDeclaredField("_var426").set(polyupdate, 20);
   int y = -5;

   polyupdate.a1(y);

   int var23 = (int) polyupdate.getClass().getDeclaredField("_var23").get(polyupdate);
   // assertion removed: y + 10;
}

@Test
public void llmTest26() throws Throwable {
    // Spec: FuzzedInvariant ( Integer_Variable_0 >= Integer_Variable_1 + Integer_Variable_2 ) holds for: <this._var23 , orig(y) , orig(this._var23)>
    // Spec: this._var23 >= old(y) + old(this._var23)
   examples.Polyupdate polyupdate = new examples.Polyupdate();
   int y = -5;

   polyupdate.a1(y);

}

@Test
public void llmTest27() throws Throwable {
    // Spec: FuzzedInvariant ( Integer_Variable_0 >= Integer_Variable_1 + Integer_Variable_2 ) holds for: <this._var23 , orig(y) , orig(this._var23)>
    // Spec: this._var23 >= old(y) + old(this._var23)
   examples.Polyupdate polyupdate = new examples.Polyupdate();
   int y = -5;

   polyupdate.a1(y);

   // assertion removed: 0 >= y; // this will fail
}

@Test
public void llmTest28() throws Throwable {
    // Spec: FuzzedInvariant ( (Integer_Variable_0 = Integer_Variable_1) implies (Integer_Variable_1 != -1) ) holds for: <this._var23, orig(this._var426)>
    // Spec: (this._var23 = old(this._var426)) implies (old(this._var426) != -1)
   examples.Polyupdate polyupdate = new examples.Polyupdate();
   polyupdate.clear();
   polyupdate.a1(-2);
}

@Test
public void llmTest29() throws Throwable {
    // Spec: FuzzedInvariant ( (Integer_Variable_0 = Integer_Variable_1) implies (Integer_Variable_1 != -1) ) holds for: <this._var23, orig(this._var426)>
    // Spec: (this._var23 = old(this._var426)) implies (old(this._var426) != -1)
   examples.Polyupdate polyupdate = new examples.Polyupdate();
   polyupdate.clear();
   polyupdate.a1(-2);
   // assertion removed: -1;
}

@Test
public void llmTest30() throws Throwable {
    // Spec: FuzzedInvariant ( (Integer_Variable_0 = Integer_Variable_1) implies (Integer_Variable_1 != -1) ) holds for: <this._var23, orig(this._var426)>
    // Spec: (this._var23 = old(this._var426)) implies (old(this._var426) != -1)
   examples.Polyupdate polyupdate = new examples.Polyupdate();
   java.lang.reflect.Field field1 = polyupdate.getClass().getDeclaredField("_var23");
   field1.setAccessible(true);
   field1.setInt(polyupdate, -1);
   java.lang.reflect.Field field2 = polyupdate.getClass().getDeclaredField("_var426");
   field2.setAccessible(true);
   field2.setInt(polyupdate, -1);
   polyupdate.a1(0);
}

@Test
public void llmTest31() throws Throwable {
    // Spec: FuzzedInvariant ( (Integer_Variable_0 = Integer_Variable_1) implies (Integer_Variable_1 != -1) ) holds for: <this._var23, orig(this._var426)>
    // Spec: (this._var23 = old(this._var426)) implies (old(this._var426) != -1)
   examples.Polyupdate polyupdate = new examples.Polyupdate();
   java.lang.reflect.Field field1 = polyupdate.getClass().getDeclaredField("_var23");
   field1.setAccessible(true);
   field1.setInt(polyupdate, -1);
   java.lang.reflect.Field field2 = polyupdate.getClass().getDeclaredField("_var426");
   field2.setAccessible(true);
   field2.setInt(polyupdate, -1);
   polyupdate.a1(0);
   // assertion removed: (int) field1.get(polyupdate) == (int) field2.get(polyupdate);
   // assertion removed: (int) field2.get(polyupdate) != -1;
}

@Test
public void llmTest32() throws Throwable {
    // Spec: FuzzedInvariant ( (Integer_Variable_0 = -1) implies (Integer_Variable_1 <= Integer_Variable_2) ) holds for: <this._var23 , orig(y) , orig(this._var426)>
    // Spec: (this._var23 = -1) implies (old(y) <= old(this._var426))
   examples.Polyupdate polyupdate = new examples.Polyupdate();
   polyupdate.clear();
   try {
       java.lang.reflect.Field _var23 = polyupdate.getClass().getDeclaredField("_var23");
       _var23.setAccessible(true);
       _var23.set(polyupdate, -1);
       java.lang.reflect.Field _var426 = polyupdate.getClass().getDeclaredField("_var426");
       _var426.setAccessible(true);
       _var426.set(polyupdate, 10);
   } catch (Exception e) {
   }
   int y = 10;

   polyupdate.a1(y);

   try {
       java.lang.reflect.Field _var23 = polyupdate.getClass().getDeclaredField("_var23");
       _var23.setAccessible(true);
       java.lang.reflect.Field _var426 = polyupdate.getClass().getDeclaredField("_var426");
       _var426.setAccessible(true);
   } catch (Exception e) {
   }
}

@Test
public void llmTest33() throws Throwable {
    // Spec: FuzzedInvariant ( (Integer_Variable_0 = -1) implies (Integer_Variable_1 <= Integer_Variable_2) ) holds for: <this._var23 , orig(y) , orig(this._var426)>
    // Spec: (this._var23 = -1) implies (old(y) <= old(this._var426))
   examples.Polyupdate polyupdate = new examples.Polyupdate();
   polyupdate.clear();
   try {
       java.lang.reflect.Field _var23 = polyupdate.getClass().getDeclaredField("_var23");
       _var23.setAccessible(true);
       _var23.set(polyupdate, -1);
       java.lang.reflect.Field _var426 = polyupdate.getClass().getDeclaredField("_var426");
       _var426.setAccessible(true);
       _var426.set(polyupdate, 10);
   } catch (Exception e) {
   }
   int y = 10;

   polyupdate.a1(y);

   try {
       java.lang.reflect.Field _var23 = polyupdate.getClass().getDeclaredField("_var23");
       _var23.setAccessible(true);
       java.lang.reflect.Field _var426 = polyupdate.getClass().getDeclaredField("_var426");
       _var426.setAccessible(true);
       // assertion removed: (_var23.get(polyupdate).equals(-1)) == (y <= (int)_var426.get(polyupdate));
   } catch (Exception e) {
   }
}

@Test
public void llmTest34() throws Throwable {
    // Spec: FuzzedInvariant ( (Integer_Variable_0 != 1) or (Integer_Variable_1 > Integer_Variable_2) ) holds for: <this._var426 , orig(y) , orig(this._var426)>
    // Spec: (this._var426 != 1) or (old(y) > old(this._var426))
   examples.Polyupdate polyupdate = new examples.Polyupdate();
   polyupdate.clear();
   polyupdate.a1(1);

}

@Test
public void llmTest35() throws Throwable {
    // Spec: FuzzedInvariant ( (Integer_Variable_0 != 1) or (Integer_Variable_1 > Integer_Variable_2) ) holds for: <this._var426 , orig(y) , orig(this._var426)>
    // Spec: (this._var426 != 1) or (old(y) > old(this._var426))
   examples.Polyupdate polyupdate = new examples.Polyupdate();
   polyupdate.clear();
   polyupdate.a1(1);

   // assertion removed: (polyupdate.sm() != 1);
}

@Test
public void llmTest36() throws Throwable {
    // Spec: FuzzedInvariant ( (Integer_Variable_0 >= 0) or (Integer_Variable_1 > 1) ) holds for: <this._var23, this._var426>
    // Spec: (this._var23 >= 0) or (this._var426 > 1)
   examples.Polyupdate polyupdate = new examples.Polyupdate();
   polyupdate.clear();
   polyupdate.getClass().getDeclaredField("_var23").setAccessible(true);
   polyupdate.getClass().getDeclaredField("_var23").set(polyupdate, -1);
   polyupdate.getClass().getDeclaredField("_var426").setAccessible(true);
   polyupdate.getClass().getDeclaredField("_var426").set(polyupdate, 1);

   polyupdate.a1(-2);

   polyupdate.getClass().getDeclaredField("_var23").setAccessible(true);
   polyupdate.getClass().getDeclaredField("_var426").setAccessible(true);
   boolean postcondition = ((int)polyupdate.getClass().getDeclaredField("_var23").get(polyupdate) >= 0) || ((int)polyupdate.getClass().getDeclaredField("_var426").get(polyupdate) > 1);
}

@Test
public void llmTest37() throws Throwable {
    // Spec: FuzzedInvariant ( (Integer_Variable_0 >= 0) or (Integer_Variable_1 > 1) ) holds for: <this._var23, this._var426>
    // Spec: (this._var23 >= 0) or (this._var426 > 1)
   examples.Polyupdate polyupdate = new examples.Polyupdate();
   polyupdate.clear();
   polyupdate.getClass().getDeclaredField("_var23").setAccessible(true);
   polyupdate.getClass().getDeclaredField("_var23").set(polyupdate, -1);
   polyupdate.getClass().getDeclaredField("_var426").setAccessible(true);
   polyupdate.getClass().getDeclaredField("_var426").set(polyupdate, 1);

   polyupdate.a1(-2);

   polyupdate.getClass().getDeclaredField("_var23").setAccessible(true);
   polyupdate.getClass().getDeclaredField("_var426").setAccessible(true);
   boolean postcondition = ((int)polyupdate.getClass().getDeclaredField("_var23").get(polyupdate) >= 0) || ((int)polyupdate.getClass().getDeclaredField("_var426").get(polyupdate) > 1);
   // assertion removed: postcondition;
}

@Test
public void llmTest38() throws Throwable {
    // Spec: FuzzedInvariant ( (Integer_Variable_0 = Integer_Variable_1) implies (Integer_Variable_1 <= 1) ) holds for: <this._var23, orig(this._var426)>
    // Spec: (this._var23 = old(this._var426)) implies (old(this._var426) <= 1)
   examples.Polyupdate polyupdate = new examples.Polyupdate();
   polyupdate.clear();
   polyupdate.a1(2);

}

@Test
public void llmTest39() throws Throwable {
    // Spec: FuzzedInvariant ( (Integer_Variable_0 = Integer_Variable_1) implies (Integer_Variable_1 <= 1) ) holds for: <this._var23, orig(this._var426)>
    // Spec: (this._var23 = old(this._var426)) implies (old(this._var426) <= 1)
   examples.Polyupdate polyupdate = new examples.Polyupdate();
   polyupdate.clear();
   polyupdate.a1(2);

   // assertion removed: !(polyupdate.sm() - polyupdate.sm() == polyupdate.sm()) || (polyupdate.sm() <= 1);
}

@Test
public void llmTest40() throws Throwable {
    // Spec: FuzzedInvariant ( (Integer_Variable_0 != 0) or (Integer_Variable_1 = Integer_Variable_2) ) holds for: <this._var426 , orig(y) , orig(this._var426)>
    // Spec: (this._var426 != 0) or (old(y) = old(this._var426))
   examples.Polyupdate polyupdate = new examples.Polyupdate();
   polyupdate.clear();
   java.lang.reflect.Field field = examples.Polyupdate.class.getDeclaredField("_var426");
   field.setAccessible(true);
   field.setInt(polyupdate, 10);
   int origY = 5;
   int origVar426 = field.getInt(polyupdate);

   polyupdate.a1(origY);

}

@Test
public void llmTest41() throws Throwable {
    // Spec: FuzzedInvariant ( (Integer_Variable_0 != 0) or (Integer_Variable_1 = Integer_Variable_2) ) holds for: <this._var426 , orig(y) , orig(this._var426)>
    // Spec: (this._var426 != 0) or (old(y) = old(this._var426))
   examples.Polyupdate polyupdate = new examples.Polyupdate();
   polyupdate.clear();
   java.lang.reflect.Field field = examples.Polyupdate.class.getDeclaredField("_var426");
   field.setAccessible(true);
   field.setInt(polyupdate, 10);
   int origY = 5;
   int origVar426 = field.getInt(polyupdate);

   polyupdate.a1(origY);

   // assertion removed: (field.getInt(polyupdate) != 0) || (origY == origVar426);
}

@Test
public void llmTest42() throws Throwable {
    // Spec: FuzzedInvariant ( (Integer_Variable_0 != Integer_Variable_1) or (Integer_Variable_1 > -1) ) holds for: <this._var23, this._var426>
    // Spec: (this._var23 != this._var426) or (this._var426 > -1)
   examples.Polyupdate polyupdate = new examples.Polyupdate();
   polyupdate.clear();
   java.lang.reflect.Field field1 = polyupdate.getClass().getDeclaredField("_var426");
   field1.setAccessible(true);
   field1.set(polyupdate, -1);
   polyupdate.a1(0);

   java.lang.reflect.Field field2 = polyupdate.getClass().getDeclaredField("_var23");
   field2.setAccessible(true);
   java.lang.reflect.Field field3 = polyupdate.getClass().getDeclaredField("_var426");
   field3.setAccessible(true);
}

@Test
public void llmTest43() throws Throwable {
    // Spec: FuzzedInvariant ( (Integer_Variable_0 != Integer_Variable_1) or (Integer_Variable_1 > -1) ) holds for: <this._var23, this._var426>
    // Spec: (this._var23 != this._var426) or (this._var426 > -1)
   examples.Polyupdate polyupdate = new examples.Polyupdate();
   polyupdate.clear();
   java.lang.reflect.Field field1 = polyupdate.getClass().getDeclaredField("_var426");
   field1.setAccessible(true);
   field1.set(polyupdate, -1);
   polyupdate.a1(0);

   java.lang.reflect.Field field2 = polyupdate.getClass().getDeclaredField("_var23");
   field2.setAccessible(true);
   java.lang.reflect.Field field3 = polyupdate.getClass().getDeclaredField("_var426");
   field3.setAccessible(true);
   // assertion removed: (field2.get(polyupdate) != field3.get(polyupdate)) || (Integer)field3.get(polyupdate) > -1;
}

@Test
public void llmTest44() throws Throwable {
    // Spec: FuzzedInvariant ( (Integer_Variable_0 >= -1) or (Integer_Variable_1 != Integer_Variable_2) ) holds for: <this._var426 , orig(y) , orig(this._var23)>
    // Spec: (this._var426 >= -1) or (old(y) != old(this._var23))
   examples.Polyupdate polyupdate = new examples.Polyupdate();
   polyupdate.clear();
   int y = -1;

   polyupdate.a1(y);

   boolean postcondition = (polyupdate.sm() >= -1) || (y != polyupdate.sm() - y);
} 

@Test
public void llmTest45() throws Throwable {
    // Spec: FuzzedInvariant ( (Integer_Variable_0 >= -1) or (Integer_Variable_1 != Integer_Variable_2) ) holds for: <this._var426 , orig(y) , orig(this._var23)>
    // Spec: (this._var426 >= -1) or (old(y) != old(this._var23))
   examples.Polyupdate polyupdate = new examples.Polyupdate();
   polyupdate.clear();
   int y = -1;

   polyupdate.a1(y);

   boolean postcondition = (polyupdate.sm() >= -1) || (y != polyupdate.sm() - y);
   // assertion removed: postcondition;
} 

@Test
public void llmTest46() throws Throwable {
    // Spec: FuzzedInvariant ( (Integer_Variable_0 != -1) or (Integer_Variable_1 >= 1) ) holds for: <this._var23, this._var426>
    // Spec: (this._var23 != -1) or (this._var426 >= 1)
   examples.Polyupdate polyupdate = new examples.Polyupdate();
   java.lang.reflect.Field field = polyupdate.getClass().getDeclaredField("_var23");
   field.setAccessible(true);
   field.setInt(polyupdate, -1);
   field = polyupdate.getClass().getDeclaredField("_var426");
   field.setAccessible(true);
   field.setInt(polyupdate, 0);
   polyupdate.a1(0);
   field = polyupdate.getClass().getDeclaredField("_var23");
   field.setAccessible(true);
   int var23 = field.getInt(polyupdate);
   field = polyupdate.getClass().getDeclaredField("_var426");
   field.setAccessible(true);
   int var426 = field.getInt(polyupdate);
}

@Test
public void llmTest47() throws Throwable {
    // Spec: FuzzedInvariant ( (Integer_Variable_0 != -1) or (Integer_Variable_1 >= 1) ) holds for: <this._var23, this._var426>
    // Spec: (this._var23 != -1) or (this._var426 >= 1)
   examples.Polyupdate polyupdate = new examples.Polyupdate();
   java.lang.reflect.Field field = polyupdate.getClass().getDeclaredField("_var23");
   field.setAccessible(true);
   field.setInt(polyupdate, -1);
   field = polyupdate.getClass().getDeclaredField("_var426");
   field.setAccessible(true);
   field.setInt(polyupdate, 0);
   polyupdate.a1(0);
   field = polyupdate.getClass().getDeclaredField("_var23");
   field.setAccessible(true);
   int var23 = field.getInt(polyupdate);
   field = polyupdate.getClass().getDeclaredField("_var426");
   field.setAccessible(true);
   int var426 = field.getInt(polyupdate);
   // assertion removed: (var23 != -1) || (var426 >= 1);
}