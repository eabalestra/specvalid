@Test
public void testCount_1() throws Throwable {
    // Spec: FuzzedInvariant ( (Integer_Variable_0 = 1) xor (Integer_Variable_1 > 0) ) holds for: <this.free, return>
    // Spec: (this.free = 1) xor (return > 0)
   examples.RingBuffer<String> ringBuffer = new examples.RingBuffer<>(5);
   ringBuffer.extend("Test");
   int result = ringBuffer.count();
}

@Test
public void testCount_1() throws Throwable {
    // Spec: FuzzedInvariant ( (Integer_Variable_0 = 1) xor (Integer_Variable_1 > 0) ) holds for: <this.free, return>
    // Spec: (this.free = 1) xor (return > 0)
   examples.RingBuffer<String> ringBuffer = new examples.RingBuffer<>(5);
   ringBuffer.extend("Test");
   int result = ringBuffer.count();
}

@Test
public void testCount_1() throws Throwable {
    // Spec: FuzzedInvariant ( Integer_Variable_0 >= Integer_Variable_1 + -1 ) holds for: <this.start, return>
    // Spec: this.start >= return + -1
   examples.RingBuffer<Integer> ringBuffer = new examples.RingBuffer<>(5);
   ringBuffer.extend(1);
   ringBuffer.extend(2);
   ringBuffer.extend(3);

   int result = ringBuffer.count();

}

@Test
public void testCount_1() throws Throwable {
    // Spec: FuzzedInvariant ( Integer_Variable_0 >= Integer_Variable_1 + -1 ) holds for: <this.start, return>
    // Spec: this.start >= return + -1
   examples.RingBuffer<Integer> ringBuffer = new examples.RingBuffer<>(5);
   ringBuffer.extend(1);
   ringBuffer.extend(2);
   ringBuffer.extend(3);

   int result = ringBuffer.count();

   // assertion removed: result <= ringBuffer.capacity();
}

@Test
public void testCount_1() throws Throwable {
    // Spec: FuzzedInvariant ( Integer_Variable_0 >= Integer_Variable_1 + -1 ) holds for: <this.start, return>
    // Spec: this.start >= return + -1
   examples.RingBuffer<Integer> ringBuffer = new examples.RingBuffer<>(5);
   ringBuffer.extend(1);
   ringBuffer.extend(2);
   ringBuffer.extend(3);

   int result = ringBuffer.count();

}

@Test
public void testCount_1() throws Throwable {
    // Spec: FuzzedInvariant ( Integer_Variable_0 >= Integer_Variable_1 + -1 ) holds for: <this.start, return>
    // Spec: this.start >= return + -1
   examples.RingBuffer<Integer> ringBuffer = new examples.RingBuffer<>(5);
   ringBuffer.extend(1);
   ringBuffer.extend(2);
   ringBuffer.extend(3);

   int result = ringBuffer.count();

   // assertion removed: result >= 0;
}

@Test
public void testCount_1() throws Throwable {
    // Spec: daikon.Quant.size(this.data) == 1
    // Spec: size(this.data) == 1
   examples.RingBuffer<String> buffer = new examples.RingBuffer<String>(5);
   buffer.extend("test");
   int count = buffer.count();
}

@Test
public void testCount_1() throws Throwable {
    // Spec: daikon.Quant.size(this.data) == 1
    // Spec: size(this.data) == 1
   examples.RingBuffer<String> buffer = new examples.RingBuffer<String>(5);
   buffer.extend("test");
   int count = buffer.count();
   // assertion removed: count;
}

@Test
public void testCount_1() throws Throwable {
    // Spec: FuzzedInvariant ( (Integer_Variable_0 < Integer_Variable_1) or (Integer_Variable_1 >= Integer_Variable_2) ) holds for: <this.start , this.free , return>
    // Spec: (this.start < this.free) or (this.free >= return)
   examples.RingBuffer<Integer> ringBuffer = new examples.RingBuffer<>(5);
   ringBuffer.extend(1);
   ringBuffer.extend(2);
   ringBuffer.extend(3);
   ringBuffer.extend(4);
   ringBuffer.extend(5);
   ringBuffer.remove();
   int result = ringBuffer.count();
}

@Test
public void testCount_1() throws Throwable {
    // Spec: FuzzedInvariant ( (Integer_Variable_0 < Integer_Variable_1) or (Integer_Variable_1 >= Integer_Variable_2) ) holds for: <this.start , this.free , return>
    // Spec: (this.start < this.free) or (this.free >= return)
   examples.RingBuffer<Integer> ringBuffer = new examples.RingBuffer<>(5);
   ringBuffer.extend(1);
   ringBuffer.extend(2);
   ringBuffer.extend(3);
   ringBuffer.extend(4);
   ringBuffer.extend(5);
   ringBuffer.remove();
   int result = ringBuffer.count();
   // assertion removed: (result < 0) || (result > ringBuffer.capacity());
}

@Test
public void testCount_1() throws Throwable {
    // Spec: FuzzedInvariant ( Integer_Variable_0 >= Integer_Variable_1 - Integer_Variable_2 ) holds for: <this.start , this.free , return>
    // Spec: this.start >= this.free - return
   examples.RingBuffer<String> buffer = new examples.RingBuffer<String>(5);
   buffer.extend("A");
   buffer.extend("B");
   buffer.remove();
   buffer.remove();
   buffer.wipeOut();
   int count = buffer.count();
}

@Test
public void testCount_1() throws Throwable {
    // Spec: FuzzedInvariant ( Integer_Variable_0 >= Integer_Variable_1 - Integer_Variable_2 ) holds for: <this.start , this.free , return>
    // Spec: this.start >= this.free - return
   examples.RingBuffer<String> buffer = new examples.RingBuffer<String>(5);
   buffer.extend("A");
   buffer.extend("B");
   buffer.remove();
   buffer.remove();
   buffer.wipeOut();
   int count = buffer.count();
   // assertion removed: count;
}

@Test
public void testCount_1() throws Throwable {
    // Spec: FuzzedInvariant ( (Integer_Variable_0 > Integer_Variable_1) xor (Integer_Variable_1 <= -1) ) holds for: <this.free, return>
    // Spec: (this.free > return) xor (return <= -1)
   examples.RingBuffer<Integer> ringBuffer = new examples.RingBuffer<>(5);
   ringBuffer.extend(1);
   ringBuffer.extend(2);
   ringBuffer.extend(3);

   int count = ringBuffer.count();

   boolean postcondition = (ringBuffer.capacity() > count) && (count >= 0);
} 

@Test
public void testCount_1() throws Throwable {
    // Spec: FuzzedInvariant ( (Integer_Variable_0 > Integer_Variable_1) xor (Integer_Variable_1 <= -1) ) holds for: <this.free, return>
    // Spec: (this.free > return) xor (return <= -1)
   examples.RingBuffer<Integer> ringBuffer = new examples.RingBuffer<>(5);
   ringBuffer.extend(1);
   ringBuffer.extend(2);
   ringBuffer.extend(3);

   int count = ringBuffer.count();

   boolean postcondition = (ringBuffer.capacity() > count) && (count >= 0);
   // assertion removed: postcondition;
} 

@Test
public void testCount_1() throws Throwable {
    // Spec: FuzzedInvariant ( (Integer_Variable_0 <= Integer_Variable_1) iff (Integer_Variable_1 > Integer_Variable_2) ) holds for: <this.start , this.free , return>
    // Spec: (this.start <= this.free) iff (this.free > return)
   examples.RingBuffer<String> buffer = new examples.RingBuffer<>(5);
   buffer.extend("A");
   buffer.extend("B");
   buffer.extend("C");
   buffer.extend("D");
   buffer.extend("E");
   buffer.remove();
   int count = buffer.count();
}

@Test
public void testCount_1() throws Throwable {
    // Spec: FuzzedInvariant ( (Integer_Variable_0 <= Integer_Variable_1) iff (Integer_Variable_1 > Integer_Variable_2) ) holds for: <this.start , this.free , return>
    // Spec: (this.start <= this.free) iff (this.free > return)
   examples.RingBuffer<String> buffer = new examples.RingBuffer<>(5);
   buffer.extend("A");
   buffer.extend("B");
   buffer.extend("C");
   buffer.extend("D");
   buffer.extend("E");
   buffer.remove();
   int count = buffer.count();
   buffer.isEmpty();
}

@Test
public void testCount_1() throws Throwable {
    // Spec: FuzzedInvariant ( (Integer_Variable_0 >= Integer_Variable_1) or (Integer_Variable_1 >= Integer_Variable_2) ) holds for: <this.start , this.free , return>
    // Spec: (this.start >= this.free) or (this.free >= return)
   examples.RingBuffer<Integer> ringBuffer = new examples.RingBuffer<>(5);
   ringBuffer.extend(1);
   ringBuffer.extend(2);
   ringBuffer.extend(3);

   int count = ringBuffer.count();

}

@Test
public void testCount_1() throws Throwable {
    // Spec: FuzzedInvariant ( (Integer_Variable_0 >= Integer_Variable_1) or (Integer_Variable_1 >= Integer_Variable_2) ) holds for: <this.start , this.free , return>
    // Spec: (this.start >= this.free) or (this.free >= return)
   examples.RingBuffer<Integer> ringBuffer = new examples.RingBuffer<>(5);
   ringBuffer.extend(1);
   ringBuffer.extend(2);
   ringBuffer.extend(3);

   int count = ringBuffer.count();

   // assertion removed: count <= ringBuffer.capacity();
}

@Test
public void testCount_1() throws Throwable {
    // Spec: FuzzedInvariant ( (Integer_Variable_0 >= Integer_Variable_1) or (Integer_Variable_1 >= Integer_Variable_2) ) holds for: <this.start , this.free , return>
    // Spec: (this.start >= this.free) or (this.free >= return)
   examples.RingBuffer<Integer> ringBuffer = new examples.RingBuffer<>(7);
   for (int i = 0; i < 7; i++) {
       ringBuffer.extend(i);
   }
   for (int i = 0; i < 6; i++) {
       ringBuffer.remove();
   }

   int count = ringBuffer.count();

}

@Test
public void testCount_1() throws Throwable {
    // Spec: FuzzedInvariant ( (Integer_Variable_0 >= Integer_Variable_1) or (Integer_Variable_1 >= Integer_Variable_2) ) holds for: <this.start , this.free , return>
    // Spec: (this.start >= this.free) or (this.free >= return)
   examples.RingBuffer<Integer> ringBuffer = new examples.RingBuffer<>(7);
   for (int i = 0; i < 7; i++) {
       ringBuffer.extend(i);
   }
   for (int i = 0; i < 6; i++) {
       ringBuffer.remove();
   }

   int count = ringBuffer.count();

   // assertion removed: count == 1;
}

@Test
public void testCount_1() throws Throwable {
    // Spec: FuzzedInvariant ( (Integer_Variable_0 <= Integer_Variable_1) iff (Integer_Variable_1 > Integer_Variable_2) ) holds for: <this.start , this.capacity_ , return>
    // Spec: (this.start <= this.capacity_) iff (this.capacity_ > return)
   examples.RingBuffer<Integer> ringBuffer = new examples.RingBuffer<>(5);
   ringBuffer.extend(1);
   ringBuffer.extend(2);
   ringBuffer.extend(3);
   ringBuffer.extend(4);
   ringBuffer.extend(5);

   int count = ringBuffer.count();

   boolean condition = ringBuffer.capacity() > count;

   if (!(ringBuffer.capacity() > count)) {
   }
}

@Test
public void testCount_1() throws Throwable {
    // Spec: FuzzedInvariant ( (Integer_Variable_0 <= Integer_Variable_1) iff (Integer_Variable_1 > Integer_Variable_2) ) holds for: <this.start , this.capacity_ , return>
    // Spec: (this.start <= this.capacity_) iff (this.capacity_ > return)
   examples.RingBuffer<Integer> ringBuffer = new examples.RingBuffer<>(5);
   ringBuffer.extend(1);
   ringBuffer.extend(2);
   ringBuffer.extend(3);
   ringBuffer.extend(4);
   ringBuffer.extend(5);

   int count = ringBuffer.count();

   boolean condition = ringBuffer.capacity() > count;

   if (!(ringBuffer.capacity() > count)) {
       org.junit.Assert.// fail removed;
   }
}

@Test
public void testCount_1() throws Throwable {
    // Spec: FuzzedInvariant ( Integer_Variable_0 >= Integer_Variable_1 / Integer_Variable_2 ) holds for: <this.start , this.free , this.capacity_>
    // Spec: this.start >= this.free / this.capacity_
   examples.RingBuffer<Integer> ringBuffer = new examples.RingBuffer<>(10);
   ringBuffer.extend(1);
   ringBuffer.extend(2);
   ringBuffer.extend(3);

   int count = ringBuffer.count();

}

@Test
public void testCount_1() throws Throwable {
    // Spec: FuzzedInvariant ( Integer_Variable_0 >= Integer_Variable_1 / Integer_Variable_2 ) holds for: <this.start , this.free , this.capacity_>
    // Spec: this.start >= this.free / this.capacity_
   examples.RingBuffer<Integer> ringBuffer = new examples.RingBuffer<>(10);
   ringBuffer.extend(1);
   ringBuffer.extend(2);
   ringBuffer.extend(3);

   int count = ringBuffer.count();

   // assertion removed: count >= ringBuffer.capacity();
}

@Test
public void testCount_1() throws Throwable {
    // Spec: FuzzedInvariant ( Integer_Variable_0 != #(examples.RingBuffer.data) ) holds for: <orig(this), return>
    // Spec: return != #(old(this).data)
   examples.RingBuffer<Integer> ringBuffer = new examples.RingBuffer<Integer>(5);
   ringBuffer.extend(1);
   ringBuffer.extend(2);
   ringBuffer.extend(3);

   int originalSize = ringBuffer.count();

   int result = ringBuffer.count();

}

@Test
public void testCount_1() throws Throwable {
    // Spec: FuzzedInvariant ( Integer_Variable_0 != #(examples.RingBuffer.data) ) holds for: <orig(this), return>
    // Spec: return != #(old(this).data)
   examples.RingBuffer<Integer> ringBuffer = new examples.RingBuffer<Integer>(5);
   ringBuffer.extend(1);
   ringBuffer.extend(2);
   ringBuffer.extend(3);

   int originalSize = ringBuffer.count();

   int result = ringBuffer.count();

   // assertion removed: 0;
}

@Test
public void testCount_1() throws Throwable {
    // Spec: daikon.Quant.size(this.data) == 1 || daikon.Quant.size(this.data) == 2 || daikon.Quant.size(this.data) == 3
    // Spec: size(this.data) == 1 || size(this.data) == 2 || size(this.data) == 3
   examples.RingBuffer<Integer> ringBuffer = new examples.RingBuffer<>(4);
   ringBuffer.extend(1);
   ringBuffer.extend(2);
   ringBuffer.extend(3);
   ringBuffer.extend(4);

   int count = ringBuffer.count();

}

@Test
public void testCount_1() throws Throwable {
    // Spec: daikon.Quant.size(this.data) == 1 || daikon.Quant.size(this.data) == 2 || daikon.Quant.size(this.data) == 3
    // Spec: size(this.data) == 1 || size(this.data) == 2 || size(this.data) == 3
   examples.RingBuffer<Integer> ringBuffer = new examples.RingBuffer<>(4);
   ringBuffer.extend(1);
   ringBuffer.extend(2);
   ringBuffer.extend(3);
   ringBuffer.extend(4);

   int count = ringBuffer.count();

   // assertion removed: ringBuffer;
   // assertion removed: ringBuffer.count() == 4;
}

@Test
public void testCount_1() throws Throwable {
    // Spec: FuzzedInvariant ( Integer_Variable_0 != Integer_Variable_1 - Integer_Variable_2 ) holds for: <this.start , this.free , this.capacity_>
    // Spec: this.start != this.free - this.capacity_
   examples.RingBuffer<String> ringBuffer = new examples.RingBuffer<>(1);
   ringBuffer.extend("test");

   int result = ringBuffer.count();

}

@Test
public void testCount_1() throws Throwable {
    // Spec: FuzzedInvariant ( Integer_Variable_0 != Integer_Variable_1 - Integer_Variable_2 ) holds for: <this.start , this.free , this.capacity_>
    // Spec: this.start != this.free - this.capacity_
   examples.RingBuffer<String> ringBuffer = new examples.RingBuffer<>(1);
   ringBuffer.extend("test");

   int result = ringBuffer.count();

   // assertion removed: result;
}

@Test
public void testCount() throws Throwable {
    // Spec: FuzzedInvariant ( (Integer_Variable_0 > Integer_Variable_1) xor (Integer_Variable_1 >= Integer_Variable_2) ) holds for: <this.free , this.capacity_ , return>
    // Spec: (this.free > this.capacity_) xor (this.capacity_ >= return)
    examples.RingBuffer<Integer> buffer = new examples.RingBuffer<>(5);
    for (int i = 0; i < 10; i++) {
        buffer.extend(i);
    }
    int count = buffer.count();
    boolean postcondition = (count <= buffer.capacity());
}

@Test
public void testCount() throws Throwable {
    // Spec: FuzzedInvariant ( (Integer_Variable_0 > Integer_Variable_1) xor (Integer_Variable_1 >= Integer_Variable_2) ) holds for: <this.free , this.capacity_ , return>
    // Spec: (this.free > this.capacity_) xor (this.capacity_ >= return)
    examples.RingBuffer<Integer> buffer = new examples.RingBuffer<>(5);
    for (int i = 0; i < 10; i++) {
        buffer.extend(i);
    }
    int count = buffer.count();
    boolean postcondition = (count <= buffer.capacity());
    // assertion removed: postcondition;
}

@Test
public void testCount_1() throws Throwable {
    // Spec: FuzzedInvariant ( Integer_Variable_0 < #(examples.RingBuffer.data) ) holds for: <orig(this), return>
    // Spec: return < #(old(this).data)
   examples.RingBuffer<Integer> buffer = new examples.RingBuffer<>(5);
   buffer.extend(1);
   buffer.extend(2);
   buffer.extend(3);
   int oldSize = buffer.count();
   buffer.remove();
   int result = buffer.count();
}

@Test
public void testCount_1() throws Throwable {
    // Spec: FuzzedInvariant ( Integer_Variable_0 < #(examples.RingBuffer.data) ) holds for: <orig(this), return>
    // Spec: return < #(old(this).data)
   examples.RingBuffer<Integer> buffer = new examples.RingBuffer<>(5);
   buffer.extend(1);
   buffer.extend(2);
   buffer.extend(3);
   int oldSize = buffer.count();
   buffer.remove();
   int result = buffer.count();
   // assertion removed: result;
}

@Test
public void testCount_1() throws Throwable {
    // Spec: FuzzedInvariant ( Integer_Variable_0 <= Integer_Variable_1 * Integer_Variable_2 ) holds for: <this.start , this.free , this.capacity_>
    // Spec: this.start <= this.free * this.capacity_
   examples.RingBuffer<Integer> ringBuffer = new examples.RingBuffer<>(5);
   ringBuffer.extend(1);
   ringBuffer.extend(2);
   ringBuffer.extend(3);
   ringBuffer.remove();
   int count = ringBuffer.count();
}

@Test
public void testCount_1() throws Throwable {
    // Spec: FuzzedInvariant ( Integer_Variable_0 <= Integer_Variable_1 * Integer_Variable_2 ) holds for: <this.start , this.free , this.capacity_>
    // Spec: this.start <= this.free * this.capacity_
   examples.RingBuffer<Integer> ringBuffer = new examples.RingBuffer<>(5);
   ringBuffer.extend(1);
   ringBuffer.extend(2);
   ringBuffer.extend(3);
   ringBuffer.remove();
   int count = ringBuffer.count();
   // assertion removed: count >= 0 && count <= ringBuffer.capacity();
}

    @Test
    public void testCount_1() throws Throwable {
    // Spec: this.start == 1
    // Spec: this.start == 1
        examples.RingBuffer<Integer> ringBuffer = new examples.RingBuffer<>(5);
        ringBuffer.extend(1);
        ringBuffer.extend(2);
        ringBuffer.extend(3);
        ringBuffer.remove();

        int result = ringBuffer.count();

    }

    @Test
    public void testCount_1() throws Throwable {
    // Spec: this.start == 1
    // Spec: this.start == 1
        examples.RingBuffer<Integer> ringBuffer = new examples.RingBuffer<>(5);
        ringBuffer.extend(1);
        ringBuffer.extend(2);
        ringBuffer.extend(3);
        ringBuffer.remove();

        int result = ringBuffer.count();

        Assert.// assertion removed: result;
    }

@Test
public void testCount_1() throws Throwable {
    // Spec: FuzzedInvariant ( (Integer_Variable_0 > 1) implies (Integer_Variable_1 > Integer_Variable_2) ) holds for: <this.start , this.free , return>
    // Spec: (this.start > 1) implies (this.free > return)
    examples.RingBuffer<Object> ringBuffer = new examples.RingBuffer<>(5);
    ringBuffer.extend(new Object());
    ringBuffer.extend(new Object());
    ringBuffer.extend(new Object());
    ringBuffer.remove();
    int result = ringBuffer.count();
    if (ringBuffer.count() < ringBuffer.capacity()) {
    }
}

@Test
public void testCount_1() throws Throwable {
    // Spec: FuzzedInvariant ( (Integer_Variable_0 > 1) implies (Integer_Variable_1 > Integer_Variable_2) ) holds for: <this.start , this.free , return>
    // Spec: (this.start > 1) implies (this.free > return)
    examples.RingBuffer<Object> ringBuffer = new examples.RingBuffer<>(5);
    ringBuffer.extend(new Object());
    ringBuffer.extend(new Object());
    ringBuffer.extend(new Object());
    ringBuffer.remove();
    int result = ringBuffer.count();
    if (ringBuffer.count() < ringBuffer.capacity()) {
        Assert.// assertion removed: ringBuffer.count() < ringBuffer.capacity();
    }
}

@Test
public void testCount_1() throws Throwable {
    // Spec: FuzzedInvariant ( (Integer_Variable_0 <= Integer_Variable_1) implies (Integer_Variable_1 != Integer_Variable_2) ) holds for: <this.start , this.free , return>
    // Spec: (this.start <= this.free) implies (this.free != return)
   examples.RingBuffer<Integer> ringBuffer = new examples.RingBuffer<>(5);
   ringBuffer.extend(1);
   ringBuffer.extend(2);
   ringBuffer.extend(3);
   ringBuffer.remove();
   int count = ringBuffer.count();
}

@Test
public void testCount_1() throws Throwable {
    // Spec: FuzzedInvariant ( (Integer_Variable_0 <= Integer_Variable_1) implies (Integer_Variable_1 != Integer_Variable_2) ) holds for: <this.start , this.free , return>
    // Spec: (this.start <= this.free) implies (this.free != return)
   examples.RingBuffer<Integer> ringBuffer = new examples.RingBuffer<>(5);
   ringBuffer.extend(1);
   ringBuffer.extend(2);
   ringBuffer.extend(3);
   ringBuffer.remove();
   int count = ringBuffer.count();
   // assertion removed: (ringBuffer.isEmpty() && count == 0) || (ringBuffer.isFull() && count == ringBuffer.capacity()) || (count > 0 && count < ringBuffer.capacity());
}

@Test
public void testCount_1() throws Throwable {
    // Spec: FuzzedInvariant ( Integer_Variable_0 = Integer_Variable_1 + 1 ) holds for: <this.free, return>
    // Spec: this.free = return + 1
   examples.RingBuffer<String> ringBuffer = new examples.RingBuffer<>(5);
   ringBuffer.extend("a");
   ringBuffer.extend("b");
   ringBuffer.extend("c");

   int result = ringBuffer.count();

}

@Test
public void testCount_1() throws Throwable {
    // Spec: FuzzedInvariant ( Integer_Variable_0 = Integer_Variable_1 + 1 ) holds for: <this.free, return>
    // Spec: this.free = return + 1
   examples.RingBuffer<String> ringBuffer = new examples.RingBuffer<>(5);
   ringBuffer.extend("a");
   ringBuffer.extend("b");
   ringBuffer.extend("c");

   int result = ringBuffer.count();

   // assertion removed: result + 1;
}

@Test
public void testCount_1() throws Throwable {
    // Spec: FuzzedInvariant ( Integer_Variable_0 > Integer_Variable_1 / -1 ) holds for: <this.start, return>
    // Spec: this.start > return / -1
   examples.RingBuffer<Integer> ringBuffer = new examples.RingBuffer<>(10);
   ringBuffer.extend(1);
   ringBuffer.extend(2);
   ringBuffer.extend(3);
   ringBuffer.remove();
   int result = ringBuffer.count();
}

@Test
public void testCount_1() throws Throwable {
    // Spec: FuzzedInvariant ( Integer_Variable_0 > Integer_Variable_1 / -1 ) holds for: <this.start, return>
    // Spec: this.start > return / -1
   examples.RingBuffer<Integer> ringBuffer = new examples.RingBuffer<>(10);
   ringBuffer.extend(1);
   ringBuffer.extend(2);
   ringBuffer.extend(3);
   ringBuffer.remove();
   int result = ringBuffer.count();
   // assertion removed: -1;
   // assertion removed: result < 0;
}

@Test
public void testCount_1() throws Throwable {
    // Spec: FuzzedInvariant ( Integer_Variable_0 > 0 ) holds for: this.free
    // Spec: this.free > 0
   examples.RingBuffer<Integer> ringBuffer = new examples.RingBuffer<>(5);
   ringBuffer.extend(1);
   ringBuffer.extend(2);
   ringBuffer.extend(3);
   ringBuffer.extend(4);
   ringBuffer.extend(5);
   ringBuffer.remove();
   ringBuffer.remove();
   ringBuffer.remove();
   ringBuffer.remove();
   ringBuffer.remove();

   int result = ringBuffer.count();

   boolean postcondition = ringBuffer.isEmpty();
}

@Test
public void testCount_1() throws Throwable {
    // Spec: FuzzedInvariant ( Integer_Variable_0 > 0 ) holds for: this.free
    // Spec: this.free > 0
   examples.RingBuffer<Integer> ringBuffer = new examples.RingBuffer<>(5);
   ringBuffer.extend(1);
   ringBuffer.extend(2);
   ringBuffer.extend(3);
   ringBuffer.extend(4);
   ringBuffer.extend(5);
   ringBuffer.remove();
   ringBuffer.remove();
   ringBuffer.remove();
   ringBuffer.remove();
   ringBuffer.remove();

   int result = ringBuffer.count();

   boolean postcondition = ringBuffer.isEmpty();
   // assertion removed: postcondition;
}

@Test
public void testCount_1() throws Throwable {
    // Spec: FuzzedInvariant ( Integer_Variable_0 > Integer_Variable_1 - Integer_Variable_2 ) holds for: <this.start , this.free , this.capacity_>
    // Spec: this.start > this.free - this.capacity_
   examples.RingBuffer<Integer> ringBuffer = new examples.RingBuffer<>(10);
   ringBuffer.extend(1);
   ringBuffer.extend(2);
   ringBuffer.extend(3);
   ringBuffer.remove();
   ringBuffer.remove();
}

@Test
public void testCount_1() throws Throwable {
    // Spec: FuzzedInvariant ( Integer_Variable_0 > Integer_Variable_1 - Integer_Variable_2 ) holds for: <this.start , this.free , this.capacity_>
    // Spec: this.start > this.free - this.capacity_
   examples.RingBuffer<Integer> ringBuffer = new examples.RingBuffer<>(10);
   ringBuffer.extend(1);
   ringBuffer.extend(2);
   ringBuffer.extend(3);
   ringBuffer.remove();
   ringBuffer.remove();
   // assertion removed: ringBuffer.count() == 1;
}

@Test
public void testCount_1() throws Throwable {
    // Spec: FuzzedInvariant ( (Integer_Variable_0 < Integer_Variable_1) iff (Integer_Variable_1 < -1) ) holds for: <this.free, return>
    // Spec: (this.free < return) iff (return < -1)
   examples.RingBuffer<Integer> buffer = new examples.RingBuffer<>(5);
   buffer.extend(1);
   buffer.extend(2);
   buffer.extend(3);

   int count = buffer.count();

   boolean condition = buffer.isEmpty() || buffer.isFull();
}

@Test
public void testCount_1() throws Throwable {
    // Spec: FuzzedInvariant ( (Integer_Variable_0 < Integer_Variable_1) iff (Integer_Variable_1 < -1) ) holds for: <this.free, return>
    // Spec: (this.free < return) iff (return < -1)
   examples.RingBuffer<Integer> buffer = new examples.RingBuffer<>(5);
   buffer.extend(1);
   buffer.extend(2);
   buffer.extend(3);

   int count = buffer.count();

   boolean condition = buffer.isEmpty() || buffer.isFull();
   // assertion removed: condition;
}