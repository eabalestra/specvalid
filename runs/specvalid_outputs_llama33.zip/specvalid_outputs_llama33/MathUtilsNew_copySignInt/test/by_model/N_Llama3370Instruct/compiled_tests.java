@Test
public void testCopySignInt_1() throws Throwable {
    // Spec: FuzzedInvariant ( (Integer_Variable_0 < 1) or (Integer_Variable_1 != 0) ) holds for: <orig(magnitude), return>
    // Spec: (old(magnitude) < 1) or (return != 0)
   int magnitude = 0;
   int sign = 1;

   int result = org.apache.commons.math3.util.MathUtilsNew.copySignInt(magnitude, sign);

}

@Test
public void testCopySignInt_1() throws Throwable {
    // Spec: FuzzedInvariant ( (Integer_Variable_0 < 1) or (Integer_Variable_1 != 0) ) holds for: <orig(magnitude), return>
    // Spec: (old(magnitude) < 1) or (return != 0)
   int magnitude = 0;
   int sign = 1;

   int result = org.apache.commons.math3.util.MathUtilsNew.copySignInt(magnitude, sign);

   // assertion removed: (magnitude < 1) || (result != 0);
}