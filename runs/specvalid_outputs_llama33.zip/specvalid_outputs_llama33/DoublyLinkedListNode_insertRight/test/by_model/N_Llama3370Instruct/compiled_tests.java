    @Test
    public void testInsertRight_1() throws Throwable {
    // Spec: this.left == this.right
    // Spec: this.left == this.right
        examples.DoublyLinkedListNode node = new examples.DoublyLinkedListNode();
        examples.DoublyLinkedListNode n = new examples.DoublyLinkedListNode();

        node.insertRight(n);

    }

    @Test
    public void testInsertRight_1() throws Throwable {
    // Spec: this.left == this.right
    // Spec: this.left == this.right
        examples.DoublyLinkedListNode node = new examples.DoublyLinkedListNode();
        examples.DoublyLinkedListNode n = new examples.DoublyLinkedListNode();

        node.insertRight(n);

        // assertion removed: node == n;
    }

@Test
public void testInsertRight_1() throws Throwable {
    // Spec: n.left == \old(this.left.right)
    // Spec: n.left == old(this.left.right)
   examples.DoublyLinkedListNode node = new examples.DoublyLinkedListNode();
   examples.DoublyLinkedListNode n = new examples.DoublyLinkedListNode();

   examples.DoublyLinkedListNode origNode = node;

   node.insertRight(n);

}

@Test
public void testInsertRight_1() throws Throwable {
    // Spec: n.left == \old(this.left.right)
    // Spec: n.left == old(this.left.right)
   examples.DoublyLinkedListNode node = new examples.DoublyLinkedListNode();
   examples.DoublyLinkedListNode n = new examples.DoublyLinkedListNode();

   examples.DoublyLinkedListNode origNode = node;

   node.insertRight(n);

   // assertion removed: origNode;
}

@Test
public void testInsertRight_1() throws Throwable {
    // Spec: this.right == \old(n)
    // Spec: this.right == old(n)
   examples.DoublyLinkedListNode node = new examples.DoublyLinkedListNode();
   examples.DoublyLinkedListNode n = new examples.DoublyLinkedListNode();

   examples.DoublyLinkedListNode origN = n;

   node.insertRight(n);

}

@Test
public void testInsertRight_1() throws Throwable {
    // Spec: this.right == \old(n)
    // Spec: this.right == old(n)
   examples.DoublyLinkedListNode node = new examples.DoublyLinkedListNode();
   examples.DoublyLinkedListNode n = new examples.DoublyLinkedListNode();

   examples.DoublyLinkedListNode origN = n;

   node.insertRight(n);

   // assertion removed: origN;
}