@Test
public void llmTest0() throws Throwable {
    // Spec: daikon.Quant.size(this.keys) == \old(daikon.Quant.size(this.keys))-1
    // Spec: size(this.keys) == old(size(this.keys))-1
    examples.Map<String, String> map = new examples.Map<>();

    // extend adds a key; indexOfKey uses 0-based indices
    map.extend("a", "v1");
    int oldSize = map.count(); // size of keys is 1

    // remove the existing key "a"
    int result = map.remove("a");

    // After remove, keys.remove(result) is called with result = 0
    // but indexOfKey returns 0 for the first element, while LinkedList indexes are 0-based.
    // However, the Eiffel-style spec in comments assumed 1-based; the given postcondition
    // expects size(this.keys) == old(size(this.keys)) - 1.
    int newSize = map.count();

    // This assertion encodes the postcondition and is expected to fail
}

@Test
public void llmTest1() throws Throwable {
    // Spec: daikon.Quant.size(this.keys) == \old(daikon.Quant.size(this.keys))-1
    // Spec: size(this.keys) == old(size(this.keys))-1
    examples.Map<String, String> map = new examples.Map<>();

    // extend adds a key; indexOfKey uses 0-based indices
    map.extend("a", "v1");
    int oldSize = map.count(); // size of keys is 1

    // remove the existing key "a"
    int result = map.remove("a");

    // After remove, keys.remove(result) is called with result = 0
    // but indexOfKey returns 0 for the first element, while LinkedList indexes are 0-based.
    // However, the Eiffel-style spec in comments assumed 1-based; the given postcondition
    // expects size(this.keys) == old(size(this.keys)) - 1.
    int newSize = map.count();

    // This assertion encodes the postcondition and is expected to fail
    // assertion removed: newSize == oldSize - 1;
}