@Test
public void testCompare_1() throws Throwable {
    // Spec: FuzzedInvariant ( (Boolean_Variable_0) implies (Integer_Variable_0 >= 0) ) holds for: <orig(x), return>
    // Spec: (old(x)) implies (return >= 0)
   lang3.BooleanUtils booleanUtils = new lang3.BooleanUtils();
   boolean x = false;
   boolean y = true;

   int result = booleanUtils.compare(x, y);

   if (!x) {
       assertTrue(result >= 0);
   }
}

@Test
public void testCompare_1() throws Throwable {
    // Spec: FuzzedInvariant ( (Boolean_Variable_0) implies (Integer_Variable_0 >= 0) ) holds for: <orig(x), return>
    // Spec: (old(x)) implies (return >= 0)
   lang3.BooleanUtils booleanUtils = new lang3.BooleanUtils();
   boolean x = false;
   boolean y = true;

   int result = booleanUtils.compare(x, y);

   if (!x) {
       // assertion removed: result >= 0;
   }
}