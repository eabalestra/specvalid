@Test
public void testMakeEmpty_1() throws Throwable {
    // Spec: daikon.Quant.eltsEqual(daikon.Quant.typeArray(this.theArray), null)
    // Spec: eltsEqual(typeArray(this.theArray), null)
   DataStructures.StackAr stack = new DataStructures.StackAr(10);

   stack.push("test");
   stack.makeEmpty();

   boolean eltsEqual = true;
   for (int i = 0; i < 10; i++) {
       if (stack.topAndPop() != null) {
           eltsEqual = false;
           break;
       }
   }
}

@Test
public void testMakeEmpty_1() throws Throwable {
    // Spec: daikon.Quant.eltsEqual(daikon.Quant.typeArray(this.theArray), null)
    // Spec: eltsEqual(typeArray(this.theArray), null)
   DataStructures.StackAr stack = new DataStructures.StackAr(10);

   stack.push("test");
   stack.makeEmpty();

   boolean eltsEqual = true;
   for (int i = 0; i < 10; i++) {
       if (stack.topAndPop() != null) {
           eltsEqual = false;
           break;
       }
   }
   // assertion removed: eltsEqual;
}