@Test
public void testInsert_r_1() throws Throwable {
    // Spec: daikon.Quant.size(this._var49) == 1 || daikon.Quant.size(this._var49) == 2 || daikon.Quant.size(this._var49) == 3
    // Spec: size(this._var49) == 1 || size(this._var49) == 2 || size(this._var49) == 3
   examples.ListComp02 listComp02 = new examples.ListComp02();
   examples.R r1 = new examples.R(1, "r1");
   examples.R r2 = new examples.R(2, "r2");
   examples.R r3 = new examples.R(3, "r3");
   examples.R r4 = new examples.R(4, "r4");

   listComp02.insert_r(r1);
   listComp02.insert_r(r2);
   listComp02.insert_r(r3);
   listComp02.insert_r(r4);

   assertFalse(listComp02.q() == 1 || listComp02.q() == 2 || listComp02.q() == 3);
}

@Test
public void testInsert_r_1() throws Throwable {
    // Spec: daikon.Quant.size(this._var49) == 1 || daikon.Quant.size(this._var49) == 2 || daikon.Quant.size(this._var49) == 3
    // Spec: size(this._var49) == 1 || size(this._var49) == 2 || size(this._var49) == 3
   examples.ListComp02 listComp02 = new examples.ListComp02();
   examples.R r1 = new examples.R(1, "r1");
   examples.R r2 = new examples.R(2, "r2");
   examples.R r3 = new examples.R(3, "r3");
   examples.R r4 = new examples.R(4, "r4");

   listComp02.insert_r(r1);
   listComp02.insert_r(r2);
   listComp02.insert_r(r3);
   listComp02.insert_r(r4);

   // assertion removed: listComp02.q() == 1 || listComp02.q() == 2 || listComp02.q() == 3;
}