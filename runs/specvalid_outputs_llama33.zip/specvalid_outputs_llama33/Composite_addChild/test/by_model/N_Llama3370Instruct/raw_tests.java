    @Test
    public void testAddChild_1() throws Throwable {
    // Spec: daikon.Quant.pairwiseEqual(daikon.Quant.typeArray(this.parent.children), new String[] { "examples.Composite" }) || daikon.Quant.pairwiseEqual(daikon.Quant.typeArray(this.parent.children), new String[] { "examples.Composite", "examples.Composite" })
    // Spec: pairwiseEqual(typeArray(this.parent.children), new String[] { "examples.Composite" }) || pairwiseEqual(typeArray(this.parent.children), new String[] { "examples.Composite", "examples.Composite" })
        examples.Composite parent = new examples.Composite(1);
        examples.Composite child1 = new examples.Composite(2);
        examples.Composite child2 = new examples.Composite(3);
        examples.Composite child3 = new examples.Composite(4);

        parent.addChild(child1);
        parent.addChild(child2);
        parent.addChild(child3);

        java.util.Set<examples.Composite> childrenSet = parent.children();
        assertEquals(3, childrenSet.size());
        for (examples.Composite child : childrenSet) {
            assertTrue(child instanceof examples.Composite);
        }
    }

    @Test
    public void testAddChild_1() throws Throwable {
    // Spec: daikon.Quant.pairwiseEqual(daikon.Quant.typeArray(this.parent.children), new String[] { "examples.Composite" }) || daikon.Quant.pairwiseEqual(daikon.Quant.typeArray(this.parent.children), new String[] { "examples.Composite", "examples.Composite" })
    // Spec: pairwiseEqual(typeArray(this.parent.children), new String[] { "examples.Composite" }) || pairwiseEqual(typeArray(this.parent.children), new String[] { "examples.Composite", "examples.Composite" })
        examples.Composite parent = new examples.Composite(1);
        examples.Composite child1 = new examples.Composite(2);
        examples.Composite child2 = new examples.Composite(3);
        examples.Composite child3 = new examples.Composite(4);

        parent.addChild(child1);
        parent.addChild(child2);
        parent.addChild(child3);

        java.util.Set<examples.Composite> childrenSet = parent.children();
        childrenSet.size();
        for (examples.Composite child : childrenSet) {
            // assertion removed: child instanceof examples.Composite;
        }
    }

@Test
public void testAddChild_1() throws Throwable {
    // Spec: c.value == c.init_value
    // Spec: c.value == c.init_value
   examples.Composite parent = new examples.Composite(1);
   examples.Composite child = new examples.Composite(2);

   parent.addChild(child);

   assertEquals(2, child.init_value);
}

@Test
public void testAddChild_1() throws Throwable {
    // Spec: c.value == c.init_value
    // Spec: c.value == c.init_value
   examples.Composite parent = new examples.Composite(1);
   examples.Composite child = new examples.Composite(2);

   parent.addChild(child);

   // assertion removed: child.init_value;
}

@Test
public void testAddChild_1() throws Throwable {
    // Spec: daikon.Quant.size(this.children) == 1 || daikon.Quant.size(this.children) == 2 || daikon.Quant.size(this.children) == 3
    // Spec: size(this.children) == 1 || size(this.children) == 2 || size(this.children) == 3
   examples.Composite parent = new examples.Composite(1);
   examples.Composite child1 = new examples.Composite(2);
   examples.Composite child2 = new examples.Composite(3);
   examples.Composite child3 = new examples.Composite(4);
   examples.Composite child4 = new examples.Composite(5);

   parent.addChild(child1);
   parent.addChild(child2);
   parent.addChild(child3);
   parent.addChild(child4);

   assertTrue(parent.children().size() == 1 || parent.children().size() == 2 || parent.children().size() == 3);
} 

@Test
public void testAddChild_1() throws Throwable {
    // Spec: daikon.Quant.size(this.children) == 1 || daikon.Quant.size(this.children) == 2 || daikon.Quant.size(this.children) == 3
    // Spec: size(this.children) == 1 || size(this.children) == 2 || size(this.children) == 3
   examples.Composite parent = new examples.Composite(1);
   examples.Composite child1 = new examples.Composite(2);
   examples.Composite child2 = new examples.Composite(3);
   examples.Composite child3 = new examples.Composite(4);
   examples.Composite child4 = new examples.Composite(5);

   parent.addChild(child1);
   parent.addChild(child2);
   parent.addChild(child3);
   parent.addChild(child4);

   // assertion removed: parent.children().size() == 1 || parent.children().size() == 2 || parent.children().size() == 3;
} 