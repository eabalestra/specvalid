    @Test
    public void testAddElementToSet_1() throws Throwable {
    // Spec: FuzzedInvariant ( Integer_Variable_0 in Integer_Set_Variable_0 ) holds for: <orig(intSet), orig(element)>
    // Spec: old(intSet) in old(element)
        examples.SimpleMethods simpleMethods = new examples.SimpleMethods();
        HashSet<Integer> intSet = new HashSet<>(Arrays.asList(1, 2, 3));
        int element = 4;

        simpleMethods.addElementToSet(intSet, element);

    }

    @Test
    public void testAddElementToSet_1() throws Throwable {
    // Spec: FuzzedInvariant ( Integer_Variable_0 in Integer_Set_Variable_0 ) holds for: <orig(intSet), orig(element)>
    // Spec: old(intSet) in old(element)
        examples.SimpleMethods simpleMethods = new examples.SimpleMethods();
        HashSet<Integer> intSet = new HashSet<>(Arrays.asList(1, 2, 3));
        int element = 4;

        simpleMethods.addElementToSet(intSet, element);

        intSet.contains(element);
    }