@Test
public void testMod_1() throws Throwable {
    // Spec: FuzzedInvariant ( (Integer_Variable_0 > 1) or (Integer_Variable_1 >= Integer_Variable_2) ) holds for: <orig(x) , orig(m) , return>
    // Spec: (old(x) > 1) or (old(m) >= return)
   math.IntMath intMath = new math.IntMath();
   int x = 1;
   int m = 1;

   int result = intMath.mod(x, m);

   assertTrue((x > 1) || (m >= result));
}

@Test
public void testMod_1() throws Throwable {
    // Spec: FuzzedInvariant ( (Integer_Variable_0 > 1) or (Integer_Variable_1 >= Integer_Variable_2) ) holds for: <orig(x) , orig(m) , return>
    // Spec: (old(x) > 1) or (old(m) >= return)
   math.IntMath intMath = new math.IntMath();
   int x = 1;
   int m = 1;

   int result = intMath.mod(x, m);

   // assertion removed: (x > 1) || (m >= result);
}

@Test
public void testMod_1() throws Throwable {
    // Spec: FuzzedInvariant ( (Integer_Variable_0 = -1) implies (Integer_Variable_1 > 1) ) holds for: <orig(x), return>
    // Spec: (old(x) = -1) implies (return > 1)
   math.IntMath intMath = new math.IntMath();
   int x = -1;
   int m = 2;


   int result = intMath.mod(x, m);


   if (x == -1) {
       assertTrue(result > 1);
   }
}

@Test
public void testMod_1() throws Throwable {
    // Spec: FuzzedInvariant ( (Integer_Variable_0 = -1) implies (Integer_Variable_1 > 1) ) holds for: <orig(x), return>
    // Spec: (old(x) = -1) implies (return > 1)
   math.IntMath intMath = new math.IntMath();
   int x = -1;
   int m = 2;


   int result = intMath.mod(x, m);


   if (x == -1) {
       // assertion removed: result > 1;
   }
}

@Test
public void testMod_1() throws Throwable {
    // Spec: FuzzedInvariant ( (Integer_Variable_0 < Integer_Variable_1) implies (Integer_Variable_1 > Integer_Variable_2) ) holds for: <orig(x) , orig(m) , return>
    // Spec: (old(x) < old(m)) implies (old(m) > return)
   math.IntMath intMath = new math.IntMath();
   int x = 3;
   int m = 5;
   int origX = x;
   int origM = m;

   int result = intMath.mod(x, m);

   if (origX < origM) {
       assertTrue(origM > result);
   }
}

@Test
public void testMod_1() throws Throwable {
    // Spec: FuzzedInvariant ( (Integer_Variable_0 < Integer_Variable_1) implies (Integer_Variable_1 > Integer_Variable_2) ) holds for: <orig(x) , orig(m) , return>
    // Spec: (old(x) < old(m)) implies (old(m) > return)
   math.IntMath intMath = new math.IntMath();
   int x = 3;
   int m = 5;
   int origX = x;
   int origM = m;

   int result = intMath.mod(x, m);

   if (origX < origM) {
       // assertion removed: origM > result;
   }
}

@Test
public void testMod_1() throws Throwable {
    // Spec: FuzzedInvariant ( (Integer_Variable_0 < Integer_Variable_1) implies (Integer_Variable_1 > Integer_Variable_2) ) holds for: <orig(x) , orig(m) , return>
    // Spec: (old(x) < old(m)) implies (old(m) > return)
   math.IntMath intMath = new math.IntMath();
   int x = 4;
   int m = 5;
   int origX = x;
   int origM = m;

   int result = intMath.mod(x, m);

   if (origX < origM) {
       assertTrue(origM > result);
   }
} 

@Test
public void testMod_1() throws Throwable {
    // Spec: FuzzedInvariant ( (Integer_Variable_0 < Integer_Variable_1) implies (Integer_Variable_1 > Integer_Variable_2) ) holds for: <orig(x) , orig(m) , return>
    // Spec: (old(x) < old(m)) implies (old(m) > return)
   math.IntMath intMath = new math.IntMath();
   int x = 4;
   int m = 5;
   int origX = x;
   int origM = m;

   int result = intMath.mod(x, m);

   if (origX < origM) {
       // assertion removed: origM > result;
   }
} 

@Test
public void testMod_1() throws Throwable {
    // Spec: FuzzedInvariant ( (Integer_Variable_0 < Integer_Variable_1) implies (Integer_Variable_1 > Integer_Variable_2) ) holds for: <orig(x) , orig(m) , return>
    // Spec: (old(x) < old(m)) implies (old(m) > return)
   math.IntMath intMath = new math.IntMath();
   int x = 4;
   int m = 5;
   int origX = x;
   int origM = m;

   int result = intMath.mod(x, m);

   if (origX < origM) {
       assertTrue(origM > result);
   }
} 

@Test
public void testMod_1() throws Throwable {
    // Spec: FuzzedInvariant ( (Integer_Variable_0 < Integer_Variable_1) implies (Integer_Variable_1 > Integer_Variable_2) ) holds for: <orig(x) , orig(m) , return>
    // Spec: (old(x) < old(m)) implies (old(m) > return)
   math.IntMath intMath = new math.IntMath();
   int x = 4;
   int m = 5;
   int origX = x;
   int origM = m;

   int result = intMath.mod(x, m);

   if (origX < origM) {
       // assertion removed: origM > result;
   }
} 

@Test
public void testMod_1() throws Throwable {
    // Spec: FuzzedInvariant ( (Integer_Variable_0 < Integer_Variable_1) implies (Integer_Variable_1 > Integer_Variable_2) ) holds for: <orig(x) , orig(m) , return>
    // Spec: (old(x) < old(m)) implies (old(m) > return)
   math.IntMath intMath = new math.IntMath();
   int x = 4;
   int m = 5;
   int origX = x;
   int origM = m;

   int result = intMath.mod(x, m);

   if (origX < origM) {
       assertTrue(origM > result);
   }
} 

@Test
public void testMod_1() throws Throwable {
    // Spec: FuzzedInvariant ( (Integer_Variable_0 < Integer_Variable_1) implies (Integer_Variable_1 > Integer_Variable_2) ) holds for: <orig(x) , orig(m) , return>
    // Spec: (old(x) < old(m)) implies (old(m) > return)
   math.IntMath intMath = new math.IntMath();
   int x = 4;
   int m = 5;
   int origX = x;
   int origM = m;

   int result = intMath.mod(x, m);

   if (origX < origM) {
       // assertion removed: origM > result;
   }
} 

@Test
public void testMod_1() throws Throwable {
    // Spec: FuzzedInvariant ( (Integer_Variable_0 = Integer_Variable_1) iff (Integer_Variable_1 <= -1) ) holds for: <orig(m), return>
    // Spec: (old(m) = return) iff (return <= -1)
   math.IntMath intMath = new math.IntMath();
   int x = 7;
   int m = 4;
   int oldM = m;

   int result = intMath.mod(x, m);

   assertFalse((oldM == result) == (result <= -1));
}

@Test
public void testMod_1() throws Throwable {
    // Spec: FuzzedInvariant ( (Integer_Variable_0 = Integer_Variable_1) iff (Integer_Variable_1 <= -1) ) holds for: <orig(m), return>
    // Spec: (old(m) = return) iff (return <= -1)
   math.IntMath intMath = new math.IntMath();
   int x = 7;
   int m = 4;
   int oldM = m;

   int result = intMath.mod(x, m);

   // assertion removed: (oldM == result) == (result <= -1);
}

@Test
public void testMod_1() throws Throwable {
    // Spec: FuzzedInvariant ( (Integer_Variable_0 > Integer_Variable_1) or (Integer_Variable_1 != Integer_Variable_2) ) holds for: <orig(x) , orig(m) , return>
    // Spec: (old(x) > old(m)) or (old(m) != return)
   math.IntMath intMath = new math.IntMath();
   int x = 1;
   int m = 1;

   int result = intMath.mod(x, m);

   assertTrue((x > m) || (m != result));
}

@Test
public void testMod_1() throws Throwable {
    // Spec: FuzzedInvariant ( (Integer_Variable_0 > Integer_Variable_1) or (Integer_Variable_1 != Integer_Variable_2) ) holds for: <orig(x) , orig(m) , return>
    // Spec: (old(x) > old(m)) or (old(m) != return)
   math.IntMath intMath = new math.IntMath();
   int x = 1;
   int m = 1;

   int result = intMath.mod(x, m);

   // assertion removed: (x > m) || (m != result);
}

@Test
public void testMod_1() throws Throwable {
    // Spec: FuzzedInvariant ( (Integer_Variable_0 != Integer_Variable_1) or (Integer_Variable_1 >= Integer_Variable_2) ) holds for: <orig(x) , orig(m) , return>
    // Spec: (old(x) != old(m)) or (old(m) >= return)
   math.IntMath intMath = new math.IntMath();
   int x = 7;
   int m = 7;

   int result = intMath.mod(x, m);

   assertTrue((x != m) || (m >= result));
}

@Test
public void testMod_1() throws Throwable {
    // Spec: FuzzedInvariant ( (Integer_Variable_0 != Integer_Variable_1) or (Integer_Variable_1 >= Integer_Variable_2) ) holds for: <orig(x) , orig(m) , return>
    // Spec: (old(x) != old(m)) or (old(m) >= return)
   math.IntMath intMath = new math.IntMath();
   int x = 7;
   int m = 7;

   int result = intMath.mod(x, m);

   // assertion removed: (x != m) || (m >= result);
}

@Test
public void testMod_1() throws Throwable {
    // Spec: FuzzedInvariant ( Integer_Variable_0 >= Integer_Variable_1 + 1 ) holds for: <orig(m), return>
    // Spec: old(m) >= return + 1
   math.IntMath intMath = new math.IntMath();
   int x = 1;
   int m = 1;

   int result = intMath.mod(x, m);

   assertFalse(result >= m);
}

@Test
public void testMod_1() throws Throwable {
    // Spec: FuzzedInvariant ( Integer_Variable_0 >= Integer_Variable_1 + 1 ) holds for: <orig(m), return>
    // Spec: old(m) >= return + 1
   math.IntMath intMath = new math.IntMath();
   int x = 1;
   int m = 1;

   int result = intMath.mod(x, m);

   // assertion removed: result >= m;
}

@Test
public void testMod_1() throws Throwable {
    // Spec: FuzzedInvariant ( Integer_Variable_0 >= Integer_Variable_1 + 1 ) holds for: <orig(m), return>
    // Spec: old(m) >= return + 1
   math.IntMath intMath = new math.IntMath();
   int x = 1;
   int m = 1;
   int origM = m;

   int result = intMath.mod(x, m);

   assertFalse(origM >= result + 1);
}

@Test
public void testMod_1() throws Throwable {
    // Spec: FuzzedInvariant ( Integer_Variable_0 >= Integer_Variable_1 + 1 ) holds for: <orig(m), return>
    // Spec: old(m) >= return + 1
   math.IntMath intMath = new math.IntMath();
   int x = 1;
   int m = 1;
   int origM = m;

   int result = intMath.mod(x, m);

   // assertion removed: origM >= result + 1;
}

@Test
public void testMod_1() throws Throwable {
    // Spec: FuzzedInvariant ( (Integer_Variable_0 = -1) or (Integer_Variable_1 != Integer_Variable_2) ) holds for: <orig(x) , orig(m) , return>
    // Spec: (old(x) = -1) or (old(m) != return)
   math.IntMath intMath = new math.IntMath();
   int x = -1;
   int m = 1;
   int origX = x;

   int result = intMath.mod(x, m);

   if (origX == -1) {
       assertNotEquals(origX, result);
   } else {
       assertFalse(origX == -1 || origX != result);
   }
}

@Test
public void testMod_1() throws Throwable {
    // Spec: FuzzedInvariant ( (Integer_Variable_0 = -1) or (Integer_Variable_1 != Integer_Variable_2) ) holds for: <orig(x) , orig(m) , return>
    // Spec: (old(x) = -1) or (old(m) != return)
   math.IntMath intMath = new math.IntMath();
   int x = -1;
   int m = 1;
   int origX = x;

   int result = intMath.mod(x, m);

   if (origX == -1) {
       // assertion removed: result;
   } else {
       // assertion removed: origX == -1 || origX != result;
   }
}

@Test
public void testMod_1() throws Throwable {
    // Spec: FuzzedInvariant ( (Integer_Variable_0 <= Integer_Variable_1) iff (Integer_Variable_1 <= -1) ) holds for: <orig(m), return>
    // Spec: (old(m) <= return) iff (return <= -1)
   math.IntMath intMath = new math.IntMath();
   int x = 7;
   int m = 4;

   int result = intMath.mod(x, m);

   boolean oldMLessThanReturn = (m <= result);
   boolean returnLessThanMinusOne = (result <= -1);
   assertTrue(oldMLessThanReturn == returnLessThanMinusOne);
} 

@Test
public void testMod_1() throws Throwable {
    // Spec: FuzzedInvariant ( (Integer_Variable_0 <= Integer_Variable_1) iff (Integer_Variable_1 <= -1) ) holds for: <orig(m), return>
    // Spec: (old(m) <= return) iff (return <= -1)
   math.IntMath intMath = new math.IntMath();
   int x = 7;
   int m = 4;

   int result = intMath.mod(x, m);

   boolean oldMLessThanReturn = (m <= result);
   boolean returnLessThanMinusOne = (result <= -1);
   // assertion removed: oldMLessThanReturn == returnLessThanMinusOne;
} 

@Test
public void testMod_1() throws Throwable {
    // Spec: FuzzedInvariant ( (Integer_Variable_0 = 1) implies (Integer_Variable_1 > Integer_Variable_2) ) holds for: <orig(x) , orig(m) , return>
    // Spec: (old(x) = 1) implies (old(m) > return)
   math.IntMath intMath = new math.IntMath();
   int x = 1;
   int m = 1;

   int result = intMath.mod(x, m);

   if (x == 1) {
       assertTrue(m > result);
   }
}

@Test
public void testMod_1() throws Throwable {
    // Spec: FuzzedInvariant ( (Integer_Variable_0 = 1) implies (Integer_Variable_1 > Integer_Variable_2) ) holds for: <orig(x) , orig(m) , return>
    // Spec: (old(x) = 1) implies (old(m) > return)
   math.IntMath intMath = new math.IntMath();
   int x = 1;
   int m = 1;

   int result = intMath.mod(x, m);

   if (x == 1) {
       // assertion removed: m > result;
   }
}

@Test
public void testMod_1() throws Throwable {
    // Spec: FuzzedInvariant ( (Integer_Variable_0 = Integer_Variable_1) iff (Integer_Variable_1 < -1) ) holds for: <orig(m), return>
    // Spec: (old(m) = return) iff (return < -1)
   math.IntMath intMath = new math.IntMath();
   int x = 7;
   int m = 5;
   int origM = m;

   int result = intMath.mod(x, m);

   assertFalse((origM == result) == (result < -1));
}

@Test
public void testMod_1() throws Throwable {
    // Spec: FuzzedInvariant ( (Integer_Variable_0 = Integer_Variable_1) iff (Integer_Variable_1 < -1) ) holds for: <orig(m), return>
    // Spec: (old(m) = return) iff (return < -1)
   math.IntMath intMath = new math.IntMath();
   int x = 7;
   int m = 5;
   int origM = m;

   int result = intMath.mod(x, m);

   // assertion removed: (origM == result) == (result < -1);
}

@Test
public void testMod_1() throws Throwable {
    // Spec: FuzzedInvariant ( (Integer_Variable_0 >= 1) or (Integer_Variable_1 > Integer_Variable_2) ) holds for: <orig(x) , orig(m) , return>
    // Spec: (old(x) >= 1) or (old(m) > return)
   math.IntMath intMath = new math.IntMath();
   int x = 0;
   int m = 1;
   int origX = x;

   int result = intMath.mod(x, m);

   if (origX >= 1) {
       assertTrue(true);
   } else {
       assertTrue(m > result);
   }
}

@Test
public void testMod_1() throws Throwable {
    // Spec: FuzzedInvariant ( (Integer_Variable_0 >= 1) or (Integer_Variable_1 > Integer_Variable_2) ) holds for: <orig(x) , orig(m) , return>
    // Spec: (old(x) >= 1) or (old(m) > return)
   math.IntMath intMath = new math.IntMath();
   int x = 0;
   int m = 1;
   int origX = x;

   int result = intMath.mod(x, m);

   if (origX >= 1) {
       // assertion removed: true;
   } else {
       // assertion removed: m > result;
   }
}

@Test
public void testMod_1() throws Throwable {
    // Spec: FuzzedInvariant ( (Integer_Variable_0 >= -1) or (Integer_Variable_1 > Integer_Variable_2) ) holds for: <orig(x) , orig(m) , return>
    // Spec: (old(x) >= -1) or (old(m) > return)
   math.IntMath intMath = new math.IntMath();
   int x = -2;
   int m = 1;
   int origX = x;

   int result = intMath.mod(x, m);

   assertTrue((origX >= -1) || (m > result));
}

@Test
public void testMod_1() throws Throwable {
    // Spec: FuzzedInvariant ( (Integer_Variable_0 >= -1) or (Integer_Variable_1 > Integer_Variable_2) ) holds for: <orig(x) , orig(m) , return>
    // Spec: (old(x) >= -1) or (old(m) > return)
   math.IntMath intMath = new math.IntMath();
   int x = -2;
   int m = 1;
   int origX = x;

   int result = intMath.mod(x, m);

   // assertion removed: (origX >= -1) || (m > result);
}