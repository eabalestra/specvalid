@Test
public void testMakeEmpty_1() throws Throwable {
    // Spec: FuzzedInvariant ( (Integer_Variable_0 >= Integer_Variable_1) or (Integer_Variable_1 = 0) ) holds for: <this.back, orig(this.back)>
    // Spec: (this.back >= old(this.back)) or (old(this.back) = 0)
   DataStructures.QueueAr queue = new DataStructures.QueueAr(10);
   queue.enqueue("item1");
   queue.enqueue("item2");

   int origSize = queue.currentSize();

   queue.makeEmpty();

}

@Test
public void testMakeEmpty_1() throws Throwable {
    // Spec: FuzzedInvariant ( (Integer_Variable_0 >= Integer_Variable_1) or (Integer_Variable_1 = 0) ) holds for: <this.back, orig(this.back)>
    // Spec: (this.back >= old(this.back)) or (old(this.back) = 0)
   DataStructures.QueueAr queue = new DataStructures.QueueAr(10);
   queue.enqueue("item1");
   queue.enqueue("item2");

   int origSize = queue.currentSize();

   queue.makeEmpty();

   queue.isEmpty();
}

@Test
public void testMakeEmpty_1() throws Throwable {
    // Spec: FuzzedInvariant ( (Integer_Variable_0 >= Integer_Variable_1) or (Integer_Variable_1 != 0) ) holds for: <this.back, orig(this.back)>
    // Spec: (this.back >= old(this.back)) or (old(this.back) != 0)
   DataStructures.QueueAr queue = new DataStructures.QueueAr(10);
   queue.enqueue("item1");
   queue.makeEmpty();
}

@Test
public void testMakeEmpty_1() throws Throwable {
    // Spec: FuzzedInvariant ( (Integer_Variable_0 >= Integer_Variable_1) or (Integer_Variable_1 != 0) ) holds for: <this.back, orig(this.back)>
    // Spec: (this.back >= old(this.back)) or (old(this.back) != 0)
   DataStructures.QueueAr queue = new DataStructures.QueueAr(10);
   queue.enqueue("item1");
   queue.makeEmpty();
   queue.isEmpty();
}

@Test
public void testMakeEmpty_1() throws Throwable {
    // Spec: FuzzedInvariant ( (Integer_Variable_0 >= Integer_Variable_1) or (Integer_Variable_1 != 0) ) holds for: <this.back, orig(this.back)>
    // Spec: (this.back >= old(this.back)) or (old(this.back) != 0)
   DataStructures.QueueAr queue = new DataStructures.QueueAr(10);
   queue.enqueue("item1");
   queue.makeEmpty();
}

@Test
public void testMakeEmpty_1() throws Throwable {
    // Spec: FuzzedInvariant ( (Integer_Variable_0 >= Integer_Variable_1) or (Integer_Variable_1 != 0) ) holds for: <this.back, orig(this.back)>
    // Spec: (this.back >= old(this.back)) or (old(this.back) != 0)
   DataStructures.QueueAr queue = new DataStructures.QueueAr(10);
   queue.enqueue("item1");
   queue.makeEmpty();
   queue.isEmpty(); 
}

@Test
public void testMakeEmpty() throws Throwable {
    // Spec: FuzzedInvariant ( (Integer_Variable_0 != -1) iff (Integer_Variable_1 >= Integer_Variable_2) ) holds for: <orig(this.front) , this.back , orig(this.back)>
    // Spec: (old(this.front) != -1) iff (this.back >= old(this.back))
   DataStructures.QueueAr queue = new DataStructures.QueueAr(5);
   queue.enqueue("A");
   queue.enqueue("B");
   queue.enqueue("C");

   queue.makeEmpty();

}

@Test
public void testMakeEmpty() throws Throwable {
    // Spec: FuzzedInvariant ( (Integer_Variable_0 != -1) iff (Integer_Variable_1 >= Integer_Variable_2) ) holds for: <orig(this.front) , this.back , orig(this.back)>
    // Spec: (old(this.front) != -1) iff (this.back >= old(this.back))
   DataStructures.QueueAr queue = new DataStructures.QueueAr(5);
   queue.enqueue("A");
   queue.enqueue("B");
   queue.enqueue("C");

   queue.makeEmpty();

   queue.isEmpty();
}

@Test
public void testMakeEmpty() throws Throwable {
    // Spec: FuzzedInvariant ( Integer_Variable_0 >= Integer_Variable_1 + -1 ) holds for: <this.back, orig(this.back)>
    // Spec: this.back >= old(this.back) + -1
   DataStructures.QueueAr queue = new DataStructures.QueueAr(10);
   queue.enqueue("item1");
   int origSize = queue.isEmpty() ? 0 : 1;

   queue.makeEmpty();

}

@Test
public void testMakeEmpty() throws Throwable {
    // Spec: FuzzedInvariant ( Integer_Variable_0 >= Integer_Variable_1 + -1 ) holds for: <this.back, orig(this.back)>
    // Spec: this.back >= old(this.back) + -1
   DataStructures.QueueAr queue = new DataStructures.QueueAr(10);
   queue.enqueue("item1");
   int origSize = queue.isEmpty() ? 0 : 1;

   queue.makeEmpty();

}

@Test
public void testMakeEmpty() throws Throwable {
    // Spec: FuzzedInvariant ( (Integer_Variable_0 = 1) or (Integer_Variable_1 >= Integer_Variable_2) ) holds for: <this.currentSize , this.back , orig(this.back)>
    // Spec: (this.currentSize = 1) or (this.back >= old(this.back))
   DataStructures.QueueAr queue = new DataStructures.QueueAr(10);
   queue.enqueue("Item");

   queue.makeEmpty();

}

@Test
public void testMakeEmpty() throws Throwable {
    // Spec: FuzzedInvariant ( (Integer_Variable_0 = 1) or (Integer_Variable_1 >= Integer_Variable_2) ) holds for: <this.currentSize , this.back , orig(this.back)>
    // Spec: (this.currentSize = 1) or (this.back >= old(this.back))
   DataStructures.QueueAr queue = new DataStructures.QueueAr(10);
   queue.enqueue("Item");

   queue.makeEmpty();

}

@Test
public void testMakeEmpty() throws Throwable {
    // Spec: FuzzedInvariant ( Integer_Variable_0 >= Integer_Variable_1 * Integer_Variable_2 ) holds for: <this.currentSize , orig(this.front) , orig(this.currentSize)>
    // Spec: this.currentSize >= old(this.front) * old(this.currentSize)
   DataStructures.QueueAr queue = new DataStructures.QueueAr(10);
   queue.enqueue("item1");
   queue.enqueue("item2");

   int origCurrentSize = queue.currentSize; // since currentSize is not public method

   queue.makeEmpty();

}

@Test
public void testMakeEmpty() throws Throwable {
    // Spec: FuzzedInvariant ( Integer_Variable_0 >= Integer_Variable_1 * Integer_Variable_2 ) holds for: <this.currentSize , orig(this.front) , orig(this.currentSize)>
    // Spec: this.currentSize >= old(this.front) * old(this.currentSize)
   DataStructures.QueueAr queue = new DataStructures.QueueAr(10);
   queue.enqueue("item1");
   queue.enqueue("item2");

   int origCurrentSize = queue.currentSize; // since currentSize is not public method

   queue.makeEmpty();

   queue.isEmpty();
}

@Test
public void testMakeEmpty() throws Throwable {
    // Spec: FuzzedInvariant ( (Integer_Variable_0 >= Integer_Variable_1) or (Integer_Variable_1 >= Integer_Variable_2) ) holds for: <orig(this.front) , this.back , orig(this.back)>
    // Spec: (old(this.front) >= this.back) or (this.back >= old(this.back))
   DataStructures.QueueAr queue = new DataStructures.QueueAr(10);
   queue.enqueue("item1");
   queue.enqueue("item2");

   queue.makeEmpty();

}

@Test
public void testMakeEmpty() throws Throwable {
    // Spec: FuzzedInvariant ( (Integer_Variable_0 >= Integer_Variable_1) or (Integer_Variable_1 >= Integer_Variable_2) ) holds for: <orig(this.front) , this.back , orig(this.back)>
    // Spec: (old(this.front) >= this.back) or (this.back >= old(this.back))
   DataStructures.QueueAr queue = new DataStructures.QueueAr(10);
   queue.enqueue("item1");
   queue.enqueue("item2");

   queue.makeEmpty();

   queue.isEmpty();
}

@Test
public void testMakeEmpty_1() throws Throwable {
    // Spec: FuzzedInvariant ( Integer_Variable_0 = Integer_Variable_1 * Integer_Variable_2 ) holds for: <this.currentSize , orig(this.front) , orig(this.currentSize)>
    // Spec: this.currentSize = old(this.front) * old(this.currentSize)
   DataStructures.QueueAr queue = new DataStructures.QueueAr(10);
   queue.enqueue("item1");
   queue.enqueue("item2");

   int origCurrentSize = queue.currentSize; 

   queue.makeEmpty();

}

@Test
public void testMakeEmpty_1() throws Throwable {
    // Spec: FuzzedInvariant ( Integer_Variable_0 = Integer_Variable_1 * Integer_Variable_2 ) holds for: <this.currentSize , orig(this.front) , orig(this.currentSize)>
    // Spec: this.currentSize = old(this.front) * old(this.currentSize)
   DataStructures.QueueAr queue = new DataStructures.QueueAr(10);
   queue.enqueue("item1");
   queue.enqueue("item2");

   int origCurrentSize = queue.currentSize; 

   queue.makeEmpty();

   // assertion removed: 0; 
}

@Test
public void testMakeEmpty_1() throws Throwable {
    // Spec: FuzzedInvariant ( (Integer_Variable_0 < Integer_Variable_1) or (Integer_Variable_1 <= 1) ) holds for: <orig(this.front), this.back>
    // Spec: (old(this.front) < this.back) or (this.back <= 1)
   DataStructures.QueueAr queue = new DataStructures.QueueAr(10);

   queue.enqueue("Test");
   queue.makeEmpty();

}

@Test
public void testMakeEmpty_1() throws Throwable {
    // Spec: FuzzedInvariant ( (Integer_Variable_0 < Integer_Variable_1) or (Integer_Variable_1 <= 1) ) holds for: <orig(this.front), this.back>
    // Spec: (old(this.front) < this.back) or (this.back <= 1)
   DataStructures.QueueAr queue = new DataStructures.QueueAr(10);

   queue.enqueue("Test");
   queue.makeEmpty();

}

@Test
public void testMakeEmpty_1() throws Throwable {
    // Spec: FuzzedInvariant ( (Integer_Variable_0 = 0) or (Integer_Variable_1 > 1) ) holds for: <orig(this.front), this.back>
    // Spec: (old(this.front) = 0) or (this.back > 1)
   DataStructures.QueueAr queue = new DataStructures.QueueAr(2);
   queue.enqueue("A");
   queue.enqueue("B");

   queue.makeEmpty();

}

@Test
public void testMakeEmpty_1() throws Throwable {
    // Spec: FuzzedInvariant ( (Integer_Variable_0 = 0) or (Integer_Variable_1 > 1) ) holds for: <orig(this.front), this.back>
    // Spec: (old(this.front) = 0) or (this.back > 1)
   DataStructures.QueueAr queue = new DataStructures.QueueAr(2);
   queue.enqueue("A");
   queue.enqueue("B");

   queue.makeEmpty();

   queue.isEmpty();
}

@Test
public void testMakeEmpty_1() throws Throwable {
    // Spec: FuzzedInvariant ( (Integer_Variable_0 = -1) implies (Integer_Variable_1 >= Integer_Variable_2) ) holds for: <this.back , orig(this.currentSize) , orig(this.back)>
    // Spec: (this.back = -1) implies (old(this.currentSize) >= old(this.back))
   DataStructures.QueueAr queue = new DataStructures.QueueAr(10);
   queue.enqueue("test");
   queue.makeEmpty();
}

@Test
public void testMakeEmpty_1() throws Throwable {
    // Spec: FuzzedInvariant ( (Integer_Variable_0 = -1) implies (Integer_Variable_1 >= Integer_Variable_2) ) holds for: <this.back , orig(this.currentSize) , orig(this.back)>
    // Spec: (this.back = -1) implies (old(this.currentSize) >= old(this.back))
   DataStructures.QueueAr queue = new DataStructures.QueueAr(10);
   queue.enqueue("test");
   queue.makeEmpty();
   queue.isEmpty();
}