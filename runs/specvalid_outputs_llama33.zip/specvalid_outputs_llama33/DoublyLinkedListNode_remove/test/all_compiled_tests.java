    @Test
    public void llmTest0() throws Throwable {
    // Spec: FuzzedInvariant ( no n : examples.DoublyLinkedListNode.^(left + right) : (n.right.*(left + right)) & (n.right.*(left + right)) in empty ) holds for: this
    // Spec: no n : examples.DoublyLinkedListNode.^(left + right) : (n.right.*(left + right)) & (n.right.*(left + right)) in empty
        // Build a two-node circular doubly linked list: a <-> b
        examples.DoublyLinkedListNode a = new examples.DoublyLinkedListNode();
        examples.DoublyLinkedListNode b = new examples.DoublyLinkedListNode();

        // Manually connect them to form a 2‑cycle
        // a.right = b; a.left = b; b.right = a; b.left = a;
        // (We must set via reflection because setters are private)
        try {
            java.lang.reflect.Method setRight =
                examples.DoublyLinkedListNode.class.getDeclaredMethod("setRight", examples.DoublyLinkedListNode.class);
            java.lang.reflect.Method setLeft =
                examples.DoublyLinkedListNode.class.getDeclaredMethod("setLeft", examples.DoublyLinkedListNode.class);
            setRight.setAccessible(true);
            setLeft.setAccessible(true);

            setRight.invoke(a, b);
            setLeft.invoke(a, b);
            setRight.invoke(b, a);
            setLeft.invoke(b, a);
        } catch (Exception e) {
        }

        // Now remove node a from the list
        a.remove();

        // Helper methods to read private fields via reflection
        java.util.function.Function<examples.DoublyLinkedListNode, examples.DoublyLinkedListNode> getLeftFn =
            node -> {
                try {
                    java.lang.reflect.Field f =
                        examples.DoublyLinkedListNode.class.getDeclaredField("left");
                    f.setAccessible(true);
                    return (examples.DoublyLinkedListNode) f.get(node);
                } catch (Exception e) {
                    throw new RuntimeException(e);
                }
            };

        java.util.function.Function<examples.DoublyLinkedListNode, examples.DoublyLinkedListNode> getRightFn =
            node -> {
                try {
                    java.lang.reflect.Field f =
                        examples.DoublyLinkedListNode.class.getDeclaredField("right");
                    f.setAccessible(true);
                    return (examples.DoublyLinkedListNode) f.get(node);
                } catch (Exception e) {
                    throw new RuntimeException(e);
                }
            };

        // After remove, a is singleton, and b is also singleton (b.left = b, b.right = b).
        boolean aSingleton =
            getLeftFn.apply(a) == a && getRightFn.apply(a) == a;
        boolean bSingleton =
            getLeftFn.apply(b) == b && getRightFn.apply(b) == b;
        boolean distinct = a != b;

        // This conjunction witnesses a violation of the postcondition.
        // If the postcondition held, this should be impossible.
    }

    @Test
    public void llmTest1() throws Throwable {
    // Spec: this.left == this.left.right.right
    // Spec: this.left == this.left.right.right
        // Build a circular list of three nodes: n1 <-> n2 <-> n3 <-> n1
        examples.DoublyLinkedListNode n1 = new examples.DoublyLinkedListNode();
        examples.DoublyLinkedListNode n2 = new examples.DoublyLinkedListNode();
        examples.DoublyLinkedListNode n3 = new examples.DoublyLinkedListNode();

        // Manually link them using reflection to access private fields
        try {
            java.lang.reflect.Field leftField =
                examples.DoublyLinkedListNode.class.getDeclaredField("left");
            java.lang.reflect.Field rightField =
                examples.DoublyLinkedListNode.class.getDeclaredField("right");
            leftField.setAccessible(true);
            rightField.setAccessible(true);

            // n1 <-> n2
            rightField.set(n1, n2);
            leftField.set(n2, n1);

            // n2 <-> n3
            rightField.set(n2, n3);
            leftField.set(n3, n2);

            // n3 <-> n1 (close the circle)
            rightField.set(n3, n1);
            leftField.set(n1, n3);
        } catch (Exception e) {
        }

        // Remove n2 from the list
        n2.remove();

        // Postcondition under test:
        // this.left == this.left.right.right
        // Here "this" is n2 (the removed node)
        try {
            java.lang.reflect.Field leftField =
                examples.DoublyLinkedListNode.class.getDeclaredField("left");
            java.lang.reflect.Field rightField =
                examples.DoublyLinkedListNode.class.getDeclaredField("right");
            leftField.setAccessible(true);
            rightField.setAccessible(true);

            examples.DoublyLinkedListNode leftOfN2 =
                (examples.DoublyLinkedListNode) leftField.get(n2);
            examples.DoublyLinkedListNode rightOfLeft =
                (examples.DoublyLinkedListNode) rightField.get(leftOfN2);
            examples.DoublyLinkedListNode rightRightOfLeft =
                (examples.DoublyLinkedListNode) rightField.get(rightOfLeft);

            // This assertion encodes the (incorrect) postcondition.
            // It must fail to demonstrate the counterexample.
        } catch (Exception e) {
        }
    }

    @Test
    public void llmTest2() throws Throwable {
    // Spec: this.left == this.left.right.right
    // Spec: this.left == this.left.right.right
        // Build a circular list of three nodes: n1 <-> n2 <-> n3 <-> n1
        examples.DoublyLinkedListNode n1 = new examples.DoublyLinkedListNode();
        examples.DoublyLinkedListNode n2 = new examples.DoublyLinkedListNode();
        examples.DoublyLinkedListNode n3 = new examples.DoublyLinkedListNode();

        // Manually link them using reflection to access private fields
        try {
            java.lang.reflect.Field leftField =
                examples.DoublyLinkedListNode.class.getDeclaredField("left");
            java.lang.reflect.Field rightField =
                examples.DoublyLinkedListNode.class.getDeclaredField("right");
            leftField.setAccessible(true);
            rightField.setAccessible(true);

            // n1 <-> n2
            rightField.set(n1, n2);
            leftField.set(n2, n1);

            // n2 <-> n3
            rightField.set(n2, n3);
            leftField.set(n3, n2);

            // n3 <-> n1 (close the circle)
            rightField.set(n3, n1);
            leftField.set(n1, n3);
        } catch (Exception e) {
        }

        // Remove n2 from the list
        n2.remove();

        // Postcondition under test:
        // this.left == this.left.right.right
        // Here "this" is n2 (the removed node)
        try {
            java.lang.reflect.Field leftField =
                examples.DoublyLinkedListNode.class.getDeclaredField("left");
            java.lang.reflect.Field rightField =
                examples.DoublyLinkedListNode.class.getDeclaredField("right");
            leftField.setAccessible(true);
            rightField.setAccessible(true);

            examples.DoublyLinkedListNode leftOfN2 =
                (examples.DoublyLinkedListNode) leftField.get(n2);
            examples.DoublyLinkedListNode rightOfLeft =
                (examples.DoublyLinkedListNode) rightField.get(leftOfN2);
            examples.DoublyLinkedListNode rightRightOfLeft =
                (examples.DoublyLinkedListNode) rightField.get(rightOfLeft);

            // This assertion encodes the (incorrect) postcondition.
            // It must fail to demonstrate the counterexample.
            // assertion removed: leftOfN2 == rightRightOfLeft;
        } catch (Exception e) {
        }
    }