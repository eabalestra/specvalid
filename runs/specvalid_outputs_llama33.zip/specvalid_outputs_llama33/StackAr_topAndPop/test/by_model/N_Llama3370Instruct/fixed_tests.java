@Test
public void testTopAndPop_1() throws Throwable {
    // Spec: FuzzedInvariant ( (Integer_Variable_0 = 0) iff (Integer_Variable_1 != 0) ) holds for: <this.topOfStack, orig(this.topOfStack)>
    // Spec: (this.topOfStack = 0) iff (old(this.topOfStack) != 0)
   DataStructures.StackAr stack = new DataStructures.StackAr(10);
   stack.push("item1");
   stack.push("item2");
   boolean origIsEmpty = stack.isEmpty();

   Object result = stack.topAndPop();

   if (stack.isEmpty()) {
   } else {
   }
}

@Test
public void testTopAndPop_1() throws Throwable {
    // Spec: FuzzedInvariant ( (Integer_Variable_0 = 0) iff (Integer_Variable_1 != 0) ) holds for: <this.topOfStack, orig(this.topOfStack)>
    // Spec: (this.topOfStack = 0) iff (old(this.topOfStack) != 0)
   DataStructures.StackAr stack = new DataStructures.StackAr(10);
   stack.push("item1");
   stack.push("item2");
   boolean origIsEmpty = stack.isEmpty();

   Object result = stack.topAndPop();

   if (stack.isEmpty()) {
       // assertion removed: origIsEmpty == false;
   } else {
       // assertion removed: stack.isEmpty() == false;
   }
}

    @Test
    public void testTopAndPop_1() throws Throwable {
    // Spec: FuzzedInvariant ( Integer_Variable_0 <= 1 ) holds for: this.topOfStack
    // Spec: this.topOfStack <= 1
        DataStructures.StackAr stack = new DataStructures.StackAr(10);
        stack.push("element1");
        stack.push("element2");
        stack.push("element3");

        Object result = stack.topAndPop();

    }

    @Test
    public void testTopAndPop_1() throws Throwable {
    // Spec: FuzzedInvariant ( Integer_Variable_0 <= 1 ) holds for: this.topOfStack
    // Spec: this.topOfStack <= 1
        DataStructures.StackAr stack = new DataStructures.StackAr(10);
        stack.push("element1");
        stack.push("element2");
        stack.push("element3");

        Object result = stack.topAndPop();

        // assertion removed: stack.isEmpty() || !stack.isFull();
    }

@Test
public void testTopAndPop_1() throws Throwable {
    // Spec: FuzzedInvariant ( Integer_Variable_0 != 0 ) holds for: this.topOfStack
    // Spec: this.topOfStack != 0
   DataStructures.StackAr stack = new DataStructures.StackAr(1);
   stack.push("element");
   stack.topAndPop();

}

@Test
public void testTopAndPop_1() throws Throwable {
    // Spec: FuzzedInvariant ( Integer_Variable_0 != 0 ) holds for: this.topOfStack
    // Spec: this.topOfStack != 0
   DataStructures.StackAr stack = new DataStructures.StackAr(1);
   stack.push("element");
   stack.topAndPop();

   stack.isEmpty();
}

@Test
public void testTopAndPop_1() throws Throwable {
    // Spec: FuzzedInvariant ( Integer_Variable_0 <= 0 ) holds for: this.topOfStack
    // Spec: this.topOfStack <= 0
   DataStructures.StackAr stack = new DataStructures.StackAr(10);
   stack.push("data");
   stack.topAndPop();

}

@Test
public void testTopAndPop_1() throws Throwable {
    // Spec: FuzzedInvariant ( Integer_Variable_0 <= 0 ) holds for: this.topOfStack
    // Spec: this.topOfStack <= 0
   DataStructures.StackAr stack = new DataStructures.StackAr(10);
   stack.push("data");
   stack.topAndPop();

   stack.isEmpty();
}

@Test
public void testTopAndPop_1() throws Throwable {
    // Spec: FuzzedInvariant ( Integer_Variable_0 <= 0 ) holds for: this.topOfStack
    // Spec: this.topOfStack <= 0
   DataStructures.StackAr stack = new DataStructures.StackAr(10);
   stack.push("data1");
   stack.push("data2");
   stack.topAndPop();

}

@Test
public void testTopAndPop_1() throws Throwable {
    // Spec: FuzzedInvariant ( Integer_Variable_0 <= 0 ) holds for: this.topOfStack
    // Spec: this.topOfStack <= 0
   DataStructures.StackAr stack = new DataStructures.StackAr(10);
   stack.push("data1");
   stack.push("data2");
   stack.topAndPop();

   stack.isEmpty();
}

@Test
public void testTopAndPop_1() throws Throwable {
    // Spec: FuzzedInvariant ( Integer_Variable_0 <= 0 ) holds for: this.topOfStack
    // Spec: this.topOfStack <= 0
   DataStructures.StackAr stack = new DataStructures.StackAr(10);
   stack.push("data1");
   stack.push("data2");

   stack.topAndPop();
   stack.topAndPop();
}

@Test
public void testTopAndPop_1() throws Throwable {
    // Spec: FuzzedInvariant ( Integer_Variable_0 <= 0 ) holds for: this.topOfStack
    // Spec: this.topOfStack <= 0
   DataStructures.StackAr stack = new DataStructures.StackAr(10);
   stack.push("data1");
   stack.push("data2");

   // assertion removed: stack.isEmpty() == false;
   stack.topAndPop();
   // assertion removed: stack.isEmpty() == false;
   stack.topAndPop();
   // assertion removed: stack.isEmpty() == true;
}

@Test
public void testTopAndPop_1() throws Throwable {
    // Spec: FuzzedInvariant ( Integer_Variable_0 <= 0 ) holds for: this.topOfStack
    // Spec: this.topOfStack <= 0
   DataStructures.StackAr stack = new DataStructures.StackAr(10);
   stack.push("data1");
   stack.push("data2");

}

@Test
public void testTopAndPop_1() throws Throwable {
    // Spec: FuzzedInvariant ( Integer_Variable_0 <= 0 ) holds for: this.topOfStack
    // Spec: this.topOfStack <= 0
   DataStructures.StackAr stack = new DataStructures.StackAr(10);
   stack.push("data1");
   stack.push("data2");

   // assertion removed: stack.isEmpty() == false;
}

@Test
public void testTopAndPop_1() throws Throwable {
    // Spec: \old(this.topOfStack) < daikon.Quant.size(this.theArray)-1
    // Spec: old(this.topOfStack) < size(this.theArray)-1
   DataStructures.StackAr stack = new DataStructures.StackAr(1);
   stack.push("item");

   Object origTopOfStack = stack.top();

   stack.topAndPop();

}

@Test
public void testTopAndPop_1() throws Throwable {
    // Spec: \old(this.topOfStack) < daikon.Quant.size(this.theArray)-1
    // Spec: old(this.topOfStack) < size(this.theArray)-1
   DataStructures.StackAr stack = new DataStructures.StackAr(1);
   stack.push("item");

   Object origTopOfStack = stack.top();

   stack.topAndPop();

   stack.isEmpty();
}

@Test
public void testTopAndPop_1() throws Throwable {
    // Spec: FuzzedInvariant ( Integer_Variable_0 = Integer_Variable_1 + -1 ) holds for: <this.topOfStack, orig(this.topOfStack)>
    // Spec: this.topOfStack = old(this.topOfStack) + -1
   DataStructures.StackAr stack = new DataStructures.StackAr(10);
   stack.push("item1");
   int origTopOfStack = stack.isEmpty() ? -1 : stack.topOfStack + 1;

   stack.topAndPop();

}

@Test
public void testTopAndPop_1() throws Throwable {
    // Spec: FuzzedInvariant ( Integer_Variable_0 = Integer_Variable_1 + -1 ) holds for: <this.topOfStack, orig(this.topOfStack)>
    // Spec: this.topOfStack = old(this.topOfStack) + -1
   DataStructures.StackAr stack = new DataStructures.StackAr(10);
   stack.push("item1");
   int origTopOfStack = stack.isEmpty() ? -1 : stack.topOfStack + 1;

   stack.topAndPop();

   stack.isEmpty() ? -1 : stack.topOfStack + 1;
}

@Test
public void testTopAndPop_1() throws Throwable {
    // Spec: daikon.Quant.size(this.theArray) == 4 || daikon.Quant.size(this.theArray) == 35 || daikon.Quant.size(this.theArray) == 97
    // Spec: size(this.theArray) == 4 || size(this.theArray) == 35 || size(this.theArray) == 97
   DataStructures.StackAr stack = new DataStructures.StackAr(10);
   stack.push("hello");
   stack.push("world");

   Object result = stack.topAndPop();

} 

@Test
public void testTopAndPop_1() throws Throwable {
    // Spec: daikon.Quant.size(this.theArray) == 4 || daikon.Quant.size(this.theArray) == 35 || daikon.Quant.size(this.theArray) == 97
    // Spec: size(this.theArray) == 4 || size(this.theArray) == 35 || size(this.theArray) == 97
   DataStructures.StackAr stack = new DataStructures.StackAr(10);
   stack.push("hello");
   stack.push("world");

   Object result = stack.topAndPop();

   // assertion removed: 10;
   // assertion removed: 10;
   // assertion removed: 10;
} 

@Test
public void testTopAndPop_1() throws Throwable {
    // Spec: FuzzedInvariant ( all n : DataStructures.StackAr.theArray : n = null ) holds for: orig(this)
    // Spec: all n : DataStructures.StackAr.theArray : n = null
   DataStructures.StackAr stack = new DataStructures.StackAr(10);
   stack.push("item1");
   stack.push("item2");

   Object result = stack.topAndPop();

}

@Test
public void testTopAndPop_1() throws Throwable {
    // Spec: FuzzedInvariant ( all n : DataStructures.StackAr.theArray : n = null ) holds for: orig(this)
    // Spec: all n : DataStructures.StackAr.theArray : n = null
   DataStructures.StackAr stack = new DataStructures.StackAr(10);
   stack.push("item1");
   stack.push("item2");

   Object result = stack.topAndPop();

   stack.isEmpty();
}

@Test
public void testTopAndPop_1() throws Throwable {
    // Spec: \result != null
    // Spec: result != null
   DataStructures.StackAr stack = new DataStructures.StackAr(10);

   Object result = stack.topAndPop();

} 

@Test
public void testTopAndPop_1() throws Throwable {
    // Spec: \result != null
    // Spec: result != null
   DataStructures.StackAr stack = new DataStructures.StackAr(10);

   Object result = stack.topAndPop();

   // assertion removed: result;
} 

@Test
public void testTopAndPop() throws Throwable {
    // Spec: FuzzedInvariant ( (Integer_Variable_0 >= -1) implies (Integer_Variable_1 <= 1) ) holds for: <this.topOfStack, orig(this.topOfStack)>
    // Spec: (this.topOfStack >= -1) implies (old(this.topOfStack) <= 1)
   DataStructures.StackAr stack = new DataStructures.StackAr(10);
   stack.push("item1");
   stack.push("item2");
   stack.push("item3");

   int origSize = stack.size();

   stack.topAndPop();

   if (!stack.isEmpty()) {
   }
}

@Test
public void testTopAndPop() throws Throwable {
    // Spec: FuzzedInvariant ( (Integer_Variable_0 >= -1) implies (Integer_Variable_1 <= 1) ) holds for: <this.topOfStack, orig(this.topOfStack)>
    // Spec: (this.topOfStack >= -1) implies (old(this.topOfStack) <= 1)
   DataStructures.StackAr stack = new DataStructures.StackAr(10);
   stack.push("item1");
   stack.push("item2");
   stack.push("item3");

   int origSize = stack.size();

   stack.topAndPop();

   if (!stack.isEmpty()) {
   }
}

@Test
public void testTopAndPop() throws Throwable {
    // Spec: FuzzedInvariant ( (Integer_Variable_0 >= -1) implies (Integer_Variable_1 <= 1) ) holds for: <this.topOfStack, orig(this.topOfStack)>
    // Spec: (this.topOfStack >= -1) implies (old(this.topOfStack) <= 1)
   DataStructures.StackAr stack = new DataStructures.StackAr(10);
   stack.push("item1");
   stack.push("item2");
   stack.push("item3");
   stack.push("item4");
   stack.push("item5");

   int origSize = stack.topOfStack() + 1;

   stack.topAndPop();

   if (stack.isEmpty()) {
   } else {
   }
}

@Test
public void testTopAndPop() throws Throwable {
    // Spec: FuzzedInvariant ( (Integer_Variable_0 >= -1) implies (Integer_Variable_1 <= 1) ) holds for: <this.topOfStack, orig(this.topOfStack)>
    // Spec: (this.topOfStack >= -1) implies (old(this.topOfStack) <= 1)
   DataStructures.StackAr stack = new DataStructures.StackAr(10);
   stack.push("item1");
   stack.push("item2");
   stack.push("item3");
   stack.push("item4");
   stack.push("item5");

   int origSize = stack.topOfStack() + 1;

   stack.topAndPop();

   if (stack.isEmpty()) {
   } else {
   }
}

@Test
public void testTopAndPop_1() throws Throwable {
    // Spec: daikon.Quant.eltsEqual(daikon.Quant.typeArray(this.theArray), null)
    // Spec: eltsEqual(typeArray(this.theArray), null)
   DataStructures.StackAr stack = new DataStructures.StackAr(10);
   stack.push("test");
   Object result = stack.topAndPop();
}

@Test
public void testTopAndPop_1() throws Throwable {
    // Spec: daikon.Quant.eltsEqual(daikon.Quant.typeArray(this.theArray), null)
    // Spec: eltsEqual(typeArray(this.theArray), null)
   DataStructures.StackAr stack = new DataStructures.StackAr(10);
   stack.push("test");
   Object result = stack.topAndPop();
   stack.isEmpty();
}

@Test
public void testTopAndPop_1() throws Throwable {
    // Spec: FuzzedInvariant ( Integer_Variable_0 = -1 ) holds for: this.topOfStack
    // Spec: this.topOfStack = -1
   DataStructures.StackAr stack = new DataStructures.StackAr(10);

   stack.push("element");

   Object result = stack.topAndPop();

}

@Test
public void testTopAndPop_1() throws Throwable {
    // Spec: FuzzedInvariant ( Integer_Variable_0 = -1 ) holds for: this.topOfStack
    // Spec: this.topOfStack = -1
   DataStructures.StackAr stack = new DataStructures.StackAr(10);

   stack.push("element");

   Object result = stack.topAndPop();

   stack.isEmpty() ? -1 : 0;
}