@Test
public void testExtend_1() throws Throwable {
    // Spec: FuzzedInvariant ( (Integer_Variable_0 = Integer_Variable_1) iff (Integer_Variable_1 <= 1) ) holds for: <this.start, this.capacity_>
    // Spec: (this.start = this.capacity_) iff (this.capacity_ <= 1)
   examples.RingBuffer<Integer> ringBuffer = new examples.RingBuffer<>(2);
   ringBuffer.extend(1);
   ringBuffer.extend(2);

   // Save the number of items before extending
   int origCount = ringBuffer.count();

   ringBuffer.extend(3);

   // Check the postcondition
   if (ringBuffer.count() == ringBuffer.capacity()) {
   } else {
   }
}

@Test
public void testExtend_1() throws Throwable {
    // Spec: FuzzedInvariant ( (Integer_Variable_0 = Integer_Variable_1) iff (Integer_Variable_1 <= 1) ) holds for: <this.start, this.capacity_>
    // Spec: (this.start = this.capacity_) iff (this.capacity_ <= 1)
   examples.RingBuffer<Integer> ringBuffer = new examples.RingBuffer<>(2);
   ringBuffer.extend(1);
   ringBuffer.extend(2);

   // Save the number of items before extending
   int origCount = ringBuffer.count();

   ringBuffer.extend(3);

   // Check the postcondition
   if (ringBuffer.count() == ringBuffer.capacity()) {
       // assertion removed: ringBuffer.count() <= 1;
   } else {
       // assertion removed: ringBuffer.count() > 1;
   }
}

@Test
public void testExtend_1() throws Throwable {
    // Spec: FuzzedInvariant ( Integer_Variable_0 >= Integer_Variable_1 / Integer_Variable_2 ) holds for: <this.start , this.free , this.capacity_>
    // Spec: this.start >= this.free / this.capacity_
   examples.RingBuffer<String> buffer = new examples.RingBuffer<>(1);
   buffer.extend("a");

   buffer.extend("b");

}

@Test
public void testExtend_1() throws Throwable {
    // Spec: FuzzedInvariant ( Integer_Variable_0 >= Integer_Variable_1 / Integer_Variable_2 ) holds for: <this.start , this.free , this.capacity_>
    // Spec: this.start >= this.free / this.capacity_
   examples.RingBuffer<String> buffer = new examples.RingBuffer<>(1);
   buffer.extend("a");

   buffer.extend("b");

   // assertion removed: buffer.count() >= buffer.capacity();
}

@Test
public void testExtend() throws Throwable {
    // Spec: FuzzedInvariant ( Integer_Variable_0 != 1 ) holds for: this.free
    // Spec: this.free != 1
   examples.RingBuffer<String> ringBuffer = new examples.RingBuffer<>(1);
   ringBuffer.extend("a");
   ringBuffer.remove();
   ringBuffer.extend("b");

}

@Test
public void testExtend() throws Throwable {
    // Spec: FuzzedInvariant ( Integer_Variable_0 != 1 ) holds for: this.free
    // Spec: this.free != 1
   examples.RingBuffer<String> ringBuffer = new examples.RingBuffer<>(1);
   ringBuffer.extend("a");
   ringBuffer.remove();
   ringBuffer.extend("b");

   ringBuffer.capacity() - ringBuffer.count();
}

@Test
public void testExtend_1() throws Throwable {
    // Spec: daikon.Quant.size(this.data)-1 == \old(daikon.Quant.size(this.data))
    // Spec: size(this.data)-1 == old(size(this.data))
   examples.RingBuffer<Integer> ringBuffer = new examples.RingBuffer<Integer>(5);
   int origDataSize = ringBuffer.dataCount();

   ringBuffer.extend(1);

}

@Test
public void testExtend_1() throws Throwable {
    // Spec: daikon.Quant.size(this.data)-1 == \old(daikon.Quant.size(this.data))
    // Spec: size(this.data)-1 == old(size(this.data))
   examples.RingBuffer<Integer> ringBuffer = new examples.RingBuffer<Integer>(5);
   int origDataSize = ringBuffer.dataCount();

   ringBuffer.extend(1);

   ringBuffer.dataCount();
}

@Test
public void testExtend_1() throws Throwable {
    // Spec: FuzzedInvariant ( Integer_Variable_0 = #(examples.RingBuffer.data) ) holds for: <orig(this), this.free>
    // Spec: this.free = #(old(this).data)
   examples.RingBuffer<Integer> buffer = new examples.RingBuffer<>(3);

   buffer.extend(1);
   buffer.extend(2);
   buffer.extend(3);

   int origCount = buffer.count();

   buffer.extend(4);

}

@Test
public void testExtend_1() throws Throwable {
    // Spec: FuzzedInvariant ( Integer_Variable_0 = #(examples.RingBuffer.data) ) holds for: <orig(this), this.free>
    // Spec: this.free = #(old(this).data)
   examples.RingBuffer<Integer> buffer = new examples.RingBuffer<>(3);

   buffer.extend(1);
   buffer.extend(2);
   buffer.extend(3);

   int origCount = buffer.count();

   buffer.extend(4);

   // assertion removed: origCount;
}

@Test
public void testExtend_1() throws Throwable {
    // Spec: daikon.Quant.size(this.data) == 2 || daikon.Quant.size(this.data) == 3 || daikon.Quant.size(this.data) == 4
    // Spec: size(this.data) == 2 || size(this.data) == 3 || size(this.data) == 4
   examples.RingBuffer<Integer> ringBuffer = new examples.RingBuffer<>(5);
   ringBuffer.extend(1);
   ringBuffer.extend(2);
   ringBuffer.extend(3);
   ringBuffer.extend(4);
   ringBuffer.extend(5);
   ringBuffer.extend(6);

}

@Test
public void testExtend_1() throws Throwable {
    // Spec: daikon.Quant.size(this.data) == 2 || daikon.Quant.size(this.data) == 3 || daikon.Quant.size(this.data) == 4
    // Spec: size(this.data) == 2 || size(this.data) == 3 || size(this.data) == 4
   examples.RingBuffer<Integer> ringBuffer = new examples.RingBuffer<>(5);
   ringBuffer.extend(1);
   ringBuffer.extend(2);
   ringBuffer.extend(3);
   ringBuffer.extend(4);
   ringBuffer.extend(5);
   ringBuffer.extend(6);

   // assertion removed: ringBuffer.count() == 2 || ringBuffer.count() == 3 || ringBuffer.count() == 4;
}

@Test
public void testExtend_1() throws Throwable {
    // Spec: FuzzedInvariant ( Integer_Variable_0 >= Integer_Variable_1 - Integer_Variable_2 ) holds for: <this.start , this.free , orig(this.free)>
    // Spec: this.start >= this.free - old(this.free)
   examples.RingBuffer<String> ringBuffer = new examples.RingBuffer<>(2);
   ringBuffer.extend("a");
   ringBuffer.extend("b");

   int origCount = ringBuffer.count();

   ringBuffer.extend("c");

}

@Test
public void testExtend_1() throws Throwable {
    // Spec: FuzzedInvariant ( Integer_Variable_0 >= Integer_Variable_1 - Integer_Variable_2 ) holds for: <this.start , this.free , orig(this.free)>
    // Spec: this.start >= this.free - old(this.free)
   examples.RingBuffer<String> ringBuffer = new examples.RingBuffer<>(2);
   ringBuffer.extend("a");
   ringBuffer.extend("b");

   int origCount = ringBuffer.count();

   ringBuffer.extend("c");

   // assertion removed: ringBuffer.count() > origCount;
}

@Test
public void testExtend_1() throws Throwable {
    // Spec: FuzzedInvariant ( (Integer_Variable_0 > Integer_Variable_1) iff (Integer_Variable_1 = Integer_Variable_2) ) holds for: <this.start , this.free , orig(this.free)>
    // Spec: (this.start > this.free) iff (this.free = old(this.free))
   examples.RingBuffer<Integer> buffer = new examples.RingBuffer<>(5);

   buffer.extend(1);
   buffer.extend(2);
   buffer.extend(3);
   buffer.extend(4);
   buffer.extend(5);

   int origCount = buffer.count();

   buffer.extend(6);

}

@Test
public void testExtend_1() throws Throwable {
    // Spec: FuzzedInvariant ( (Integer_Variable_0 > Integer_Variable_1) iff (Integer_Variable_1 = Integer_Variable_2) ) holds for: <this.start , this.free , orig(this.free)>
    // Spec: (this.start > this.free) iff (this.free = old(this.free))
   examples.RingBuffer<Integer> buffer = new examples.RingBuffer<>(5);

   buffer.extend(1);
   buffer.extend(2);
   buffer.extend(3);
   buffer.extend(4);
   buffer.extend(5);

   int origCount = buffer.count();

   buffer.extend(6);

   // assertion removed: buffer.count() > origCount;
}

@Test
public void testExtend_1() throws Throwable {
    // Spec: FuzzedInvariant ( Integer_Variable_0 >= #(examples.RingBuffer.data) ) holds for: <orig(this), this.free>
    // Spec: this.free >= #(old(this).data)
   examples.RingBuffer<Integer> ringBuffer = new examples.RingBuffer<>(1);
   ringBuffer.extend(1);

}

@Test
public void testExtend_1() throws Throwable {
    // Spec: FuzzedInvariant ( Integer_Variable_0 >= #(examples.RingBuffer.data) ) holds for: <orig(this), this.free>
    // Spec: this.free >= #(old(this).data)
   examples.RingBuffer<Integer> ringBuffer = new examples.RingBuffer<>(1);
   ringBuffer.extend(1);

}

@Test
public void testExtend_1() throws Throwable {
    // Spec: this.start == 1
    // Spec: this.start == 1
    examples.RingBuffer<String> buffer = new examples.RingBuffer<>(2);
    buffer.extend("a");
    buffer.extend("b");

    buffer.extend("c");

}

@Test
public void testExtend_1() throws Throwable {
    // Spec: this.start == 1
    // Spec: this.start == 1
    examples.RingBuffer<String> buffer = new examples.RingBuffer<>(2);
    buffer.extend("a");
    buffer.extend("b");

    buffer.extend("c");

    buffer.isEmpty();
}

@Test
public void testExtend_1() throws Throwable {
    // Spec: FuzzedInvariant ( (Integer_Variable_0 = Integer_Variable_1) iff (Integer_Variable_1 <= 1) ) holds for: <this.free, this.capacity_>
    // Spec: (this.free = this.capacity_) iff (this.capacity_ <= 1)
   examples.RingBuffer<Integer> ringBuffer = new examples.RingBuffer<>(2);
   ringBuffer.extend(1);
   ringBuffer.extend(2);

   boolean postcondition = ringBuffer.count() == ringBuffer.capacity();

}

@Test
public void testExtend_1() throws Throwable {
    // Spec: FuzzedInvariant ( (Integer_Variable_0 = Integer_Variable_1) iff (Integer_Variable_1 <= 1) ) holds for: <this.free, this.capacity_>
    // Spec: (this.free = this.capacity_) iff (this.capacity_ <= 1)
   examples.RingBuffer<Integer> ringBuffer = new examples.RingBuffer<>(2);
   ringBuffer.extend(1);
   ringBuffer.extend(2);

   boolean postcondition = ringBuffer.count() == ringBuffer.capacity();

   // assertion removed: postcondition;
}