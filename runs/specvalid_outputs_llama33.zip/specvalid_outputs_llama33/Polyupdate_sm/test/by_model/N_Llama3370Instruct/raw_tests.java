@Test
public void testSm_1() throws Throwable {
    // Spec: FuzzedInvariant ( (Integer_Variable_0 >= 1) implies (Integer_Variable_1 > 1) ) holds for: <this._var426, return>
    // Spec: (this._var426 >= 1) implies (return > 1)
   examples.Polyupdate polyupdate = new examples.Polyupdate();
   polyupdate.clear();
   polyupdate.a(1);
   polyupdate.a(0);

   int result = polyupdate.sm();

   if (result >= 1) {
       assertTrue(result > 1);
   }
}

@Test
public void testSm_1() throws Throwable {
    // Spec: FuzzedInvariant ( (Integer_Variable_0 >= 1) implies (Integer_Variable_1 > 1) ) holds for: <this._var426, return>
    // Spec: (this._var426 >= 1) implies (return > 1)
   examples.Polyupdate polyupdate = new examples.Polyupdate();
   polyupdate.clear();
   polyupdate.a(1);
   polyupdate.a(0);

   int result = polyupdate.sm();

   if (result >= 1) {
       // assertion removed: result > 1;
   }
}

@Test
public void testSm() throws Throwable {
    // Spec: FuzzedInvariant ( (Integer_Variable_0 = 1) or (Integer_Variable_1 != 1) ) holds for: <this._var23, return>
    // Spec: (this._var23 = 1) or (return != 1)
  examples.Polyupdate polyupdate = new examples.Polyupdate();
  polyupdate.clear();
  polyupdate.a(1);
  polyupdate.a(0);
  int result = polyupdate.sm();
  assertEquals(1, result);
}

@Test
public void testSm() throws Throwable {
    // Spec: FuzzedInvariant ( (Integer_Variable_0 = 1) or (Integer_Variable_1 != 1) ) holds for: <this._var23, return>
    // Spec: (this._var23 = 1) or (return != 1)
  examples.Polyupdate polyupdate = new examples.Polyupdate();
  polyupdate.clear();
  polyupdate.a(1);
  polyupdate.a(0);
  int result = polyupdate.sm();
  // assertion removed: result;
}