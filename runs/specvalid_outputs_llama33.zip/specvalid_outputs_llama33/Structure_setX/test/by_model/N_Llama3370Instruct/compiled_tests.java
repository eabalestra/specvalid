@Test
public void testSetX_1() throws Throwable {
    // Spec: FuzzedInvariant ( Integer_Variable_0 >= Integer_Variable_1 - 1 ) holds for: <this.var62, orig(y)>
    // Spec: this.var62 >= old(y) - 1
   examples.Structure structure = new examples.Structure();
   int y = 0;


   structure.setX(y);


}

@Test
public void testSetX_1() throws Throwable {
    // Spec: FuzzedInvariant ( Integer_Variable_0 >= Integer_Variable_1 - 1 ) holds for: <this.var62, orig(y)>
    // Spec: this.var62 >= old(y) - 1
   examples.Structure structure = new examples.Structure();
   int y = 0;


   structure.setX(y);


   // assertion removed: y - 1;
   // assertion removed: structure.foo() - 1 >= y - 1;
}

@Test
public void testSetX_1() throws Throwable {
    // Spec: FuzzedInvariant ( (Integer_Variable_0 <= 1) or (Integer_Variable_1 != 0) ) holds for: <this.var62, orig(y)>
    // Spec: (this.var62 <= 1) or (old(y) != 0)
   examples.Structure structure = new examples.Structure();
   int y = 0;


   structure.setX(y);


}

@Test
public void testSetX_1() throws Throwable {
    // Spec: FuzzedInvariant ( (Integer_Variable_0 <= 1) or (Integer_Variable_1 != 0) ) holds for: <this.var62, orig(y)>
    // Spec: (this.var62 <= 1) or (old(y) != 0)
   examples.Structure structure = new examples.Structure();
   int y = 0;


   structure.setX(y);


   // assertion removed: (structure.foo() <= 1) || (y != 0);
}

@Test
public void testSetX_1() throws Throwable {
    // Spec: FuzzedInvariant ( (Integer_Variable_0 = -1) implies (Integer_Variable_1 > 1) ) holds for: <this.var62, orig(y)>
    // Spec: (this.var62 = -1) implies (old(y) > 1)
   examples.Structure structure = new examples.Structure();
   int y = 0;

   structure.setX(y);

}

@Test
public void testSetX_1() throws Throwable {
    // Spec: FuzzedInvariant ( (Integer_Variable_0 = -1) implies (Integer_Variable_1 > 1) ) holds for: <this.var62, orig(y)>
    // Spec: (this.var62 = -1) implies (old(y) > 1)
   examples.Structure structure = new examples.Structure();
   int y = 0;

   structure.setX(y);

   // assertion removed: (structure.foo() == -1) == (y > 1);
}

@Test
public void testSetX_1() throws Throwable {
    // Spec: FuzzedInvariant ( Integer_Variable_0 != Integer_Variable_1 + 0 ) holds for: <this.var62, orig(y)>
    // Spec: this.var62 != old(y) + 0
   examples.Structure structure = new examples.Structure();
   int y = 0;

   structure.setX(y);

}

@Test
public void testSetX_1() throws Throwable {
    // Spec: FuzzedInvariant ( Integer_Variable_0 != Integer_Variable_1 + 0 ) holds for: <this.var62, orig(y)>
    // Spec: this.var62 != old(y) + 0
   examples.Structure structure = new examples.Structure();
   int y = 0;

   structure.setX(y);

   // assertion removed: structure.foo() != (y + 1);
}

@Test
public void testSetX_1() throws Throwable {
    // Spec: FuzzedInvariant ( (Integer_Variable_0 = 0) implies (Integer_Variable_1 <= 1) ) holds for: <this.var62, orig(y)>
    // Spec: (this.var62 = 0) implies (old(y) <= 1)
   examples.Structure structure = new examples.Structure();
   structure.setX(2);
}

@Test
public void testSetX_1() throws Throwable {
    // Spec: FuzzedInvariant ( (Integer_Variable_0 = 0) implies (Integer_Variable_1 <= 1) ) holds for: <this.var62, orig(y)>
    // Spec: (this.var62 = 0) implies (old(y) <= 1)
   examples.Structure structure = new examples.Structure();
   structure.setX(2);
   // assertion removed: (structure.foo() == 3) == (structure.foo() == 4 && 2 <= 1);
}

@Test
public void testSetX_1() throws Throwable {
    // Spec: FuzzedInvariant ( (Integer_Variable_0 = 0) implies (Integer_Variable_1 <= 1) ) holds for: <this.var62, orig(y)>
    // Spec: (this.var62 = 0) implies (old(y) <= 1)
   examples.Structure structure = new examples.Structure();
   int y = 1;
   structure.setX(y);
}

@Test
public void testSetX_1() throws Throwable {
    // Spec: FuzzedInvariant ( (Integer_Variable_0 = 0) implies (Integer_Variable_1 <= 1) ) holds for: <this.var62, orig(y)>
    // Spec: (this.var62 = 0) implies (old(y) <= 1)
   examples.Structure structure = new examples.Structure();
   int y = 1;
   structure.setX(y);
   // assertion removed: !(structure.foo() == 0) || (y <= 1);
}

@Test
public void testSetX_1() throws Throwable {
    // Spec: FuzzedInvariant ( (Integer_Variable_0 != 1) or (Integer_Variable_1 < 1) ) holds for: <this.var62, orig(y)>
    // Spec: (this.var62 != 1) or (old(y) < 1)
   examples.Structure structure = new examples.Structure();
   structure.setX(0);

}

@Test
public void testSetX_1() throws Throwable {
    // Spec: FuzzedInvariant ( (Integer_Variable_0 != 1) or (Integer_Variable_1 < 1) ) holds for: <this.var62, orig(y)>
    // Spec: (this.var62 != 1) or (old(y) < 1)
   examples.Structure structure = new examples.Structure();
   structure.setX(0);

   // assertion removed: (structure.foo() != 1) || (0 < 1);
}