@Test
public void testRemove() throws Throwable {
    // Spec: this._var4384._0 == this._var5992
    // Spec: this._var4384._0 == this._var5992
    examples.MaxBag maxBag = new examples.MaxBag();
    maxBag.add(10);
    maxBag.add(20);
    maxBag.add(30);
    maxBag.remove(10);
}

@Test
public void testRemove() throws Throwable {
    // Spec: this._var4384._0 == this._var5992
    // Spec: this._var4384._0 == this._var5992
    examples.MaxBag maxBag = new examples.MaxBag();
    maxBag.add(10);
    maxBag.add(20);
    maxBag.add(30);
    maxBag.remove(10);
    // assertion removed: maxBag.getMax() == 10;
}