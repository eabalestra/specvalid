@Test
public void testItem_1() throws Throwable {
    // Spec: FuzzedInvariant ( some n : examples.RingBuffer.data : n = null ) holds for: this
    // Spec: some n : examples.RingBuffer.data : n = null
   examples.RingBuffer<Object> ringBuffer = new examples.RingBuffer<>(1);
   ringBuffer.extend(null);
   Object result = ringBuffer.item();
}

@Test
public void testItem_1() throws Throwable {
    // Spec: FuzzedInvariant ( some n : examples.RingBuffer.data : n = null ) holds for: this
    // Spec: some n : examples.RingBuffer.data : n = null
   examples.RingBuffer<Object> ringBuffer = new examples.RingBuffer<>(1);
   ringBuffer.extend(null);
   Object result = ringBuffer.item();
   // assertion removed: result;
   // assertion removed: result;
}

@Test
public void testItem_1() throws Throwable {
    // Spec: FuzzedInvariant ( Integer_Variable_0 <= Integer_Variable_1 * Integer_Variable_2 ) holds for: <this.start , this.free , this.capacity_>
    // Spec: this.start <= this.free * this.capacity_
   examples.RingBuffer<Integer> ringBuffer = new examples.RingBuffer<>(1);
   ringBuffer.extend(1);
   ringBuffer.remove();
   ringBuffer.extend(1);

   Object result = ringBuffer.item();

}

@Test
public void testItem_1() throws Throwable {
    // Spec: FuzzedInvariant ( Integer_Variable_0 <= Integer_Variable_1 * Integer_Variable_2 ) holds for: <this.start , this.free , this.capacity_>
    // Spec: this.start <= this.free * this.capacity_
   examples.RingBuffer<Integer> ringBuffer = new examples.RingBuffer<>(1);
   ringBuffer.extend(1);
   ringBuffer.remove();
   ringBuffer.extend(1);

   Object result = ringBuffer.item();

   // assertion removed: ringBuffer.count() <= ringBuffer.capacity() * ringBuffer.capacity();
}

@Test
public void testItem_1() throws Throwable {
    // Spec: FuzzedInvariant ( (Integer_Variable_0 > -1) xor (Integer_Variable_1 <= 1) ) holds for: <this.start, this.capacity_>
    // Spec: (this.start > -1) xor (this.capacity_ <= 1)
   examples.RingBuffer<Integer> ringBuffer = new examples.RingBuffer<>(2);
   ringBuffer.extend(1);
   ringBuffer.extend(2);
   ringBuffer.remove();

}

@Test
public void testItem_1() throws Throwable {
    // Spec: FuzzedInvariant ( (Integer_Variable_0 > -1) xor (Integer_Variable_1 <= 1) ) holds for: <this.start, this.capacity_>
    // Spec: (this.start > -1) xor (this.capacity_ <= 1)
   examples.RingBuffer<Integer> ringBuffer = new examples.RingBuffer<>(2);
   ringBuffer.extend(1);
   ringBuffer.extend(2);
   ringBuffer.remove();

   // assertion removed: ringBuffer.count() > 0 && ! (ringBuffer.capacity() <= 1);
}

@Test
public void testItem_1() throws Throwable {
    // Spec: FuzzedInvariant ( (Integer_Variable_0 != 0) xor (Integer_Variable_1 < 1) ) holds for: <this.start, this.free>
    // Spec: (this.start != 0) xor (this.free < 1)
   examples.RingBuffer<Integer> ringBuffer = new examples.RingBuffer<>(1);
   ringBuffer.extend(1);

   Object result = ringBuffer.item();

   boolean postcondition = !ringBuffer.isEmpty() ^ ringBuffer.isFull();
}

@Test
public void testItem_1() throws Throwable {
    // Spec: FuzzedInvariant ( (Integer_Variable_0 != 0) xor (Integer_Variable_1 < 1) ) holds for: <this.start, this.free>
    // Spec: (this.start != 0) xor (this.free < 1)
   examples.RingBuffer<Integer> ringBuffer = new examples.RingBuffer<>(1);
   ringBuffer.extend(1);

   Object result = ringBuffer.item();

   boolean postcondition = !ringBuffer.isEmpty() ^ ringBuffer.isFull();
   // assertion removed: postcondition;
}

@Test
public void testItem_1() throws Throwable {
    // Spec: FuzzedInvariant ( Integer_Variable_0 > Integer_Variable_1 - Integer_Variable_2 ) holds for: <this.start , this.free , this.capacity_>
    // Spec: this.start > this.free - this.capacity_
   examples.RingBuffer<String> ringBuffer = new examples.RingBuffer<>(5);
   ringBuffer.extend("a");
   ringBuffer.extend("b");
   ringBuffer.extend("c");
   ringBuffer.extend("d");
   ringBuffer.extend("e");
   ringBuffer.remove();

   Object result = ringBuffer.item();

   boolean postcondition = ringBuffer.count() > 0;
}

@Test
public void testItem_1() throws Throwable {
    // Spec: FuzzedInvariant ( Integer_Variable_0 > Integer_Variable_1 - Integer_Variable_2 ) holds for: <this.start , this.free , this.capacity_>
    // Spec: this.start > this.free - this.capacity_
   examples.RingBuffer<String> ringBuffer = new examples.RingBuffer<>(5);
   ringBuffer.extend("a");
   ringBuffer.extend("b");
   ringBuffer.extend("c");
   ringBuffer.extend("d");
   ringBuffer.extend("e");
   ringBuffer.remove();

   Object result = ringBuffer.item();

   boolean postcondition = ringBuffer.count() > 0;
   // assertion removed: postcondition;
}

@Test
public void testItem_1() throws Throwable {
    // Spec: this.start == 1
    // Spec: this.start == 1
   examples.RingBuffer<String> buffer = new examples.RingBuffer<>(5);
   buffer.extend("a");
   buffer.extend("b");
   buffer.remove();

   Object result = buffer.item();

}

@Test
public void testItem_1() throws Throwable {
    // Spec: this.start == 1
    // Spec: this.start == 1
   examples.RingBuffer<String> buffer = new examples.RingBuffer<>(5);
   buffer.extend("a");
   buffer.extend("b");
   buffer.remove();

   Object result = buffer.item();

   buffer.count();
}

@Test
public void testItem_1() throws Throwable {
    // Spec: FuzzedInvariant ( Integer_Variable_0 = #(examples.RingBuffer.data) ) holds for: <orig(this), this.free>
    // Spec: this.free = #(old(this).data)
   examples.RingBuffer<String> ringBuffer = new examples.RingBuffer<String>(5);
   ringBuffer.extend("Apple");
   ringBuffer.extend("Banana");
   examples.RingBuffer<String> origRingBuffer = ringBuffer;

   Object result = ringBuffer.item();

}

@Test
public void testItem_1() throws Throwable {
    // Spec: FuzzedInvariant ( Integer_Variable_0 = #(examples.RingBuffer.data) ) holds for: <orig(this), this.free>
    // Spec: this.free = #(old(this).data)
   examples.RingBuffer<String> ringBuffer = new examples.RingBuffer<String>(5);
   ringBuffer.extend("Apple");
   ringBuffer.extend("Banana");
   examples.RingBuffer<String> origRingBuffer = ringBuffer;

   Object result = ringBuffer.item();

   ringBuffer.count();
}

@Test
public void testItem_1() throws Throwable {
    // Spec: FuzzedInvariant ( Integer_Variable_0 >= Integer_Variable_1 / Integer_Variable_2 ) holds for: <this.start , this.free , this.capacity_>
    // Spec: this.start >= this.free / this.capacity_
   examples.RingBuffer<String> buffer = new examples.RingBuffer<>(10);

   buffer.extend("test");
   buffer.extend("test2");

   Object result = buffer.item();

}

@Test
public void testItem_1() throws Throwable {
    // Spec: FuzzedInvariant ( Integer_Variable_0 >= Integer_Variable_1 / Integer_Variable_2 ) holds for: <this.start , this.free , this.capacity_>
    // Spec: this.start >= this.free / this.capacity_
   examples.RingBuffer<String> buffer = new examples.RingBuffer<>(10);

   buffer.extend("test");
   buffer.extend("test2");

   Object result = buffer.item();

   // assertion removed: buffer.count() >= buffer.capacity();
}