@Test
public void testExtend_1() throws Throwable {
    // Spec: FuzzedInvariant ( Integer_Variable_0 < #(Map.data) ) holds for: <orig(this), return>
    // Spec: return < #(old(this).data)
   examples.Map<String, String> map = new examples.Map<>();
   map.extend("key1", "value1");
   map.extend("key2", "value2");

   int result = map.extend("key1", "newValue1");

   assertTrue(result < map.count());
}

@Test
public void testExtend_1() throws Throwable {
    // Spec: FuzzedInvariant ( Integer_Variable_0 < #(Map.data) ) holds for: <orig(this), return>
    // Spec: return < #(old(this).data)
   examples.Map<String, String> map = new examples.Map<>();
   map.extend("key1", "value1");
   map.extend("key2", "value2");

   int result = map.extend("key1", "newValue1");

   // assertion removed: result < map.count();
}

@Test
public void testExtend_1() throws Throwable {
    // Spec: daikon.Quant.memberOf(\old(v.getClass().getName()) , daikon.Quant.typeArray(this.data) )
    // Spec: memberOf(old(v.getClass().getName()) , typeArray(this.data) )
   examples.Map<String, Integer> map = new examples.Map<String, Integer>();
   String k = "test";
   Integer v = 10;

   map.extend(k, v);

   assertTrue(v.getClass().getName().equals("java.lang.Integer"));
   assertNotEquals(v.getClass().getName(), map.getClass().getName());
}

@Test
public void testExtend_1() throws Throwable {
    // Spec: daikon.Quant.memberOf(\old(v.getClass().getName()) , daikon.Quant.typeArray(this.data) )
    // Spec: memberOf(old(v.getClass().getName()) , typeArray(this.data) )
   examples.Map<String, Integer> map = new examples.Map<String, Integer>();
   String k = "test";
   Integer v = 10;

   map.extend(k, v);

   v.getClass().getName().equals("java.lang.Integer");
   map.getClass().getName();
}

@Test
public void testExtend_1() throws Throwable {
    // Spec: daikon.Quant.size(this.data) == 1 || daikon.Quant.size(this.data) == 2 || daikon.Quant.size(this.data) == 3
    // Spec: size(this.data) == 1 || size(this.data) == 2 || size(this.data) == 3
   Map<String, String> map = new Map<>();

   map.extend("key1", "value1");
   map.extend("key2", "value2");
   map.extend("key3", "value3");
   map.extend("key4", "value4");

   assertFalse(map.count() == 1 || map.count() == 2 || map.count() == 3);
}

@Test
public void testExtend_1() throws Throwable {
    // Spec: daikon.Quant.size(this.data) == 1 || daikon.Quant.size(this.data) == 2 || daikon.Quant.size(this.data) == 3
    // Spec: size(this.data) == 1 || size(this.data) == 2 || size(this.data) == 3
   Map<String, String> map = new Map<>();

   map.extend("key1", "value1");
   map.extend("key2", "value2");
   map.extend("key3", "value3");
   map.extend("key4", "value4");

   // assertion removed: map.count() == 1 || map.count() == 2 || map.count() == 3;
}

@Test
public void testExtend_1() throws Throwable {
    // Spec: FuzzedInvariant ( Integer_Variable_0 < #(Map.keys) ) holds for: <orig(this), return>
    // Spec: return < #(old(this).keys)
   examples.Map<String, String> map = new examples.Map<String, String>();
   map.extend("key1", "value1");
   int result = map.extend("key2", "value2");

   assertNotEquals(map.count(), map.count() - 1);
}

@Test
public void testExtend_1() throws Throwable {
    // Spec: FuzzedInvariant ( Integer_Variable_0 < #(Map.keys) ) holds for: <orig(this), return>
    // Spec: return < #(old(this).keys)
   examples.Map<String, String> map = new examples.Map<String, String>();
   map.extend("key1", "value1");
   int result = map.extend("key2", "value2");

   map.count() - 1;
}

@Test
public void testExtend_2() throws Throwable {
    // Spec: FuzzedInvariant ( Integer_Variable_0 < #(Map.keys) ) holds for: <orig(this), return>
    // Spec: return < #(old(this).keys)
   examples.Map<String, String> map = new examples.Map<String, String>();
   int initialSize = map.count();
   map.extend("key1", "value1");
   int result = map.extend("key2", "value2");
   assertTrue(map.count() > initialSize);
}

@Test
public void testExtend_2() throws Throwable {
    // Spec: FuzzedInvariant ( Integer_Variable_0 < #(Map.keys) ) holds for: <orig(this), return>
    // Spec: return < #(old(this).keys)
   examples.Map<String, String> map = new examples.Map<String, String>();
   int initialSize = map.count();
   map.extend("key1", "value1");
   int result = map.extend("key2", "value2");
   // assertion removed: map.count() > initialSize;
}

@Test
public void testExtend_1() throws Throwable {
    // Spec: FuzzedInvariant ( Integer_Variable_0 != #(Map.data) ) holds for: <orig(this), return>
    // Spec: return != #(old(this).data)
   examples.Map<String, String> map = new examples.Map<>();
   map.extend("key", "value");
   examples.Map<String, String> origMap = new examples.Map<>();
   origMap.extend("key", "value");

   int result = map.extend("key", "new_value");

   assertNotEquals(result, origMap.count());
}

@Test
public void testExtend_1() throws Throwable {
    // Spec: FuzzedInvariant ( Integer_Variable_0 != #(Map.data) ) holds for: <orig(this), return>
    // Spec: return != #(old(this).data)
   examples.Map<String, String> map = new examples.Map<>();
   map.extend("key", "value");
   examples.Map<String, String> origMap = new examples.Map<>();
   origMap.extend("key", "value");

   int result = map.extend("key", "new_value");

   origMap.count();
}

@Test 
public void testExtend_1() throws Throwable {
    // Spec: \result == 0 || \result == 1 || \result == 2
    // Spec: result == 0 || result == 1 || result == 2
    examples.Map<Integer, Integer> map = new examples.Map<>();
    map.extend(1, 1);
    map.extend(2, 2);
    map.extend(3, 3);
    int result = map.extend(4, 4);
    assertTrue(result == 0 || result == 1 || result == 2);
}

@Test 
public void testExtend_1() throws Throwable {
    // Spec: \result == 0 || \result == 1 || \result == 2
    // Spec: result == 0 || result == 1 || result == 2
    examples.Map<Integer, Integer> map = new examples.Map<>();
    map.extend(1, 1);
    map.extend(2, 2);
    map.extend(3, 3);
    int result = map.extend(4, 4);
    // assertion removed: result == 0 || result == 1 || result == 2;
}

@Test
public void testExtend_1() throws Throwable {
    // Spec: daikon.Quant.size(this.keys) == 1 || daikon.Quant.size(this.keys) == 2 || daikon.Quant.size(this.keys) == 3
    // Spec: size(this.keys) == 1 || size(this.keys) == 2 || size(this.keys) == 3
   examples.Map<Integer, Integer> map = new examples.Map<>();
   map.extend(1, 1);
   map.extend(2, 2);
   map.extend(3, 3);
   map.extend(4, 4);

   map.extend(1, 5);

   assertEquals(4, map.count());
}

@Test
public void testExtend_1() throws Throwable {
    // Spec: daikon.Quant.size(this.keys) == 1 || daikon.Quant.size(this.keys) == 2 || daikon.Quant.size(this.keys) == 3
    // Spec: size(this.keys) == 1 || size(this.keys) == 2 || size(this.keys) == 3
   examples.Map<Integer, Integer> map = new examples.Map<>();
   map.extend(1, 1);
   map.extend(2, 2);
   map.extend(3, 3);
   map.extend(4, 4);

   map.extend(1, 5);

   map.count();
}