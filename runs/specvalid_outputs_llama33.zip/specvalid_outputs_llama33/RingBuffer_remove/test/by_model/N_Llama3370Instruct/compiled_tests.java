@Test
public void testRemove_1() throws Throwable {
    // Spec: FuzzedInvariant ( (Integer_Variable_0 <= 1) xor (Integer_Variable_1 > Integer_Variable_2) ) holds for: <this.start , this.free , orig(this.start)>
    // Spec: (this.start <= 1) xor (this.free > old(this.start))
   examples.RingBuffer<Integer> ringBuffer = new examples.RingBuffer<>(5);
   ringBuffer.extend(1);
   ringBuffer.extend(2);
   ringBuffer.extend(3);
   ringBuffer.remove();

   boolean postcondition = (ringBuffer.isEmpty() ^ (ringBuffer.count() == 2));
}

@Test
public void testRemove_1() throws Throwable {
    // Spec: FuzzedInvariant ( (Integer_Variable_0 <= 1) xor (Integer_Variable_1 > Integer_Variable_2) ) holds for: <this.start , this.free , orig(this.start)>
    // Spec: (this.start <= 1) xor (this.free > old(this.start))
   examples.RingBuffer<Integer> ringBuffer = new examples.RingBuffer<>(5);
   ringBuffer.extend(1);
   ringBuffer.extend(2);
   ringBuffer.extend(3);
   ringBuffer.remove();

   boolean postcondition = (ringBuffer.isEmpty() ^ (ringBuffer.count() == 2));
   // assertion removed: postcondition;
}

@Test
public void testRemove_1() throws Throwable {
    // Spec: FuzzedInvariant ( (Integer_Variable_0 <= 1) xor (Integer_Variable_1 > Integer_Variable_2) ) holds for: <this.start , this.free , orig(this.start)>
    // Spec: (this.start <= 1) xor (this.free > old(this.start))
   examples.RingBuffer<Integer> ringBuffer = new examples.RingBuffer<>(5);
   ringBuffer.extend(1);
   ringBuffer.extend(2);
   ringBuffer.extend(3);
   int oldCount = ringBuffer.count();
   ringBuffer.remove();

   boolean postcondition = ringBuffer.count() == oldCount - 1;
}

@Test
public void testRemove_1() throws Throwable {
    // Spec: FuzzedInvariant ( (Integer_Variable_0 <= 1) xor (Integer_Variable_1 > Integer_Variable_2) ) holds for: <this.start , this.free , orig(this.start)>
    // Spec: (this.start <= 1) xor (this.free > old(this.start))
   examples.RingBuffer<Integer> ringBuffer = new examples.RingBuffer<>(5);
   ringBuffer.extend(1);
   ringBuffer.extend(2);
   ringBuffer.extend(3);
   int oldCount = ringBuffer.count();
   ringBuffer.remove();

   boolean postcondition = ringBuffer.count() == oldCount - 1;
   // assertion removed: postcondition;
}

@Test
public void testRemove() throws Throwable {
    // Spec: FuzzedInvariant ( Integer_Variable_0 >= Integer_Variable_1 / Integer_Variable_2 ) holds for: <this.start , this.free , this.capacity_>
    // Spec: this.start >= this.free / this.capacity_
   examples.RingBuffer<String> buffer = new examples.RingBuffer<>(1);
   buffer.extend("a");
   buffer.remove();
}

@Test
public void testRemove() throws Throwable {
    // Spec: FuzzedInvariant ( Integer_Variable_0 >= Integer_Variable_1 / Integer_Variable_2 ) holds for: <this.start , this.free , this.capacity_>
    // Spec: this.start >= this.free / this.capacity_
   examples.RingBuffer<String> buffer = new examples.RingBuffer<>(1);
   buffer.extend("a");
   buffer.remove();
   buffer.isEmpty();
}

@Test
public void testRemove_1() throws Throwable {
    // Spec: FuzzedInvariant ( Integer_Variable_0 = #(examples.RingBuffer.data) ) holds for: <orig(this), this.free>
    // Spec: this.free = #(old(this).data)
   examples.RingBuffer<String> ringBuffer = new examples.RingBuffer<>(5);
   ringBuffer.extend("A");
   ringBuffer.extend("B");
   ringBuffer.extend("C");

   int originalDataCount = ringBuffer.count();

   ringBuffer.remove();

}

@Test
public void testRemove_1() throws Throwable {
    // Spec: FuzzedInvariant ( Integer_Variable_0 = #(examples.RingBuffer.data) ) holds for: <orig(this), this.free>
    // Spec: this.free = #(old(this).data)
   examples.RingBuffer<String> ringBuffer = new examples.RingBuffer<>(5);
   ringBuffer.extend("A");
   ringBuffer.extend("B");
   ringBuffer.extend("C");

   int originalDataCount = ringBuffer.count();

   ringBuffer.remove();

   // assertion removed: originalDataCount;
}

@Test
public void testRemove_1() throws Throwable {
    // Spec: FuzzedInvariant ( (Integer_Variable_0 <= 0) xor (Integer_Variable_1 >= 1) ) holds for: <this.free, this.capacity_>
    // Spec: (this.free <= 0) xor (this.capacity_ >= 1)
   examples.RingBuffer<Integer> buffer = new examples.RingBuffer<>(1);
   buffer.extend(1);

   buffer.remove();

   boolean countLessThanEqualZero = buffer.count() <= 0;
   boolean capacityGreaterThanOrEqualOne = buffer.capacity() >= 1;
   boolean xorResult = countLessThanEqualZero ^ capacityGreaterThanOrEqualOne;

}

@Test
public void testRemove_1() throws Throwable {
    // Spec: FuzzedInvariant ( (Integer_Variable_0 <= 0) xor (Integer_Variable_1 >= 1) ) holds for: <this.free, this.capacity_>
    // Spec: (this.free <= 0) xor (this.capacity_ >= 1)
   examples.RingBuffer<Integer> buffer = new examples.RingBuffer<>(1);
   buffer.extend(1);

   buffer.remove();

   boolean countLessThanEqualZero = buffer.count() <= 0;
   boolean capacityGreaterThanOrEqualOne = buffer.capacity() >= 1;
   boolean xorResult = countLessThanEqualZero ^ capacityGreaterThanOrEqualOne;

   // assertion removed: xorResult;
}

@Test
public void testRemove_1() throws Throwable {
    // Spec: FuzzedInvariant ( (Integer_Variable_0 != 1) iff (Integer_Variable_1 != Integer_Variable_2) ) holds for: <this.start , this.capacity_ , orig(this.start)>
    // Spec: (this.start != 1) iff (this.capacity_ != old(this.start))
   examples.RingBuffer<Integer> ringBuffer = new examples.RingBuffer<>(5);
   ringBuffer.extend(1);
   ringBuffer.extend(2);
   ringBuffer.extend(3);
   ringBuffer.extend(4);
   ringBuffer.extend(5);
   int origCount = ringBuffer.count();
   ringBuffer.remove();
   int newCount = ringBuffer.count();

   boolean condition = newCount == origCount - 1;
}

@Test
public void testRemove_1() throws Throwable {
    // Spec: FuzzedInvariant ( (Integer_Variable_0 != 1) iff (Integer_Variable_1 != Integer_Variable_2) ) holds for: <this.start , this.capacity_ , orig(this.start)>
    // Spec: (this.start != 1) iff (this.capacity_ != old(this.start))
   examples.RingBuffer<Integer> ringBuffer = new examples.RingBuffer<>(5);
   ringBuffer.extend(1);
   ringBuffer.extend(2);
   ringBuffer.extend(3);
   ringBuffer.extend(4);
   ringBuffer.extend(5);
   int origCount = ringBuffer.count();
   ringBuffer.remove();
   int newCount = ringBuffer.count();

   boolean condition = newCount == origCount - 1;
   // assertion removed: condition;
}

@Test
public void testRemove_1() throws Throwable {
    // Spec: this.start == 1
    // Spec: this.start == 1
   examples.RingBuffer<String> buffer = new examples.RingBuffer<>(5);
   buffer.extend("element1");
   buffer.extend("element2");
   buffer.extend("element3");
   buffer.remove();

}

@Test
public void testRemove_1() throws Throwable {
    // Spec: this.start == 1
    // Spec: this.start == 1
   examples.RingBuffer<String> buffer = new examples.RingBuffer<>(5);
   buffer.extend("element1");
   buffer.extend("element2");
   buffer.extend("element3");
   buffer.remove();

   buffer.count();
}

@Test
public void testRemove_1() throws Throwable {
    // Spec: FuzzedInvariant ( (Integer_Variable_0 != 1) xor (Integer_Variable_1 <= 1) ) holds for: <this.start, this.free>
    // Spec: (this.start != 1) xor (this.free <= 1)
    examples.RingBuffer<Integer> ringBuffer = new examples.RingBuffer<>(5);

    ringBuffer.extend(1);
    ringBuffer.extend(2);
    ringBuffer.extend(3);

    int origCount = ringBuffer.count();

    ringBuffer.remove();

}

@Test
public void testRemove_1() throws Throwable {
    // Spec: FuzzedInvariant ( (Integer_Variable_0 != 1) xor (Integer_Variable_1 <= 1) ) holds for: <this.start, this.free>
    // Spec: (this.start != 1) xor (this.free <= 1)
    examples.RingBuffer<Integer> ringBuffer = new examples.RingBuffer<>(5);

    ringBuffer.extend(1);
    ringBuffer.extend(2);
    ringBuffer.extend(3);

    int origCount = ringBuffer.count();

    ringBuffer.remove();

}

@Test
public void testRemove_1() throws Throwable {
    // Spec: FuzzedInvariant ( Integer_Variable_0 != Integer_Variable_1 - Integer_Variable_2 ) holds for: <this.start , this.free , this.capacity_>
    // Spec: this.start != this.free - this.capacity_
   examples.RingBuffer<Integer> ringBuffer = new examples.RingBuffer<>(1);
   ringBuffer.extend(1);

   ringBuffer.remove();

}

@Test
public void testRemove_1() throws Throwable {
    // Spec: FuzzedInvariant ( Integer_Variable_0 != Integer_Variable_1 - Integer_Variable_2 ) holds for: <this.start , this.free , this.capacity_>
    // Spec: this.start != this.free - this.capacity_
   examples.RingBuffer<Integer> ringBuffer = new examples.RingBuffer<>(1);
   ringBuffer.extend(1);

   ringBuffer.remove();

   ringBuffer.isEmpty();
}

@Test
public void testRemove_1() throws Throwable {
    // Spec: FuzzedInvariant ( Integer_Variable_0 > Integer_Variable_1 - Integer_Variable_2 ) holds for: <this.start , this.free , this.capacity_>
    // Spec: this.start > this.free - this.capacity_
   examples.RingBuffer<Integer> ringBuffer = new examples.RingBuffer<>(5);
   ringBuffer.extend(1);
   ringBuffer.extend(2);
   ringBuffer.extend(3);
   ringBuffer.extend(4);
   ringBuffer.extend(5);
   ringBuffer.remove();

}

@Test
public void testRemove_1() throws Throwable {
    // Spec: FuzzedInvariant ( Integer_Variable_0 > Integer_Variable_1 - Integer_Variable_2 ) holds for: <this.start , this.free , this.capacity_>
    // Spec: this.start > this.free - this.capacity_
   examples.RingBuffer<Integer> ringBuffer = new examples.RingBuffer<>(5);
   ringBuffer.extend(1);
   ringBuffer.extend(2);
   ringBuffer.extend(3);
   ringBuffer.extend(4);
   ringBuffer.extend(5);
   ringBuffer.remove();

   // assertion removed: ringBuffer.count() == 4;
}

@Test
public void testRemove_1() throws Throwable {
    // Spec: FuzzedInvariant ( Integer_Variable_0 >= Integer_Variable_1 - 1 ) holds for: <this.start, this.free>
    // Spec: this.start >= this.free - 1
   examples.RingBuffer<Integer> ringBuffer = new examples.RingBuffer<Integer>(5);
   ringBuffer.extend(1);
   ringBuffer.extend(2);
   ringBuffer.extend(3);
   ringBuffer.remove();
   ringBuffer.remove();
   ringBuffer.remove();


   ringBuffer.extend(4);
   ringBuffer.extend(5);
   ringBuffer.extend(6);

   ringBuffer.remove();

}

@Test
public void testRemove_1() throws Throwable {
    // Spec: FuzzedInvariant ( Integer_Variable_0 >= Integer_Variable_1 - 1 ) holds for: <this.start, this.free>
    // Spec: this.start >= this.free - 1
   examples.RingBuffer<Integer> ringBuffer = new examples.RingBuffer<Integer>(5);
   ringBuffer.extend(1);
   ringBuffer.extend(2);
   ringBuffer.extend(3);
   ringBuffer.remove();
   ringBuffer.remove();
   ringBuffer.remove();

   ringBuffer.count();

   ringBuffer.extend(4);
   ringBuffer.extend(5);
   ringBuffer.extend(6);

   ringBuffer.remove();

   // assertion removed: ringBuffer.count() >= 0 && ringBuffer.count() <= ringBuffer.capacity();
}

@Test
public void testRemove_2() throws Throwable {
    // Spec: FuzzedInvariant ( Integer_Variable_0 >= Integer_Variable_1 - 1 ) holds for: <this.start, this.free>
    // Spec: this.start >= this.free - 1
   examples.RingBuffer<Integer> ringBuffer = new examples.RingBuffer<Integer>(5);
   ringBuffer.extend(1);
   ringBuffer.remove();
}

@Test
public void testRemove_2() throws Throwable {
    // Spec: FuzzedInvariant ( Integer_Variable_0 >= Integer_Variable_1 - 1 ) holds for: <this.start, this.free>
    // Spec: this.start >= this.free - 1
   examples.RingBuffer<Integer> ringBuffer = new examples.RingBuffer<Integer>(5);
   ringBuffer.extend(1);
   ringBuffer.remove();
   // assertion removed: ringBuffer.count() == 0;
}