@Test
public void testPush_1() throws Throwable {
    // Spec: daikon.Quant.memberOf(\old(x_object) , this.theArray )
    // Spec: memberOf(old(x_object) , this.theArray )
   DataStructures.StackAr stack = new DataStructures.StackAr(10);
   Object x_object = "test";
   stack.push(x_object);
   stack.push("new test");
   boolean memberOf = false;
   while (!stack.isEmpty()) {
       Object top = stack.top();
       stack.pop();
       if (top.equals(x_object)) {
           memberOf = true;
           break;
       }
   }
}

@Test
public void testPush_1() throws Throwable {
    // Spec: daikon.Quant.memberOf(\old(x_object) , this.theArray )
    // Spec: memberOf(old(x_object) , this.theArray )
   DataStructures.StackAr stack = new DataStructures.StackAr(10);
   Object x_object = "test";
   stack.push(x_object);
   stack.push("new test");
   boolean memberOf = false;
   while (!stack.isEmpty()) {
       Object top = stack.top();
       stack.pop();
       if (top.equals(x_object)) {
           memberOf = true;
           break;
       }
   }
   // assertion removed: memberOf;
}