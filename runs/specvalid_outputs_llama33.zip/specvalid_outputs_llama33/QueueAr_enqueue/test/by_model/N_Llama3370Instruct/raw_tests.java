@Test
public void testEnqueue_1() throws Throwable {
    // Spec: FuzzedInvariant ( (Integer_Variable_0 = 0) iff (Integer_Variable_1 < Integer_Variable_2) ) holds for: <this.currentSize , this.back , orig(this.currentSize)>
    // Spec: (this.currentSize = 0) iff (this.back < old(this.currentSize))
   DataStructures.QueueAr queue = new DataStructures.QueueAr(5);
   queue.enqueue("item1");
   queue.enqueue("item2");
   queue.enqueue("item3");
   queue.enqueue("item4");
   queue.enqueue("item5");

   DataStructures.QueueAr origQueue = queue;

   queue.enqueue("item6");

   boolean currentSizeEqualsZero = queue.isEmpty();
   boolean backLessThanOldCurrentSize = false;

   if (!queue.isEmpty() && queue.isFull()) {
       backLessThanOldCurrentSize = true;
   }

   if (currentSizeEqualsZero != backLessThanOldCurrentSize) {
       System.out.println("currentSizeEqualsZero: " + currentSizeEqualsZero);
       System.out.println("backLessThanOldCurrentSize: " + backLessThanOldCurrentSize);
       assert false;
   }
}

@Test
public void testEnqueue_1() throws Throwable {
    // Spec: FuzzedInvariant ( (Integer_Variable_0 = 0) iff (Integer_Variable_1 < Integer_Variable_2) ) holds for: <this.currentSize , this.back , orig(this.currentSize)>
    // Spec: (this.currentSize = 0) iff (this.back < old(this.currentSize))
   DataStructures.QueueAr queue = new DataStructures.QueueAr(5);
   queue.enqueue("item1");
   queue.enqueue("item2");
   queue.enqueue("item3");
   queue.enqueue("item4");
   queue.enqueue("item5");

   DataStructures.QueueAr origQueue = queue;

   queue.enqueue("item6");

   boolean currentSizeEqualsZero = queue.isEmpty();
   boolean backLessThanOldCurrentSize = false;

   if (!queue.isEmpty() && queue.isFull()) {
       backLessThanOldCurrentSize = true;
   }

   if (currentSizeEqualsZero != backLessThanOldCurrentSize) {
       System.out.println("currentSizeEqualsZero: " + currentSizeEqualsZero);
       System.out.println("backLessThanOldCurrentSize: " + backLessThanOldCurrentSize);
       assert false;
   }
}

@Test
public void testEnqueue_1() throws Throwable {
    // Spec: \old(x) == daikon.Quant.getElement_Object(this.theArray, this.back)
    // Spec: old(x) == getElement_Object(this.theArray, this.back)
   DataStructures.QueueAr queue = new DataStructures.QueueAr(5);
   Object x = new Object();
   Object origX = x;

   queue.enqueue(x);

   assertTrue(origX == queue.getFront());
}

@Test
public void testEnqueue_1() throws Throwable {
    // Spec: \old(x) == daikon.Quant.getElement_Object(this.theArray, this.back)
    // Spec: old(x) == getElement_Object(this.theArray, this.back)
   DataStructures.QueueAr queue = new DataStructures.QueueAr(5);
   Object x = new Object();
   Object origX = x;

   queue.enqueue(x);

   // assertion removed: origX == queue.getFront();
}

    @Test
    public void testEnqueue_1() throws Throwable {
    // Spec: \old(x) == daikon.Quant.getElement_Object(this.theArray, this.back)
    // Spec: old(x) == getElement_Object(this.theArray, this.back)
        DataStructures.QueueAr queue = new DataStructures.QueueAr(5);
        Object x = new Object();
        Object origX = x;

        queue.enqueue(x);

        java.lang.reflect.Field theArrayField = DataStructures.QueueAr.class.getDeclaredField("theArray");
        theArrayField.setAccessible(true);
        Object[] theArray = (Object[]) theArrayField.get(queue);

        java.lang.reflect.Field backField = DataStructures.QueueAr.class.getDeclaredField("back");
        backField.setAccessible(true);
        int back = (int) backField.get(queue);
        assertTrue(origX == theArray[(back - 1 + theArray.length) % theArray.length]);
    }

    @Test
    public void testEnqueue_1() throws Throwable {
    // Spec: \old(x) == daikon.Quant.getElement_Object(this.theArray, this.back)
    // Spec: old(x) == getElement_Object(this.theArray, this.back)
        DataStructures.QueueAr queue = new DataStructures.QueueAr(5);
        Object x = new Object();
        Object origX = x;

        queue.enqueue(x);

        java.lang.reflect.Field theArrayField = DataStructures.QueueAr.class.getDeclaredField("theArray");
        theArrayField.setAccessible(true);
        Object[] theArray = (Object[]) theArrayField.get(queue);

        java.lang.reflect.Field backField = DataStructures.QueueAr.class.getDeclaredField("back");
        backField.setAccessible(true);
        int back = (int) backField.get(queue);
        // assertion removed: origX == theArray[(back - 1 + theArray.length) % theArray.length];
    }

@Test
public void testEnqueue_1() throws Throwable {
    // Spec: daikon.Quant.memberOf(\old(x) , this.theArray )
    // Spec: memberOf(old(x) , this.theArray )
   DataStructures.QueueAr queue = new DataStructures.QueueAr(5);
   Object x = "test";

   queue.enqueue(x);

   boolean found = false;
   for (int i = 0; i < 5; i++) {
       try {
           Object obj = queue.getFront();
           for (int j = 0; j < i; j++) {
               queue.enqueue(queue.dequeue());
           }
           if (queue.getFront().equals(x)) {
               found = true;
           }
           for (int j = 0; j <= i; j++) {
               queue.dequeue();
           }
           queue.enqueue(obj);
           break;
       } catch (NullPointerException e) {
           continue;
       }
   }
   assertTrue(found);
}

@Test
public void testEnqueue_1() throws Throwable {
    // Spec: daikon.Quant.memberOf(\old(x) , this.theArray )
    // Spec: memberOf(old(x) , this.theArray )
   DataStructures.QueueAr queue = new DataStructures.QueueAr(5);
   Object x = "test";

   queue.enqueue(x);

   boolean found = false;
   for (int i = 0; i < 5; i++) {
       try {
           Object obj = queue.getFront();
           for (int j = 0; j < i; j++) {
               queue.enqueue(queue.dequeue());
           }
           if (queue.getFront().equals(x)) {
               found = true;
           }
           for (int j = 0; j <= i; j++) {
               queue.dequeue();
           }
           queue.enqueue(obj);
           break;
       } catch (NullPointerException e) {
           continue;
       }
   }
   // assertion removed: found;
}

@Test
public void testEnqueue_1() throws Throwable {
    // Spec: FuzzedInvariant ( (Integer_Variable_0 >= Integer_Variable_1) implies (Integer_Variable_1 >= Integer_Variable_2) ) holds for: <this.front , this.back , orig(this.currentSize)>
    // Spec: (this.front >= this.back) implies (this.back >= old(this.currentSize))
   DataStructures.QueueAr queue = new DataStructures.QueueAr(3);
   queue.enqueue("A");
   queue.enqueue("B");

   int origCurrentSize = queue.isEmpty() ? 0 : queue.getFront() != null ? 2 : 0;

   queue.enqueue("C");

   assertTrue((queue.getFront().equals("A") && queue.getFront() != null) || (queue.isEmpty()));
}

@Test
public void testEnqueue_1() throws Throwable {
    // Spec: FuzzedInvariant ( (Integer_Variable_0 >= Integer_Variable_1) implies (Integer_Variable_1 >= Integer_Variable_2) ) holds for: <this.front , this.back , orig(this.currentSize)>
    // Spec: (this.front >= this.back) implies (this.back >= old(this.currentSize))
   DataStructures.QueueAr queue = new DataStructures.QueueAr(3);
   queue.enqueue("A");
   queue.enqueue("B");

   int origCurrentSize = queue.isEmpty() ? 0 : queue.getFront() != null ? 2 : 0;

   queue.enqueue("C");

   // assertion removed: (queue.getFront().equals("A") && queue.getFront() != null) || (queue.isEmpty());
}

@Test
public void testEnqueue_1() throws Throwable {
    // Spec: FuzzedInvariant ( (Integer_Variable_0 = 1) implies (Integer_Variable_1 = Integer_Variable_2) ) holds for: <this.currentSize , this.front , this.back>
    // Spec: (this.currentSize = 1) implies (this.front = this.back)
   DataStructures.QueueAr queue = new DataStructures.QueueAr(2);
   queue.enqueue("A");
   queue.enqueue("B");
   queue.dequeue();
   queue.enqueue("C");

   assertTrue((queue.isEmpty()) == (queue.getFront() == null));
}

@Test
public void testEnqueue_1() throws Throwable {
    // Spec: FuzzedInvariant ( (Integer_Variable_0 = 1) implies (Integer_Variable_1 = Integer_Variable_2) ) holds for: <this.currentSize , this.front , this.back>
    // Spec: (this.currentSize = 1) implies (this.front = this.back)
   DataStructures.QueueAr queue = new DataStructures.QueueAr(2);
   queue.enqueue("A");
   queue.enqueue("B");
   queue.dequeue();
   queue.enqueue("C");

   // assertion removed: (queue.isEmpty()) == (queue.getFront() == null);
}

@Test
public void testEnqueue_1() throws Throwable {
    // Spec: FuzzedInvariant ( (Integer_Variable_0 = Integer_Variable_1) or (Integer_Variable_1 > Integer_Variable_2) ) holds for: <this.front , this.back , orig(this.back)>
    // Spec: (this.front = this.back) or (this.back > old(this.back))
   DataStructures.QueueAr queue = new DataStructures.QueueAr(10);
   queue.enqueue("A");
   queue.enqueue("B");
   queue.enqueue("C");
   int origSize = queue.isEmpty() ? 0 : queue.size();

   queue.dequeue();
   queue.enqueue("D");

   assertTrue((queue.isEmpty() ? 0 : queue.size()) == 3);
}

@Test
public void testEnqueue_1() throws Throwable {
    // Spec: FuzzedInvariant ( (Integer_Variable_0 = Integer_Variable_1) or (Integer_Variable_1 > Integer_Variable_2) ) holds for: <this.front , this.back , orig(this.back)>
    // Spec: (this.front = this.back) or (this.back > old(this.back))
   DataStructures.QueueAr queue = new DataStructures.QueueAr(10);
   queue.enqueue("A");
   queue.enqueue("B");
   queue.enqueue("C");
   int origSize = queue.isEmpty() ? 0 : queue.size();

   queue.dequeue();
   queue.enqueue("D");

   // assertion removed: (queue.isEmpty() ? 0 : queue.size()) == 3;
}

@Test
public void testEnqueue_1() throws Throwable {
    // Spec: FuzzedInvariant ( (Integer_Variable_0 != Integer_Variable_1) or (Integer_Variable_1 >= Integer_Variable_2) ) holds for: <this.currentSize , this.back , orig(this.back)>
    // Spec: (this.currentSize != this.back) or (this.back >= old(this.back))
   DataStructures.QueueAr queue = new DataStructures.QueueAr(5);
   int origSize = queue.isEmpty() ? 0 : queue.size();

   queue.enqueue("test");

   assertTrue(queue.size() == (origSize + 1));
}

@Test
public void testEnqueue_1() throws Throwable {
    // Spec: FuzzedInvariant ( (Integer_Variable_0 != Integer_Variable_1) or (Integer_Variable_1 >= Integer_Variable_2) ) holds for: <this.currentSize , this.back , orig(this.back)>
    // Spec: (this.currentSize != this.back) or (this.back >= old(this.back))
   DataStructures.QueueAr queue = new DataStructures.QueueAr(5);
   int origSize = queue.isEmpty() ? 0 : queue.size();

   queue.enqueue("test");

   // assertion removed: queue.size() == (origSize + 1);
}

@Test
public void testEnqueue_1() throws Throwable {
    // Spec: FuzzedInvariant ( (Integer_Variable_0 < 1) implies (Integer_Variable_1 >= Integer_Variable_2) ) holds for: <this.currentSize , this.back , orig(this.back)>
    // Spec: (this.currentSize < 1) implies (this.back >= old(this.back))
   DataStructures.QueueAr queue = new DataStructures.QueueAr(1);
   queue.enqueue("test");
   queue.dequeue();

   queue.enqueue("test2");

   assertTrue(queue.getFront() != null);
}

@Test
public void testEnqueue_1() throws Throwable {
    // Spec: FuzzedInvariant ( (Integer_Variable_0 < 1) implies (Integer_Variable_1 >= Integer_Variable_2) ) holds for: <this.currentSize , this.back , orig(this.back)>
    // Spec: (this.currentSize < 1) implies (this.back >= old(this.back))
   DataStructures.QueueAr queue = new DataStructures.QueueAr(1);
   queue.enqueue("test");
   queue.dequeue();

   queue.enqueue("test2");

   // assertion removed: queue.getFront() != null;
}

@Test
public void testEnqueue_1() throws Throwable {
    // Spec: \old(daikon.Quant.getElement_Object(this.theArray, \new(this.back))) == \old(daikon.Quant.getElement_Object(this.theArray, this.currentSize))
    // Spec: old(getElement_Object(this.theArray, new(this.back))) == old(getElement_Object(this.theArray, this.currentSize))
   DataStructures.QueueAr queue = new DataStructures.QueueAr(5);
   Object x = new Object();

   queue.enqueue(x);

   try {
       queue.enqueue(new Object());
   } catch (DataStructures.Overflow e) {
       // Ignore DataStructures.Overflow exception
   }

   assertNotEquals(x, queue.getFront());
}

@Test
public void testEnqueue_1() throws Throwable {
    // Spec: \old(daikon.Quant.getElement_Object(this.theArray, \new(this.back))) == \old(daikon.Quant.getElement_Object(this.theArray, this.currentSize))
    // Spec: old(getElement_Object(this.theArray, new(this.back))) == old(getElement_Object(this.theArray, this.currentSize))
   DataStructures.QueueAr queue = new DataStructures.QueueAr(5);
   Object x = new Object();

   queue.enqueue(x);

   try {
       queue.enqueue(new Object());
   } catch (DataStructures.Overflow e) {
       // Ignore DataStructures.Overflow exception
   }

   queue.getFront();
}

@Test
public void testEnqueue_1() throws Throwable {
    // Spec: FuzzedInvariant ( Integer_Variable_0 = Integer_Variable_1 - Integer_Variable_2 ) holds for: <this.front , this.back , orig(this.currentSize)>
    // Spec: this.front = this.back - old(this.currentSize)
   DataStructures.QueueAr queue = new DataStructures.QueueAr(5);
   queue.enqueue("A");
   queue.enqueue("B");
   queue.enqueue("C");
   queue.enqueue("D");
   queue.enqueue("E");

   DataStructures.QueueAr origQueue = queue;

   try {
       queue.enqueue("F");
   } catch (DataStructures.Overflow overflow) {
       // Ignore overflow exception
   }

   assertEquals(0, 4);
}

@Test
public void testEnqueue_1() throws Throwable {
    // Spec: FuzzedInvariant ( Integer_Variable_0 = Integer_Variable_1 - Integer_Variable_2 ) holds for: <this.front , this.back , orig(this.currentSize)>
    // Spec: this.front = this.back - old(this.currentSize)
   DataStructures.QueueAr queue = new DataStructures.QueueAr(5);
   queue.enqueue("A");
   queue.enqueue("B");
   queue.enqueue("C");
   queue.enqueue("D");
   queue.enqueue("E");

   DataStructures.QueueAr origQueue = queue;

   try {
       queue.enqueue("F");
   } catch (DataStructures.Overflow overflow) {
       // Ignore overflow exception
   }

   // assertion removed: 4;
}

@Test
public void testEnqueue_1() throws Throwable {
    // Spec: FuzzedInvariant ( (Integer_Variable_0 < Integer_Variable_1) implies (Integer_Variable_1 >= Integer_Variable_2) ) holds for: <this.front , this.back , orig(this.currentSize)>
    // Spec: (this.front < this.back) implies (this.back >= old(this.currentSize))
   DataStructures.QueueAr queue = new DataStructures.QueueAr(10);
   queue.enqueue("A");
   queue.enqueue("B");
   queue.enqueue("C");
   int originalCurrentSize = queue.currentSize(); // There is no public method currentSize.

   // You could create a public method currentSize() in your DataStructures.QueueAr class:
   // public int currentSize() { return this.currentSize; }

   // Or remove the line, as it's not used anywhere else in the test
   queue.enqueue("D");

   assertFalse((queue.getFront().toString().compareTo(queue.getFront().toString()) < 0) && (queue.getFront().toString().compareTo(Integer.toString(4)) < 0));
}

@Test
public void testEnqueue_1() throws Throwable {
    // Spec: FuzzedInvariant ( (Integer_Variable_0 < Integer_Variable_1) implies (Integer_Variable_1 >= Integer_Variable_2) ) holds for: <this.front , this.back , orig(this.currentSize)>
    // Spec: (this.front < this.back) implies (this.back >= old(this.currentSize))
   DataStructures.QueueAr queue = new DataStructures.QueueAr(10);
   queue.enqueue("A");
   queue.enqueue("B");
   queue.enqueue("C");
   int originalCurrentSize = queue.currentSize(); // There is no public method currentSize.

   // You could create a public method currentSize() in your DataStructures.QueueAr class:
   // public int currentSize() { return this.currentSize; }

   // Or remove the line, as it's not used anywhere else in the test
   queue.enqueue("D");

   // assertion removed: (queue.getFront().toString().compareTo(queue.getFront().toString()) < 0) && (queue.getFront().toString().compareTo(Integer.toString(4)) < 0);
}

@Test
public void testEnqueue_1() throws Throwable {
    // Spec: FuzzedInvariant ( (Integer_Variable_0 <= 1) or (Integer_Variable_1 < Integer_Variable_2) ) holds for: <this.currentSize , this.front , this.back>
    // Spec: (this.currentSize <= 1) or (this.front < this.back)
   DataStructures.QueueAr queue = new DataStructures.QueueAr(3);

   queue.enqueue("a");
   queue.enqueue("b");
   queue.enqueue("c");

   DataStructures.QueueAr origQueue = queue;

   try {
       queue.enqueue("d");
       assertTrue(false);
   } catch (DataStructures.Overflow e) {
       assertTrue(true);
   }

}

@Test
public void testEnqueue_1() throws Throwable {
    // Spec: FuzzedInvariant ( (Integer_Variable_0 <= 1) or (Integer_Variable_1 < Integer_Variable_2) ) holds for: <this.currentSize , this.front , this.back>
    // Spec: (this.currentSize <= 1) or (this.front < this.back)
   DataStructures.QueueAr queue = new DataStructures.QueueAr(3);

   queue.enqueue("a");
   queue.enqueue("b");
   queue.enqueue("c");

   DataStructures.QueueAr origQueue = queue;

   try {
       queue.enqueue("d");
       // assertion removed: false;
   } catch (DataStructures.Overflow e) {
       // assertion removed: true;
   }

}

@Test
public void testEnqueue_1() throws Throwable {
    // Spec: FuzzedInvariant ( (Integer_Variable_0 <= 1) or (Integer_Variable_1 < Integer_Variable_2) ) holds for: <this.currentSize , this.front , this.back>
    // Spec: (this.currentSize <= 1) or (this.front < this.back)
   DataStructures.QueueAr queue = new DataStructures.QueueAr(3);

   queue.enqueue("a");
   queue.enqueue("b");

   DataStructures.QueueAr origQueue = queue;

   queue.enqueue("c");
   queue.dequeue();

   queue.enqueue("d");

   assertTrue((queue.isEmpty()) || (queue.getFront() != null));
}

@Test
public void testEnqueue_1() throws Throwable {
    // Spec: FuzzedInvariant ( (Integer_Variable_0 <= 1) or (Integer_Variable_1 < Integer_Variable_2) ) holds for: <this.currentSize , this.front , this.back>
    // Spec: (this.currentSize <= 1) or (this.front < this.back)
   DataStructures.QueueAr queue = new DataStructures.QueueAr(3);

   queue.enqueue("a");
   queue.enqueue("b");

   DataStructures.QueueAr origQueue = queue;

   queue.enqueue("c");
   queue.dequeue();

   queue.enqueue("d");

   // assertion removed: (queue.isEmpty()) || (queue.getFront() != null);
}

@Test
public void testEnqueue_1() throws Throwable {
    // Spec: this.front == 0 || this.front == 1 || this.front == 2
    // Spec: this.front == 0 || this.front == 1 || this.front == 2
   DataStructures.QueueAr queue = new DataStructures.QueueAr(5);
   for (int i = 0; i < 4; i++) {
       queue.enqueue("test");
   }

   queue.enqueue("test");

   // Check if front is not 0, 1, or 2 after enqueue
   java.lang.reflect.Field f = queue.getClass().getDeclaredField("front");
   f.setAccessible(true);
   assertFalse((int)f.get(queue) == 0 || (int)f.get(queue) == 1 || (int)f.get(queue) == 2);
}

@Test
public void testEnqueue_1() throws Throwable {
    // Spec: this.front == 0 || this.front == 1 || this.front == 2
    // Spec: this.front == 0 || this.front == 1 || this.front == 2
   DataStructures.QueueAr queue = new DataStructures.QueueAr(5);
   for (int i = 0; i < 4; i++) {
       queue.enqueue("test");
   }

   queue.enqueue("test");

   // Check if front is not 0, 1, or 2 after enqueue
   java.lang.reflect.Field f = queue.getClass().getDeclaredField("front");
   f.setAccessible(true);
   // assertion removed: (int)f.get(queue) == 0 || (int)f.get(queue) == 1 || (int)f.get(queue) == 2;
}

@Test
public void testEnqueue_1() throws Throwable {
    // Spec: FuzzedInvariant ( (Integer_Variable_0 = 1) implies (Integer_Variable_1 = Integer_Variable_2) ) holds for: <this.front , orig(this.currentSize) , orig(this.back)>
    // Spec: (this.front = 1) implies (old(this.currentSize) = old(this.back))
   DataStructures.QueueAr queue = new DataStructures.QueueAr(5);
   queue.enqueue("elem1");
   queue.enqueue("elem2");

   int origCurrentSize = queue.getSize();
   queue.enqueue("elem3");

   if (queue.getSize() == origCurrentSize + 1) {
       assertTrue(queue.getSize() == origCurrentSize + 1);
   }
}

@Test
public void testEnqueue_1() throws Throwable {
    // Spec: FuzzedInvariant ( (Integer_Variable_0 = 1) implies (Integer_Variable_1 = Integer_Variable_2) ) holds for: <this.front , orig(this.currentSize) , orig(this.back)>
    // Spec: (this.front = 1) implies (old(this.currentSize) = old(this.back))
   DataStructures.QueueAr queue = new DataStructures.QueueAr(5);
   queue.enqueue("elem1");
   queue.enqueue("elem2");

   int origCurrentSize = queue.getSize();
   queue.enqueue("elem3");

   if (queue.getSize() == origCurrentSize + 1) {
       // assertion removed: queue.getSize() == origCurrentSize + 1;
   }
}