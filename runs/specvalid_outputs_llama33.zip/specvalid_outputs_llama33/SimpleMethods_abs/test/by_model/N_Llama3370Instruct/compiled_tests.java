@Test
public void testAbs_1() throws Throwable {
    // Spec: FuzzedInvariant ( (Integer_Variable_0 > Integer_Variable_1) implies (Integer_Variable_1 < -1) ) holds for: <orig(x), return>
    // Spec: (old(x) > return) implies (return < -1)
   int x = -1;
   int result = new examples.SimpleMethods().abs(x);
   if (x > result) {
   }
}

@Test
public void testAbs_1() throws Throwable {
    // Spec: FuzzedInvariant ( (Integer_Variable_0 > Integer_Variable_1) implies (Integer_Variable_1 < -1) ) holds for: <orig(x), return>
    // Spec: (old(x) > return) implies (return < -1)
   int x = -1;
   int result = new examples.SimpleMethods().abs(x);
   if (x > result) {
       // assertion removed: result < -1;
   }
}

@Test
public void testAbs_1() throws Throwable {
    // Spec: FuzzedInvariant ( (Integer_Variable_0 > 1) implies (Integer_Variable_1 > 1) ) holds for: <orig(x), return>
    // Spec: (old(x) > 1) implies (return > 1)
   examples.SimpleMethods simpleMethods = new examples.SimpleMethods();
   int x = 1;

   int result = simpleMethods.abs(x);

   if (x > 1) {
   }
}

@Test
public void testAbs_1() throws Throwable {
    // Spec: FuzzedInvariant ( (Integer_Variable_0 > 1) implies (Integer_Variable_1 > 1) ) holds for: <orig(x), return>
    // Spec: (old(x) > 1) implies (return > 1)
   examples.SimpleMethods simpleMethods = new examples.SimpleMethods();
   int x = 1;

   int result = simpleMethods.abs(x);

   if (x > 1) {
       // assertion removed: result > 1;
   }
}