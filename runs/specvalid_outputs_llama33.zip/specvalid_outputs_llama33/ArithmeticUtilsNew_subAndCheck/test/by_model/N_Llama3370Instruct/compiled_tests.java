@Test
public void testSubAndCheck_1() throws Throwable {
    // Spec: FuzzedInvariant ( Long_Variable_0 = Long_Variable_1 + Long_Variable_2 ) holds for: <orig(a) , orig(b) , return>
    // Spec: old(a) = old(b) + return
   long a = Long.MAX_VALUE;
   long b = 1;

   try {
       org.apache.commons.math3.util.ArithmeticUtilsNew instance = new org.apache.commons.math3.util.ArithmeticUtilsNew();
       long result = instance.subAndCheck(a, b);
   } catch (org.apache.commons.math3.exception.MathArithmeticException e) {
       // expected
   }
}

@Test
public void testSubAndCheck_1() throws Throwable {
    // Spec: FuzzedInvariant ( Long_Variable_0 = Long_Variable_1 + Long_Variable_2 ) holds for: <orig(a) , orig(b) , return>
    // Spec: old(a) = old(b) + return
   long a = Long.MAX_VALUE;
   long b = 1;

   try {
       org.apache.commons.math3.util.ArithmeticUtilsNew instance = new org.apache.commons.math3.util.ArithmeticUtilsNew();
       long result = instance.subAndCheck(a, b);
       // assertion removed: b + result;
   } catch (org.apache.commons.math3.exception.MathArithmeticException e) {
       // expected
   }
}

@Test
public void testSubAndCheck_1() throws Throwable {
    // Spec: FuzzedInvariant ( Long_Variable_0 >= Long_Variable_1 + Long_Variable_2 ) holds for: <orig(a) , orig(b) , return>
    // Spec: old(a) >= old(b) + return
   long a = Long.MIN_VALUE;
   long b = Long.MIN_VALUE;
   long origA = a;

   org.apache.commons.math3.util.ArithmeticUtilsNew arithmeticUtilsNew = new org.apache.commons.math3.util.ArithmeticUtilsNew();
   long result = arithmeticUtilsNew.subAndCheck(a, b);

}

@Test
public void testSubAndCheck_1() throws Throwable {
    // Spec: FuzzedInvariant ( Long_Variable_0 >= Long_Variable_1 + Long_Variable_2 ) holds for: <orig(a) , orig(b) , return>
    // Spec: old(a) >= old(b) + return
   long a = Long.MIN_VALUE;
   long b = Long.MIN_VALUE;
   long origA = a;

   org.apache.commons.math3.util.ArithmeticUtilsNew arithmeticUtilsNew = new org.apache.commons.math3.util.ArithmeticUtilsNew();
   long result = arithmeticUtilsNew.subAndCheck(a, b);

   // assertion removed: origA >= origA - result;
}