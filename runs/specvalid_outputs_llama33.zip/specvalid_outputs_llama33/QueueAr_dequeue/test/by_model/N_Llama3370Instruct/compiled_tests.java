    @Test
    public void testDequeue_1() throws Throwable {
    // Spec: FuzzedInvariant ( Integer_Variable_0 <= Integer_Variable_1 * Integer_Variable_2 ) holds for: <this.currentSize , this.back , this.front>
    // Spec: this.currentSize <= this.back * this.front
        DataStructures.QueueAr queue = new DataStructures.QueueAr(10);
        queue.enqueue("item1");
        queue.enqueue("item2");
        queue.dequeue();

    }

    @Test
    public void testDequeue_1() throws Throwable {
    // Spec: FuzzedInvariant ( Integer_Variable_0 <= Integer_Variable_1 * Integer_Variable_2 ) holds for: <this.currentSize , this.back , this.front>
    // Spec: this.currentSize <= this.back * this.front
        DataStructures.QueueAr queue = new DataStructures.QueueAr(10);
        queue.enqueue("item1");
        queue.enqueue("item2");
        queue.dequeue();

        queue.isEmpty();
    }

    @Test
    public void testDequeue_1() throws Throwable {
    // Spec: FuzzedInvariant ( Integer_Variable_0 <= Integer_Variable_1 - -1 ) holds for: <this.currentSize, this.front>
    // Spec: this.currentSize <= this.front - -1
        DataStructures.QueueAr queue = new DataStructures.QueueAr(10);
        queue.enqueue("item1");
        queue.enqueue("item2");
        queue.dequeue();

    }

@Test
public void testDequeue_1() throws Throwable {
    // Spec: FuzzedInvariant ( Integer_Variable_0 >= Integer_Variable_1 + -1 ) holds for: <this.back, this.front>
    // Spec: this.back >= this.front + -1
   DataStructures.QueueAr queue = new DataStructures.QueueAr(1);
   queue.enqueue("item");

   queue.dequeue();

}

@Test
public void testDequeue_1() throws Throwable {
    // Spec: FuzzedInvariant ( Integer_Variable_0 >= Integer_Variable_1 + -1 ) holds for: <this.back, this.front>
    // Spec: this.back >= this.front + -1
   DataStructures.QueueAr queue = new DataStructures.QueueAr(1);
   queue.enqueue("item");

   queue.dequeue();

   queue.isEmpty();
}

    @Test
    public void testDequeue() throws Throwable {
    // Spec: FuzzedInvariant ( Integer_Variable_0 <= Integer_Variable_1 + Integer_Variable_2 ) holds for: <this.currentSize , this.back , this.front>
    // Spec: this.currentSize <= this.back + this.front
        DataStructures.QueueAr queue = new DataStructures.QueueAr(5);
        queue.enqueue("A");
        queue.enqueue("B");
        queue.enqueue("C");
        queue.dequeue();
        queue.dequeue();
        queue.dequeue();

    }

    @Test
    public void testDequeue() throws Throwable {
    // Spec: FuzzedInvariant ( Integer_Variable_0 <= Integer_Variable_1 + Integer_Variable_2 ) holds for: <this.currentSize , this.back , this.front>
    // Spec: this.currentSize <= this.back + this.front
        DataStructures.QueueAr queue = new DataStructures.QueueAr(5);
        queue.enqueue("A");
        queue.enqueue("B");
        queue.enqueue("C");
        queue.dequeue();
        queue.dequeue();
        queue.dequeue();

        queue.isEmpty();
    }

@Test
public void testDequeue_1() throws Throwable {
    // Spec: this.currentSize == 0
    // Spec: this.currentSize == 0
   DataStructures.QueueAr queue = new DataStructures.QueueAr(10);
   queue.enqueue("item1");
   queue.enqueue("item2");

   queue.dequeue();

}

@Test
public void testDequeue_1() throws Throwable {
    // Spec: this.currentSize == 0
    // Spec: this.currentSize == 0
   DataStructures.QueueAr queue = new DataStructures.QueueAr(10);
   queue.enqueue("item1");
   queue.enqueue("item2");

   queue.dequeue();

   queue.isEmpty();
}

@Test
public void testDequeue_1() throws Throwable {
    // Spec: this.front == 0 || this.front == 1 || this.front == 2
    // Spec: this.front == 0 || this.front == 1 || this.front == 2
   DataStructures.QueueAr queue = new DataStructures.QueueAr(5);
   queue.enqueue("A");
   queue.enqueue("B");
   queue.enqueue("C");
   queue.enqueue("D");
   queue.enqueue("E");

   queue.dequeue();
   queue.dequeue();
   queue.dequeue();

   DataStructures.QueueAr origQueue = queue;

   queue.dequeue();

}

@Test
public void testDequeue_1() throws Throwable {
    // Spec: this.front == 0 || this.front == 1 || this.front == 2
    // Spec: this.front == 0 || this.front == 1 || this.front == 2
   DataStructures.QueueAr queue = new DataStructures.QueueAr(5);
   queue.enqueue("A");
   queue.enqueue("B");
   queue.enqueue("C");
   queue.enqueue("D");
   queue.enqueue("E");

   queue.dequeue();
   queue.dequeue();
   queue.dequeue();

   DataStructures.QueueAr origQueue = queue;

   queue.dequeue();

   // assertion removed: queue.isEmpty() || queue.getFront() != null;
}

@Test
public void testDequeue_1() throws Throwable {
    // Spec: FuzzedInvariant ( (Integer_Variable_0 <= Integer_Variable_1) or (Integer_Variable_1 = 1) ) holds for: <this.currentSize, this.front>
    // Spec: (this.currentSize <= this.front) or (this.front = 1)
   DataStructures.QueueAr queue = new DataStructures.QueueAr(10);
   queue.enqueue("item1");
   queue.enqueue("item2");
   queue.enqueue("item3");

   Object result = queue.dequeue();

}

@Test
public void testDequeue_1() throws Throwable {
    // Spec: FuzzedInvariant ( (Integer_Variable_0 <= Integer_Variable_1) or (Integer_Variable_1 = 1) ) holds for: <this.currentSize, this.front>
    // Spec: (this.currentSize <= this.front) or (this.front = 1)
   DataStructures.QueueAr queue = new DataStructures.QueueAr(10);
   queue.enqueue("item1");
   queue.enqueue("item2");
   queue.enqueue("item3");

   Object result = queue.dequeue();

   // assertion removed: queue.isEmpty() || queue.getFront() == null;
}