@Test
public void testInsert_r_1() throws Throwable {
    // Spec: daikon.Quant.size(this._var49) == 1 || daikon.Quant.size(this._var49) == 2 || daikon.Quant.size(this._var49) == 3
    // Spec: size(this._var49) == 1 || size(this._var49) == 2 || size(this._var49) == 3
    // Create list of 3 elements
    java.util.ArrayList<examples.R> RList = new java.util.ArrayList<>();
    RList.add(null);
    RList.add(null);
    RList.add(null);

    examples.ListComp02 obj = new examples.ListComp02(RList, new java.util.ArrayList<examples.S>());

    obj.insert_r(null);

    // Use reflection to access the private field _var49
    java.lang.reflect.Field field = obj.getClass().getDeclaredField("_var49");
    field.setAccessible(true);
    java.util.ArrayList<?> list = (java.util.ArrayList<?>) field.get(obj);
    int size = list.size();

}

@Test
public void testInsert_r_1() throws Throwable {
    // Spec: daikon.Quant.size(this._var49) == 1 || daikon.Quant.size(this._var49) == 2 || daikon.Quant.size(this._var49) == 3
    // Spec: size(this._var49) == 1 || size(this._var49) == 2 || size(this._var49) == 3
    // Create list of 3 elements
    java.util.ArrayList<examples.R> RList = new java.util.ArrayList<>();
    RList.add(null);
    RList.add(null);
    RList.add(null);

    examples.ListComp02 obj = new examples.ListComp02(RList, new java.util.ArrayList<examples.S>());

    obj.insert_r(null);

    // Use reflection to access the private field _var49
    java.lang.reflect.Field field = obj.getClass().getDeclaredField("_var49");
    field.setAccessible(true);
    java.util.ArrayList<?> list = (java.util.ArrayList<?>) field.get(obj);
    int size = list.size();

    // assertion removed: size == 1 || size == 2 || size == 3;
}

@Test
public void testInsert_r_1() throws Throwable {
    // Spec: daikon.Quant.size(this._var49) == 1 || daikon.Quant.size(this._var49) == 2 || daikon.Quant.size(this._var49) == 3
    // Spec: size(this._var49) == 1 || size(this._var49) == 2 || size(this._var49) == 3
    java.util.ArrayList<examples.R> RList = new java.util.ArrayList<>();
    RList.add(new examples.R(1, "a"));
    RList.add(new examples.R(1, "b"));
    RList.add(new examples.R(1, "c"));

    examples.ListComp02 obj = new examples.ListComp02(RList, new java.util.ArrayList<examples.S>());

    obj.insert_r(new examples.R(1, "d"));

    int size = RList.size();
}

@Test
public void testInsert_r_1() throws Throwable {
    // Spec: daikon.Quant.size(this._var49) == 1 || daikon.Quant.size(this._var49) == 2 || daikon.Quant.size(this._var49) == 3
    // Spec: size(this._var49) == 1 || size(this._var49) == 2 || size(this._var49) == 3
    java.util.ArrayList<examples.R> RList = new java.util.ArrayList<>();
    RList.add(new examples.R(1, "a"));
    RList.add(new examples.R(1, "b"));
    RList.add(new examples.R(1, "c"));

    examples.ListComp02 obj = new examples.ListComp02(RList, new java.util.ArrayList<examples.S>());

    obj.insert_r(new examples.R(1, "d"));

    int size = RList.size();
    // assertion removed: size;
}

   @Test
   public void testInsert_r_1() throws Throwable {
    // Spec: daikon.Quant.size(this._var49) == 1 || daikon.Quant.size(this._var49) == 2 || daikon.Quant.size(this._var49) == 3
    // Spec: size(this._var49) == 1 || size(this._var49) == 2 || size(this._var49) == 3
            java.util.ArrayList RList = new java.util.ArrayList();
            RList.add(null);
            RList.add(null);
            RList.add(null);

            java.util.ArrayList SList = new java.util.ArrayList();

            examples.ListComp02 obj = new examples.ListComp02(RList, SList);

            obj.insert_r(null);

            // Access the private field via reflection
            java.lang.reflect.Field field = examples.ListComp02.class.getDeclaredField("_var49");
            field.setAccessible(true);
            java.util.ArrayList list = (java.util.ArrayList) field.get(obj);
            int size = list.size();

   }

   @Test
   public void testInsert_r_1() throws Throwable {
    // Spec: daikon.Quant.size(this._var49) == 1 || daikon.Quant.size(this._var49) == 2 || daikon.Quant.size(this._var49) == 3
    // Spec: size(this._var49) == 1 || size(this._var49) == 2 || size(this._var49) == 3
            java.util.ArrayList RList = new java.util.ArrayList();
            RList.add(null);
            RList.add(null);
            RList.add(null);

            java.util.ArrayList SList = new java.util.ArrayList();

            examples.ListComp02 obj = new examples.ListComp02(RList, SList);

            obj.insert_r(null);

            // Access the private field via reflection
            java.lang.reflect.Field field = examples.ListComp02.class.getDeclaredField("_var49");
            field.setAccessible(true);
            java.util.ArrayList list = (java.util.ArrayList) field.get(obj);
            int size = list.size();

            // assertion removed: size == 1 || size == 2 || size == 3;
   }

@Test
public void testInsert_r_1() throws Throwable {
    // Spec: daikon.Quant.size(this._var49) == 1 || daikon.Quant.size(this._var49) == 2 || daikon.Quant.size(this._var49) == 3
    // Spec: size(this._var49) == 1 || size(this._var49) == 2 || size(this._var49) == 3
    java.util.ArrayList rawRList = new java.util.ArrayList();
    rawRList.add(null);
    rawRList.add(null);
    rawRList.add(null);

    java.util.ArrayList rawSList = new java.util.ArrayList();

    // Create the object
    examples.ListComp02 obj = new examples.ListComp02(rawRList, rawSList);

    // Insert one more element
    obj.insert_r(null);

    // Now check the size of _var49 using reflection
    java.lang.reflect.Field field = obj.getClass().getDeclaredField("_var49");
    field.setAccessible(true);
    java.util.ArrayList list = (java.util.ArrayList) field.get(obj);
    int size = list.size();
}

@Test
public void testInsert_r_1() throws Throwable {
    // Spec: daikon.Quant.size(this._var49) == 1 || daikon.Quant.size(this._var49) == 2 || daikon.Quant.size(this._var49) == 3
    // Spec: size(this._var49) == 1 || size(this._var49) == 2 || size(this._var49) == 3
    java.util.ArrayList rawRList = new java.util.ArrayList();
    rawRList.add(null);
    rawRList.add(null);
    rawRList.add(null);

    java.util.ArrayList rawSList = new java.util.ArrayList();

    // Create the object
    examples.ListComp02 obj = new examples.ListComp02(rawRList, rawSList);

    // Insert one more element
    obj.insert_r(null);

    // Now check the size of _var49 using reflection
    java.lang.reflect.Field field = obj.getClass().getDeclaredField("_var49");
    field.setAccessible(true);
    java.util.ArrayList list = (java.util.ArrayList) field.get(obj);
    int size = list.size();
    // assertion removed: size == 1 || size == 2 || size == 3;
}

@Test
          public void testInsert_r_1() throws Throwable {
    // Spec: daikon.Quant.size(this._var49) == 1 || daikon.Quant.size(this._var49) == 2 || daikon.Quant.size(this._var49) == 3
    // Spec: size(this._var49) == 1 || size(this._var49) == 2 || size(this._var49) == 3
              java.util.ArrayList rawRList = new java.util.ArrayList();
              rawRList.add(null);
              rawRList.add(null);
              rawRList.add(null);
              java.util.ArrayList rawSList = new java.util.ArrayList();
              examples.ListComp02 obj = new examples.ListComp02(rawRList, rawSList);
              obj.insert_r(null);
              // We cannot access obj._var49 because it is private, so we use the rawRList we passed to the constructor
              int size = rawRList.size();
          }

@Test
          public void testInsert_r_1() throws Throwable {
    // Spec: daikon.Quant.size(this._var49) == 1 || daikon.Quant.size(this._var49) == 2 || daikon.Quant.size(this._var49) == 3
    // Spec: size(this._var49) == 1 || size(this._var49) == 2 || size(this._var49) == 3
              java.util.ArrayList rawRList = new java.util.ArrayList();
              rawRList.add(null);
              rawRList.add(null);
              rawRList.add(null);
              java.util.ArrayList rawSList = new java.util.ArrayList();
              examples.ListComp02 obj = new examples.ListComp02(rawRList, rawSList);
              obj.insert_r(null);
              // We cannot access obj._var49 because it is private, so we use the rawRList we passed to the constructor
              int size = rawRList.size();
              // assertion removed: size == 1 || size == 2 || size == 3;
          }

    @Test
    public void testInsert_r_1() throws Throwable {
    // Spec: daikon.Quant.size(this._var49) == 1 || daikon.Quant.size(this._var49) == 2 || daikon.Quant.size(this._var49) == 3
    // Spec: size(this._var49) == 1 || size(this._var49) == 2 || size(this._var49) == 3

        java.util.ArrayList rawRList = new java.util.ArrayList();
        rawRList.add(null);
        rawRList.add(null);
        rawRList.add(null);
        // Create an empty list for Ss
        java.util.ArrayList rawSList = new java.util.ArrayList();
        // Construct the object
        examples.ListComp02 obj = new examples.ListComp02(rawRList, rawSList);

        obj.insert_r(null);

        // Instead of accessing obj._var49, use rawRList because it is the same object
        int size = rawRList.size();

    }

    @Test
    public void testInsert_r_1() throws Throwable {
    // Spec: daikon.Quant.size(this._var49) == 1 || daikon.Quant.size(this._var49) == 2 || daikon.Quant.size(this._var49) == 3
    // Spec: size(this._var49) == 1 || size(this._var49) == 2 || size(this._var49) == 3

        java.util.ArrayList rawRList = new java.util.ArrayList();
        rawRList.add(null);
        rawRList.add(null);
        rawRList.add(null);
        // Create an empty list for Ss
        java.util.ArrayList rawSList = new java.util.ArrayList();
        // Construct the object
        examples.ListComp02 obj = new examples.ListComp02(rawRList, rawSList);

        obj.insert_r(null);

        // Instead of accessing obj._var49, use rawRList because it is the same object
        int size = rawRList.size();

        // assertion removed: "Postcondition violated: size = " + size, size == 1 || size == 2 || size == 3;
    }

   @Test
    public void testInsert_r_Counterexample() throws Throwable {
    // Spec: daikon.Quant.size(this._var49) == 1 || daikon.Quant.size(this._var49) == 2 || daikon.Quant.size(this._var49) == 3
    // Spec: size(this._var49) == 1 || size(this._var49) == 2 || size(this._var49) == 3

        java.util.ArrayList rawListR = new java.util.ArrayList();
        rawListR.add(null);
        rawListR.add(null);
        rawListR.add(null);  // Initial size = 3

        java.util.ArrayList rawListS = new java.util.ArrayList();

        examples.ListComp02 listComp = new examples.ListComp02(rawListR, rawListS);

        listComp.insert_r(null);

        // Instead of accessing private field `_var49` directly, use reflection to get it
        java.lang.reflect.Field field = listComp.getClass().getDeclaredField("_var49");
        field.setAccessible(true);
        java.util.ArrayList<?> list = (java.util.ArrayList<?>) field.get(listComp);
        int actualSize = list.size();

    }

   @Test
    public void testInsert_r_Counterexample() throws Throwable {
    // Spec: daikon.Quant.size(this._var49) == 1 || daikon.Quant.size(this._var49) == 2 || daikon.Quant.size(this._var49) == 3
    // Spec: size(this._var49) == 1 || size(this._var49) == 2 || size(this._var49) == 3

        java.util.ArrayList rawListR = new java.util.ArrayList();
        rawListR.add(null);
        rawListR.add(null);
        rawListR.add(null);  // Initial size = 3

        java.util.ArrayList rawListS = new java.util.ArrayList();

        examples.ListComp02 listComp = new examples.ListComp02(rawListR, rawListS);

        listComp.insert_r(null);

        // Instead of accessing private field `_var49` directly, use reflection to get it
        java.lang.reflect.Field field = listComp.getClass().getDeclaredField("_var49");
        field.setAccessible(true);
        java.util.ArrayList<?> list = (java.util.ArrayList<?>) field.get(listComp);
        int actualSize = list.size();

        // assertion removed: actualSize == 1 || actualSize == 2 || actualSize == 3;
    }