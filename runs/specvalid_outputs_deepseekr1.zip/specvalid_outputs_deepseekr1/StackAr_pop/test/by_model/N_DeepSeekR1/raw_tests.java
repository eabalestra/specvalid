                @Test
                public void testPopPostcondition() throws Throwable {
    // Spec: FuzzedInvariant ( (Integer_Variable_0 > 1) implies (Integer_Variable_1 <= -1) ) holds for: <this.topOfStack, orig(this.topOfStack)>
    // Spec: (this.topOfStack > 1) implies (old(this.topOfStack) <= -1)
                    DataStructures.StackAr stack = new DataStructures.StackAr(10);
                    // Push four elements
                    stack.push(1);
                    stack.push(2);
                    stack.push(3);
                    stack.push(4);

                    // We need the old topOfStack
                    java.lang.reflect.Field topField = DataStructures.StackAr.class.getDeclaredField("topOfStack");
                    topField.setAccessible(true);
                    int oldTop = (int) topField.get(stack);

                    // Call pop
                    stack.pop();

                    int newTop = (int) topField.get(stack);

                    // Check the condition: (newTop > 1) implies (oldTop <= -1)
                    // which is: ! (newTop > 1) || (oldTop <= -1)
                    assertTrue("Violated postcondition: (topOfStack>1) should imply old(topOfStack)<=-1", 
                        newTop <= 1 || oldTop <= -1);
                }

                @Test
                public void testPopPostcondition() throws Throwable {
    // Spec: FuzzedInvariant ( (Integer_Variable_0 > 1) implies (Integer_Variable_1 <= -1) ) holds for: <this.topOfStack, orig(this.topOfStack)>
    // Spec: (this.topOfStack > 1) implies (old(this.topOfStack) <= -1)
                    DataStructures.StackAr stack = new DataStructures.StackAr(10);
                    // Push four elements
                    stack.push(1);
                    stack.push(2);
                    stack.push(3);
                    stack.push(4);

                    // We need the old topOfStack
                    java.lang.reflect.Field topField = DataStructures.StackAr.class.getDeclaredField("topOfStack");
                    topField.setAccessible(true);
                    int oldTop = (int) topField.get(stack);

                    // Call pop
                    stack.pop();

                    int newTop = (int) topField.get(stack);

                    // Check the condition: (newTop > 1) implies (oldTop <= -1)
                    // which is: ! (newTop > 1) || (oldTop <= -1)
                    // assertion removed: newTop <= 1 || oldTop <= -1;
                }

                @Test
                public void testPopViolatesPostcondition() throws Throwable {
    // Spec: FuzzedInvariant ( (Integer_Variable_0 > 1) implies (Integer_Variable_1 <= -1) ) holds for: <this.topOfStack, orig(this.topOfStack)>
    // Spec: (this.topOfStack > 1) implies (old(this.topOfStack) <= -1)
                    DataStructures.StackAr stack = new DataStructures.StackAr(10);
                    // Push four elements
                    stack.push(10);
                    stack.push(20);
                    stack.push(30);
                    stack.push(40);

                    // Use reflection to access the private field "topOfStack"
                    java.lang.reflect.Field topField = DataStructures.StackAr.class.getDeclaredField("topOfStack");
                    topField.setAccessible(true);
                    int oldTopOfStack = (int) topField.get(stack);

                    // Perform the pop operation
                    stack.pop();

                    int newTopOfStack = (int) topField.get(stack);

                    // The postcondition: (newTopOfStack > 1) implies (oldTopOfStack <= -1)
                    // We write: !(newTopOfStack > 1) || (oldTopOfStack <= -1)
                    // And we must assert this condition will hold, but in our counterexample it fails.
                    // Therefore, we write an assertTrue that we expect to hold? 
                    // But we know it fails? Actually, this test is meant to demonstrate the violation.
                    // So we put the postcondition as the condition in the assert, and if it fails the test fails? 
                    // But we are the ones providing the test as a counterexample. 
                    // So the test should be designed to fail? because the postcondition is violated.

                    // We write:
                    assertTrue("Postcondition violated: (this.topOfStack > 1) should imply old(this.topOfStack)<=-1, but after popping, topOfStack="+newTopOfStack+" and old top="+oldTopOfStack, 
                               newTopOfStack <= 1 || oldTopOfStack <= -1);
                }

                @Test
                public void testPopViolatesPostcondition() throws Throwable {
    // Spec: FuzzedInvariant ( (Integer_Variable_0 > 1) implies (Integer_Variable_1 <= -1) ) holds for: <this.topOfStack, orig(this.topOfStack)>
    // Spec: (this.topOfStack > 1) implies (old(this.topOfStack) <= -1)
                    DataStructures.StackAr stack = new DataStructures.StackAr(10);
                    // Push four elements
                    stack.push(10);
                    stack.push(20);
                    stack.push(30);
                    stack.push(40);

                    // Use reflection to access the private field "topOfStack"
                    java.lang.reflect.Field topField = DataStructures.StackAr.class.getDeclaredField("topOfStack");
                    topField.setAccessible(true);
                    int oldTopOfStack = (int) topField.get(stack);

                    // Perform the pop operation
                    stack.pop();

                    int newTopOfStack = (int) topField.get(stack);

                    // The postcondition: (newTopOfStack > 1) implies (oldTopOfStack <= -1)
                    // We write: !(newTopOfStack > 1) || (oldTopOfStack <= -1)
                    // And we must assert this condition will hold, but in our counterexample it fails.
                    // Therefore, we write an assertTrue that we expect to hold? 
                    // But we know it fails? Actually, this test is meant to demonstrate the violation.
                    // So we put the postcondition as the condition in the assert, and if it fails the test fails? 
                    // But we are the ones providing the test as a counterexample. 
                    // So the test should be designed to fail? because the postcondition is violated.

                    // We write:
                    // assertion removed: "Postcondition violated: (this.topOfStack > 1) should imply old(this.topOfStack)<=-1, but after popping, topOfStack="+newTopOfStack+" and old top="+oldTopOfStack, 
                               newTopOfStack <= 1 || oldTopOfStack <= -1;
                }

            @Test
            public void testPopPostcondition() throws Throwable {
    // Spec: FuzzedInvariant ( (Integer_Variable_0 > 1) implies (Integer_Variable_1 <= -1) ) holds for: <this.topOfStack, orig(this.topOfStack)>
    // Spec: (this.topOfStack > 1) implies (old(this.topOfStack) <= -1)
                DataStructures.StackAr stack = new DataStructures.StackAr(10);
                stack.push(10);
                stack.push(20);
                stack.push(30);
                stack.push(40);

                java.lang.reflect.Field topField = DataStructures.StackAr.class.getDeclaredField("topOfStack");
                topField.setAccessible(true);
                int oldTopOfStack = (int) topField.get(stack);

                stack.pop();

                int newTopOfStack = (int) topField.get(stack);

                // Check: (newTopOfStack > 1) -> (oldTopOfStack <= -1) is false in this case.
                assertTrue(newTopOfStack <= 1 || oldTopOfStack <= -1);
            }

            @Test
            public void testPopPostcondition() throws Throwable {
    // Spec: FuzzedInvariant ( (Integer_Variable_0 > 1) implies (Integer_Variable_1 <= -1) ) holds for: <this.topOfStack, orig(this.topOfStack)>
    // Spec: (this.topOfStack > 1) implies (old(this.topOfStack) <= -1)
                DataStructures.StackAr stack = new DataStructures.StackAr(10);
                stack.push(10);
                stack.push(20);
                stack.push(30);
                stack.push(40);

                java.lang.reflect.Field topField = DataStructures.StackAr.class.getDeclaredField("topOfStack");
                topField.setAccessible(true);
                int oldTopOfStack = (int) topField.get(stack);

                stack.pop();

                int newTopOfStack = (int) topField.get(stack);

                // Check: (newTopOfStack > 1) -> (oldTopOfStack <= -1) is false in this case.
                // assertion removed: newTopOfStack <= 1 || oldTopOfStack <= -1;
            }

   @Test
   public void testPop() throws Throwable {
    // Spec: FuzzedInvariant ( (Integer_Variable_0 > 1) implies (Integer_Variable_1 <= -1) ) holds for: <this.topOfStack, orig(this.topOfStack)>
    // Spec: (this.topOfStack > 1) implies (old(this.topOfStack) <= -1)
        DataStructures.StackAr stack = new DataStructures.StackAr();
        stack.push(-9);
        stack.push(-9); // now the stack has two -9, the top is the last pushed

        // Now pop one element
        stack.pop();

        // Now the top should be the first pushed element, which is -9
        assertEquals(-9, stack.top());

        // Also, the stack should not be empty
        assertFalse(stack.isEmpty());
   }

   @Test
   public void testPop() throws Throwable {
    // Spec: FuzzedInvariant ( (Integer_Variable_0 > 1) implies (Integer_Variable_1 <= -1) ) holds for: <this.topOfStack, orig(this.topOfStack)>
    // Spec: (this.topOfStack > 1) implies (old(this.topOfStack) <= -1)
        DataStructures.StackAr stack = new DataStructures.StackAr();
        stack.push(-9);
        stack.push(-9); // now the stack has two -9, the top is the last pushed

        // Now pop one element
        stack.pop();

        // Now the top should be the first pushed element, which is -9
        stack.top();

        // Also, the stack should not be empty
        stack.isEmpty();
   }

            @Test
            public void testPopPostcondition() throws Throwable {
    // Spec: FuzzedInvariant ( (Integer_Variable_0 > 1) implies (Integer_Variable_1 <= -1) ) holds for: <this.topOfStack, orig(this.topOfStack)>
    // Spec: (this.topOfStack > 1) implies (old(this.topOfStack) <= -1)
                DataStructures.StackAr stack = new DataStructures.StackAr(10);
                stack.push(10);
                stack.push(20);
                stack.push(30);
                stack.push(40);
                
                // Get old topOfStack
                java.lang.reflect.Field topField = DataStructures.StackAr.class.getDeclaredField("topOfStack");
                topField.setAccessible(true);
                int oldTop = (int) topField.get(stack);

                stack.pop();

                int newTop = (int) topField.get(stack);

                // Check condition: (this.topOfStack>1) => (old(this.topOfStack)<=-1) 
                // which becomes: (newTop>1) => (oldTop<=-1)
                // In this test, newTop will be 2 and oldTop is 3 -> condition fails.
                assertTrue(newTop <= 1 || oldTop <= -1);
            }

            @Test
            public void testPopPostcondition() throws Throwable {
    // Spec: FuzzedInvariant ( (Integer_Variable_0 > 1) implies (Integer_Variable_1 <= -1) ) holds for: <this.topOfStack, orig(this.topOfStack)>
    // Spec: (this.topOfStack > 1) implies (old(this.topOfStack) <= -1)
                DataStructures.StackAr stack = new DataStructures.StackAr(10);
                stack.push(10);
                stack.push(20);
                stack.push(30);
                stack.push(40);
                
                // Get old topOfStack
                java.lang.reflect.Field topField = DataStructures.StackAr.class.getDeclaredField("topOfStack");
                topField.setAccessible(true);
                int oldTop = (int) topField.get(stack);

                stack.pop();

                int newTop = (int) topField.get(stack);

                // Check condition: (this.topOfStack>1) => (old(this.topOfStack)<=-1) 
                // which becomes: (newTop>1) => (oldTop<=-1)
                // In this test, newTop will be 2 and oldTop is 3 -> condition fails.
                // assertion removed: newTop <= 1 || oldTop <= -1;
            }

        @Test
        public void testPop() throws Throwable {
    // Spec: this.topOfStack == -1
    // Spec: this.topOfStack == -1
            DataStructures.StackAr stack = new DataStructures.StackAr();
            // Push two elements
            stack.push("A");
            stack.push("B");

            stack.pop();

            // After popping once, the stack should have one element, which is "A" at the top.
            assertFalse(stack.isEmpty());
            assertEquals("A", stack.top());
        }

        @Test
        public void testPop() throws Throwable {
    // Spec: this.topOfStack == -1
    // Spec: this.topOfStack == -1
            DataStructures.StackAr stack = new DataStructures.StackAr();
            // Push two elements
            stack.push("A");
            stack.push("B");

            stack.pop();

            // After popping once, the stack should have one element, which is "A" at the top.
            stack.isEmpty();
            stack.top();
        }

        @Test
        public void testPop() throws Throwable {
    // Spec: this.topOfStack == -1
    // Spec: this.topOfStack == -1
            DataStructures.StackAr stack = new DataStructures.StackAr();
            stack.push("A");
            stack.pop();   // pop the only element we have? Wait, we pushed only one?

            assertTrue(stack.isEmpty());
        }

        @Test
        public void testPop() throws Throwable {
    // Spec: this.topOfStack == -1
    // Spec: this.topOfStack == -1
            DataStructures.StackAr stack = new DataStructures.StackAr();
            stack.push("A");
            stack.pop();   // pop the only element we have? Wait, we pushed only one?

            stack.isEmpty();
        }

        @Test
        public void testPop() throws Throwable {
    // Spec: this.topOfStack == -1
    // Spec: this.topOfStack == -1
            DataStructures.StackAr stack = new DataStructures.StackAr();
            stack.push("A");
            stack.push("B");

            stack.pop();
            stack.pop();   // pop twice to make stack empty

            assertTrue(stack.isEmpty());   // use public method
        }

        @Test
        public void testPop() throws Throwable {
    // Spec: this.topOfStack == -1
    // Spec: this.topOfStack == -1
            DataStructures.StackAr stack = new DataStructures.StackAr();
            stack.push("A");
            stack.push("B");

            stack.pop();
            stack.pop();   // pop twice to make stack empty

            stack.isEmpty();   // use public method
        }

        @Test
        public void testPop() throws Throwable {
    // Spec: this.topOfStack == -1
    // Spec: this.topOfStack == -1
            DataStructures.StackAr stack = new DataStructures.StackAr();
            stack.push("A");
            stack.push("B");
            stack.pop();
            assertFalse(stack.isEmpty());
            assertEquals("A", stack.top());
        }

        @Test
        public void testPop() throws Throwable {
    // Spec: this.topOfStack == -1
    // Spec: this.topOfStack == -1
            DataStructures.StackAr stack = new DataStructures.StackAr();
            stack.push("A");
            stack.push("B");
            stack.pop();
            stack.isEmpty();
            stack.top();
        }

   @Test
   public void testPop() throws Throwable {
    // Spec: this.topOfStack == -1
    // Spec: this.topOfStack == -1
        DataStructures.StackAr stack = new DataStructures.StackAr();
        stack.push(new Object());
        stack.push(new Object());

        stack.pop();
        stack.pop();   // now we pop two times

        assertTrue(stack.isEmpty());   // after two pops, the stack should be empty
   }

   @Test
   public void testPop() throws Throwable {
    // Spec: this.topOfStack == -1
    // Spec: this.topOfStack == -1
        DataStructures.StackAr stack = new DataStructures.StackAr();
        stack.push(new Object());
        stack.push(new Object());

        stack.pop();
        stack.pop();   // now we pop two times

        stack.isEmpty();   // after two pops, the stack should be empty
   }

     @Test
     public void testPop() throws Throwable {
    // Spec: this.topOfStack == -1
    // Spec: this.topOfStack == -1
         DataStructures.StackAr stack = new DataStructures.StackAr();
         stack.push(1);
         stack.push(2);
         stack.pop();
         // Now we do: assertEquals with two objects.
         assertEquals(Integer.valueOf(1), stack.top());
         stack.pop();
         assertTrue(stack.isEmpty());
     }

     @Test
     public void testPop() throws Throwable {
    // Spec: this.topOfStack == -1
    // Spec: this.topOfStack == -1
         DataStructures.StackAr stack = new DataStructures.StackAr();
         stack.push(1);
         stack.push(2);
         stack.pop();
         // Now we do: assertEquals with two objects.
         stack.top();
         stack.pop();
         stack.isEmpty();
     }

        @Test
        public void testPopCounterexample() throws Throwable {
    // Spec: this.topOfStack == -1
    // Spec: this.topOfStack == -1
            DataStructures.StackAr stack = new DataStructures.StackAr();
            stack.push(1);
            stack.pop();   // Now stack should be empty
            assertTrue(stack.isEmpty());
        }

        @Test
        public void testPopCounterexample() throws Throwable {
    // Spec: this.topOfStack == -1
    // Spec: this.topOfStack == -1
            DataStructures.StackAr stack = new DataStructures.StackAr();
            stack.push(1);
            stack.pop();   // Now stack should be empty
            stack.isEmpty();
        }

     @Test
     public void testPop_1() throws Throwable {
    // Spec: this.topOfStack == -1
    // Spec: this.topOfStack == -1
         DataStructures.StackAr stack = new DataStructures.StackAr();
         stack.push(1);
         stack.push(2);
         stack.pop();
         stack.pop();   // second pop to empty the stack
         assertTrue(stack.isEmpty());
     }

     @Test
     public void testPop_1() throws Throwable {
    // Spec: this.topOfStack == -1
    // Spec: this.topOfStack == -1
         DataStructures.StackAr stack = new DataStructures.StackAr();
         stack.push(1);
         stack.push(2);
         stack.pop();
         stack.pop();   // second pop to empty the stack
         stack.isEmpty();
     }

   @Test
   public void testPop_1() throws Throwable {
    // Spec: this.topOfStack == -1
    // Spec: this.topOfStack == -1
       DataStructures.StackAr stack = new DataStructures.StackAr();
       stack.push(1);
       stack.push(2);
       stack.pop(); // removes 2
       stack.pop(); // removes 1 -> now empty
       assertTrue(stack.isEmpty());
   }

   @Test
   public void testPop_1() throws Throwable {
    // Spec: this.topOfStack == -1
    // Spec: this.topOfStack == -1
       DataStructures.StackAr stack = new DataStructures.StackAr();
       stack.push(1);
       stack.push(2);
       stack.pop(); // removes 2
       stack.pop(); // removes 1 -> now empty
       stack.isEmpty();
   }

   @Test
   public void testPop_1() throws Throwable {
    // Spec: this.topOfStack == -1
    // Spec: this.topOfStack == -1
       DataStructures.StackAr stack = new DataStructures.StackAr();
       stack.push(1);
       stack.push(2);
       stack.pop();
       // After popping, there is one element left. So:
       assertFalse(stack.isEmpty());   // test it is not empty
       assertEquals(1, stack.top());   // and the top is 1
   }

   @Test
   public void testPop_1() throws Throwable {
    // Spec: this.topOfStack == -1
    // Spec: this.topOfStack == -1
       DataStructures.StackAr stack = new DataStructures.StackAr();
       stack.push(1);
       stack.push(2);
       stack.pop();
       // After popping, there is one element left. So:
       stack.isEmpty();   // test it is not empty
       stack.top();   // and the top is 1
   }

          @Test
          public void testPop_1() throws Throwable {
    // Spec: this.topOfStack == -1
    // Spec: this.topOfStack == -1
              DataStructures.StackAr stack = new DataStructures.StackAr();
              try {
                stack.push(1);
                stack.pop();
              } catch (DataStructures.OverflowException e) {
                fail("Unexpected OverflowException");
              } catch (DataStructures.UnderflowException e) {
                fail("Unexpected UnderflowException");
              }
              assertTrue(stack.isEmpty());
          }

          @Test
          public void testPop_1() throws Throwable {
    // Spec: this.topOfStack == -1
    // Spec: this.topOfStack == -1
              DataStructures.StackAr stack = new DataStructures.StackAr();
              try {
                stack.push(1);
                stack.pop();
              } catch (DataStructures.OverflowException e) {
                // fail removed;
              } catch (DataStructures.UnderflowException e) {
                // fail removed;
              }
              stack.isEmpty();
          }

      @Test
      public void testPop_1() throws Throwable {
    // Spec: this.topOfStack == -1
    // Spec: this.topOfStack == -1
          DataStructures.StackAr stack = new DataStructures.StackAr();
          try {
              stack.push(1);
              stack.pop();   // only one pop
          } catch (DataStructures.OverflowException e) {
              fail("Unexpected OverflowException");
          } catch (DataStructures.UnderflowException e) {
              fail("Unexpected UnderflowException");
          }
          // Now the stack is empty? so we can check with isEmpty
          assertTrue(stack.isEmpty());
      }

      @Test
      public void testPop_1() throws Throwable {
    // Spec: this.topOfStack == -1
    // Spec: this.topOfStack == -1
          DataStructures.StackAr stack = new DataStructures.StackAr();
          try {
              stack.push(1);
              stack.pop();   // only one pop
          } catch (DataStructures.OverflowException e) {
              // fail removed;
          } catch (DataStructures.UnderflowException e) {
              // fail removed;
          }
          // Now the stack is empty? so we can check with isEmpty
          stack.isEmpty();
      }

      @Test
      public void testPop_1() throws Throwable {
    // Spec: this.topOfStack == -1
    // Spec: this.topOfStack == -1
          DataStructures.StackAr stack = new DataStructures.StackAr();
          stack.push(1);
          stack.push(2);
          stack.pop();

          // After pushing two and then popping one, there should be one element left
          assertFalse(stack.isEmpty());   // because we should have one element
          assertEquals(1, stack.top());   // and that element should be 1
      }

      @Test
      public void testPop_1() throws Throwable {
    // Spec: this.topOfStack == -1
    // Spec: this.topOfStack == -1
          DataStructures.StackAr stack = new DataStructures.StackAr();
          stack.push(1);
          stack.push(2);
          stack.pop();

          // After pushing two and then popping one, there should be one element left
          stack.isEmpty();   // because we should have one element
          stack.top();   // and that element should be 1
      }

        @Test
        public void testPop_1() throws Throwable {
    // Spec: this.topOfStack == -1
    // Spec: this.topOfStack == -1
            DataStructures.StackAr stack = new DataStructures.StackAr();
            try {
                stack.push(1);
                stack.push(2);
                stack.pop();
                stack.pop();   // pop the second element
            } catch (DataStructures.OverflowException e) {
                fail("Unexpected DataStructures.OverflowException");
            } catch (DataStructures.UnderflowException e) {
                fail("Unexpected DataStructures.UnderflowException");
            }
            // Now the stack should be empty
            assertTrue(stack.isEmpty());
        }

        @Test
        public void testPop_1() throws Throwable {
    // Spec: this.topOfStack == -1
    // Spec: this.topOfStack == -1
            DataStructures.StackAr stack = new DataStructures.StackAr();
            try {
                stack.push(1);
                stack.push(2);
                stack.pop();
                stack.pop();   // pop the second element
            } catch (DataStructures.OverflowException e) {
                // fail removed;
            } catch (DataStructures.UnderflowException e) {
                // fail removed;
            }
            // Now the stack should be empty
            stack.isEmpty();
        }

        @Test
        public void testPop_1() throws Throwable {
    // Spec: this.topOfStack == -1
    // Spec: this.topOfStack == -1
            DataStructures.StackAr stack = new DataStructures.StackAr();
            try {
                stack.push(1);
                stack.push(2);
                stack.pop();
            } catch (DataStructures.OverflowException e) {
                org.junit.Assert.fail("Unexpected DataStructures.OverflowException");
            } catch (DataStructures.UnderflowException e) {
                org.junit.Assert.fail("Unexpected DataStructures.UnderflowException");
            }

            // Now the stack should have one element: the 1 at the bottom and now at the top? 
            // Actually, after pushing 1 then 2, the stack is:
            //   index0: 1
            //   index1: 2 (top)
            // Then we pop, so we remove 2. Then the stack has only 1, and the top is 1 at index0.
            // So the top element should be 1.

            org.junit.Assert.assertFalse("Stack should not be empty after pop", stack.isEmpty());
            org.junit.Assert.assertEquals("Top element should be 1", 1, stack.top());
        }

        @Test
        public void testPop_1() throws Throwable {
    // Spec: this.topOfStack == -1
    // Spec: this.topOfStack == -1
            DataStructures.StackAr stack = new DataStructures.StackAr();
            try {
                stack.push(1);
                stack.push(2);
                stack.pop();
            } catch (DataStructures.OverflowException e) {
                org.junit.Assert.// fail removed;
            } catch (DataStructures.UnderflowException e) {
                org.junit.Assert.// fail removed;
            }

            // Now the stack should have one element: the 1 at the bottom and now at the top? 
            // Actually, after pushing 1 then 2, the stack is:
            //   index0: 1
            //   index1: 2 (top)
            // Then we pop, so we remove 2. Then the stack has only 1, and the top is 1 at index0.
            // So the top element should be 1.

            org.junit.Assert.stack.isEmpty();
            org.junit.Assert.stack.top();
        }

          @Test
          public void testPop_1() throws Throwable {
    // Spec: this.topOfStack == -1
    // Spec: this.topOfStack == -1
              DataStructures.StackAr stack = new DataStructures.StackAr();
              try {
                  stack.push(1);
                  stack.push(2);
                  stack.pop();
              } catch (DataStructures.OverflowException e) {
                  org.junit.Assert.fail("Unexpected DataStructures.OverflowException");
              } catch (DataStructures.UnderflowException e) {
                  org.junit.Assert.fail("Unexpected DataStructures.UnderflowException");
              }
              // We don't have direct access to topOfStack, so use public methods
              // Check stack is not empty and the top element is 1
              org.junit.Assert.assertFalse(stack.isEmpty());
              org.junit.Assert.assertEquals(1, stack.top());  // autoboxing will work? stack.top() returns an Object, which is an Integer? 
              // But note: assertEquals(Object, Object) can compare two Integers? 
          }

          @Test
          public void testPop_1() throws Throwable {
    // Spec: this.topOfStack == -1
    // Spec: this.topOfStack == -1
              DataStructures.StackAr stack = new DataStructures.StackAr();
              try {
                  stack.push(1);
                  stack.push(2);
                  stack.pop();
              } catch (DataStructures.OverflowException e) {
                  org.junit.Assert.// fail removed;
              } catch (DataStructures.UnderflowException e) {
                  org.junit.Assert.// fail removed;
              }
              // We don't have direct access to topOfStack, so use public methods
              // Check stack is not empty and the top element is 1
              org.junit.Assert.stack.isEmpty();
              org.junit.Assert.stack.top();  // autoboxing will work? stack.top() returns an Object, which is an Integer? 
              // But note: assertEquals(Object, Object) can compare two Integers? 
          }

    @Test
    public void testPop_1() throws Throwable {
    // Spec: this.topOfStack == -1
    // Spec: this.topOfStack == -1
        DataStructures.StackAr stack = new DataStructures.StackAr();
        try {
            stack.push(1);
            stack.push(2);
            stack.pop();
        } catch (DataStructures.OverflowException e) {
            org.junit.Assert.fail("Unexpected DataStructures.OverflowException");
        } catch (DataStructures.UnderflowException e) {
            org.junit.Assert.fail("Unexpected DataStructures.UnderflowException");
        }
        // After two pushes and one pop, the top should be 1 (the element we pushed first is now on top) and the stack should not be empty.
        org.junit.Assert.assertEquals(Integer.valueOf(1), stack.top());
    }

    @Test
    public void testPop_1() throws Throwable {
    // Spec: this.topOfStack == -1
    // Spec: this.topOfStack == -1
        DataStructures.StackAr stack = new DataStructures.StackAr();
        try {
            stack.push(1);
            stack.push(2);
            stack.pop();
        } catch (DataStructures.OverflowException e) {
            org.junit.Assert.// fail removed;
        } catch (DataStructures.UnderflowException e) {
            org.junit.Assert.// fail removed;
        }
        // After two pushes and one pop, the top should be 1 (the element we pushed first is now on top) and the stack should not be empty.
        org.junit.Assert.stack.top();
    }

    @Test
    public void testPop_1() throws Throwable {
    // Spec: FuzzedInvariant ( Integer_Variable_0 <= 1 ) holds for: this.topOfStack
    // Spec: this.topOfStack <= 1
        DataStructures.StackAr stack = new DataStructures.StackAr(10);
        stack.push(1);
        stack.push(2);
        stack.push(3);
        stack.push(4);

        try {
            stack.pop();
        } catch (DataStructures.UnderflowException e) {
            // shouldn't happen because stack is not empty
        }

        try {
            java.lang.reflect.Field topOfStackField = DataStructures.StackAr.class.getDeclaredField("topOfStack");
            topOfStackField.setAccessible(true);
            int topOfStackValue = (int) topOfStackField.get(stack);
            org.junit.Assert.assertTrue(topOfStackValue <= 1);
        } catch (NoSuchFieldException | SecurityException | IllegalAccessException e) {
            org.junit.Assert.fail("Failed to get the value of topOfStack: " + e.getMessage());
        }
    }

    @Test
    public void testPop_1() throws Throwable {
    // Spec: FuzzedInvariant ( Integer_Variable_0 <= 1 ) holds for: this.topOfStack
    // Spec: this.topOfStack <= 1
        DataStructures.StackAr stack = new DataStructures.StackAr(10);
        stack.push(1);
        stack.push(2);
        stack.push(3);
        stack.push(4);

        try {
            stack.pop();
        } catch (DataStructures.UnderflowException e) {
            // shouldn't happen because stack is not empty
        }

        try {
            java.lang.reflect.Field topOfStackField = DataStructures.StackAr.class.getDeclaredField("topOfStack");
            topOfStackField.setAccessible(true);
            int topOfStackValue = (int) topOfStackField.get(stack);
            org.junit.Assert.// assertion removed: topOfStackValue <= 1;
        } catch (NoSuchFieldException | SecurityException | IllegalAccessException e) {
            org.junit.Assert.fail("Failed to get the value of topOfStack: " + e.getMessage());
        }
    }

        @Test
        public void testPop_1() throws Throwable {
    // Spec: FuzzedInvariant ( Integer_Variable_0 <= 1 ) holds for: this.topOfStack
    // Spec: this.topOfStack <= 1
            DataStructures.StackAr stack = new DataStructures.StackAr(10);
            stack.push(1);
            stack.push(2);
            stack.push(3);
            stack.push(4);

            try {
                stack.pop();
            } catch (DataStructures.UnderflowException e) {
                fail("Unexpected UnderflowException");
            }

            // Now check the condition using reflection
            try {
                java.lang.reflect.Field topField = DataStructures.StackAr.class.getDeclaredField("topOfStack");
                topField.setAccessible(true);
                int topIndex = (int) topField.get(stack);
                assertTrue(topIndex <= 1);
            } catch (Exception e) {
                fail("Reflection failed: " + e.getMessage());
            }
        }

        @Test
        public void testPop_1() throws Throwable {
    // Spec: FuzzedInvariant ( Integer_Variable_0 <= 1 ) holds for: this.topOfStack
    // Spec: this.topOfStack <= 1
            DataStructures.StackAr stack = new DataStructures.StackAr(10);
            stack.push(1);
            stack.push(2);
            stack.push(3);
            stack.push(4);

            try {
                stack.pop();
            } catch (DataStructures.UnderflowException e) {
                // fail removed;
            }

            // Now check the condition using reflection
            try {
                java.lang.reflect.Field topField = DataStructures.StackAr.class.getDeclaredField("topOfStack");
                topField.setAccessible(true);
                int topIndex = (int) topField.get(stack);
                // assertion removed: topIndex <= 1;
            } catch (Exception e) {
                fail("Reflection failed: " + e.getMessage());
            }
        }

        @Test
        public void testPop_1() throws Throwable {
    // Spec: FuzzedInvariant ( Integer_Variable_0 <= 1 ) holds for: this.topOfStack
    // Spec: this.topOfStack <= 1
            DataStructures.StackAr stack = new DataStructures.StackAr(10);
            stack.push(1);
            stack.push(2);
            stack.push(3);
            stack.push(4);

            try {
                stack.pop();
            } catch (DataStructures.UnderflowException e) {
                fail("Unexpected UnderflowException");
            }

            // Now check the state of the stack: the top element should be 3
            assertFalse("The stack should not be empty after popping one element", stack.isEmpty());
            assertEquals(3, stack.top());
        }

        @Test
        public void testPop_1() throws Throwable {
    // Spec: FuzzedInvariant ( Integer_Variable_0 <= 1 ) holds for: this.topOfStack
    // Spec: this.topOfStack <= 1
            DataStructures.StackAr stack = new DataStructures.StackAr(10);
            stack.push(1);
            stack.push(2);
            stack.push(3);
            stack.push(4);

            try {
                stack.pop();
            } catch (DataStructures.UnderflowException e) {
                // fail removed;
            }

            // Now check the state of the stack: the top element should be 3
            stack.isEmpty();
            stack.top();
        }

@Test
public void testPop_1() throws Throwable {
    // Spec: FuzzedInvariant ( Integer_Variable_0 <= 1 ) holds for: this.topOfStack
    // Spec: this.topOfStack <= 1
   DataStructures.StackAr stack = new DataStructures.StackAr(10);
   stack.push(1);
   stack.push(2);
   stack.push(3);
   stack.push(4);
   
   stack.pop();

   // Check the new top is 3
   assertEquals(3, (int)stack.top());
}

@Test
public void testPop_1() throws Throwable {
    // Spec: FuzzedInvariant ( Integer_Variable_0 <= 1 ) holds for: this.topOfStack
    // Spec: this.topOfStack <= 1
   DataStructures.StackAr stack = new DataStructures.StackAr(10);
   stack.push(1);
   stack.push(2);
   stack.push(3);
   stack.push(4);
   
   stack.pop();

   // Check the new top is 3
   (int)stack.top();
}

   @Test
   public void testPop_1() throws Throwable {
    // Spec: FuzzedInvariant ( Integer_Variable_0 <= 1 ) holds for: this.topOfStack
    // Spec: this.topOfStack <= 1
        DataStructures.StackAr stack = new DataStructures.StackAr(10);
        stack.push(1);
        stack.push(2);
        stack.push(3);
        stack.push(4);

        try {
            stack.pop();
        } catch (DataStructures.UnderflowException e) {
            // This is unexpected, so we fail the test
            fail();
        }

        // We check that the top is now 3
        assertEquals(3, stack.top());
   }

   @Test
   public void testPop_1() throws Throwable {
    // Spec: FuzzedInvariant ( Integer_Variable_0 <= 1 ) holds for: this.topOfStack
    // Spec: this.topOfStack <= 1
        DataStructures.StackAr stack = new DataStructures.StackAr(10);
        stack.push(1);
        stack.push(2);
        stack.push(3);
        stack.push(4);

        try {
            stack.pop();
        } catch (DataStructures.UnderflowException e) {
            // This is unexpected, so we fail the test
            // fail removed;
        }

        // We check that the top is now 3
        stack.top();
   }

   @Test
   public void testPop_1() throws Throwable {
    // Spec: FuzzedInvariant ( Integer_Variable_0 <= 1 ) holds for: this.topOfStack
    // Spec: this.topOfStack <= 1
       DataStructures.StackAr stack = new DataStructures.StackAr(10);
       stack.push(1);
       stack.push(2);
       stack.push(3);
       stack.push(4);
       try {
           stack.pop();
       } catch(DataStructures.UnderflowException e) {
           fail("Unexpected exception: " + e.getMessage());
       }
       // After one pop, the top should be 3
       assertEquals(3, stack.top());
   }

   @Test
   public void testPop_1() throws Throwable {
    // Spec: FuzzedInvariant ( Integer_Variable_0 <= 1 ) holds for: this.topOfStack
    // Spec: this.topOfStack <= 1
       DataStructures.StackAr stack = new DataStructures.StackAr(10);
       stack.push(1);
       stack.push(2);
       stack.push(3);
       stack.push(4);
       try {
           stack.pop();
       } catch(DataStructures.UnderflowException e) {
           fail("Unexpected exception: " + e.getMessage());
       }
       // After one pop, the top should be 3
       stack.top();
   }

        @Test
        public void testPop_1() throws Throwable {
    // Spec: FuzzedInvariant ( Integer_Variable_0 <= 1 ) holds for: this.topOfStack
    // Spec: this.topOfStack <= 1
            DataStructures.StackAr stack = new DataStructures.StackAr(10);
            stack.push(1);
            stack.push(2);
            stack.push(3);
            stack.push(4);
            stack.pop();
            // We expect the top to be 3
            assertEquals(3, stack.top());
        }

        @Test
        public void testPop_1() throws Throwable {
    // Spec: FuzzedInvariant ( Integer_Variable_0 <= 1 ) holds for: this.topOfStack
    // Spec: this.topOfStack <= 1
            DataStructures.StackAr stack = new DataStructures.StackAr(10);
            stack.push(1);
            stack.push(2);
            stack.push(3);
            stack.push(4);
            stack.pop();
            // We expect the top to be 3
            stack.top();
        }

   @Test
   public void testPop_1() throws Throwable {
    // Spec: FuzzedInvariant ( Integer_Variable_0 <= 1 ) holds for: this.topOfStack
    // Spec: this.topOfStack <= 1
      DataStructures.StackAr stack = new DataStructures.StackAr(10);
      stack.push(1);
      stack.push(2);
      stack.push(3);
      stack.push(4);
      stack.pop();
      // After popping, the top should be 3
      assertEquals(Integer.valueOf(3), stack.top());
   }

   @Test
   public void testPop_1() throws Throwable {
    // Spec: FuzzedInvariant ( Integer_Variable_0 <= 1 ) holds for: this.topOfStack
    // Spec: this.topOfStack <= 1
      DataStructures.StackAr stack = new DataStructures.StackAr(10);
      stack.push(1);
      stack.push(2);
      stack.push(3);
      stack.push(4);
      stack.pop();
      // After popping, the top should be 3
      stack.top();
   }

        @Test
        public void testPop_1() throws Throwable {
    // Spec: FuzzedInvariant ( Integer_Variable_0 <= 1 ) holds for: this.topOfStack
    // Spec: this.topOfStack <= 1
            DataStructures.StackAr stack = new DataStructures.StackAr(10);
            try {
                stack.push(1);
                stack.push(2);
                stack.push(3);
                stack.push(4);
                stack.pop();
            } catch (DataStructures.OverflowException | DataStructures.UnderflowException e) {
                // shouldn't happen
                fail("Unexpected exception: " + e.getMessage());
            }
            // We replace the private field access with a check of the top element.
            assertEquals(3, stack.top());
        }

        @Test
        public void testPop_1() throws Throwable {
    // Spec: FuzzedInvariant ( Integer_Variable_0 <= 1 ) holds for: this.topOfStack
    // Spec: this.topOfStack <= 1
            DataStructures.StackAr stack = new DataStructures.StackAr(10);
            try {
                stack.push(1);
                stack.push(2);
                stack.push(3);
                stack.push(4);
                stack.pop();
            } catch (DataStructures.OverflowException | DataStructures.UnderflowException e) {
                // shouldn't happen
                fail("Unexpected exception: " + e.getMessage());
            }
            // We replace the private field access with a check of the top element.
            stack.top();
        }

@Test
public void testPop_1() throws Throwable {
    // Spec: FuzzedInvariant ( Integer_Variable_0 <= 1 ) holds for: this.topOfStack
    // Spec: this.topOfStack <= 1
   DataStructures.StackAr stack = new DataStructures.StackAr(10);
   try {
        stack.push(1);
        stack.push(2);
        stack.push(3);
        stack.push(4);
        stack.pop();
   } catch (DataStructures.OverflowException e) {
        fail("Unexpected OverflowException");
   } catch (DataStructures.UnderflowException e) {
        fail("Unexpected UnderflowException");
   }
   // Instead of checking the private topOfStack, check the top element
   assertEquals(3, stack.top());
}

@Test
public void testPop_1() throws Throwable {
    // Spec: FuzzedInvariant ( Integer_Variable_0 <= 1 ) holds for: this.topOfStack
    // Spec: this.topOfStack <= 1
   DataStructures.StackAr stack = new DataStructures.StackAr(10);
   try {
        stack.push(1);
        stack.push(2);
        stack.push(3);
        stack.push(4);
        stack.pop();
   } catch (DataStructures.OverflowException e) {
        // fail removed;
   } catch (DataStructures.UnderflowException e) {
        // fail removed;
   }
   // Instead of checking the private topOfStack, check the top element
   stack.top();
}

        @Test
        public void testPop_1() throws Throwable {
    // Spec: FuzzedInvariant ( Integer_Variable_0 <= 1 ) holds for: this.topOfStack
    // Spec: this.topOfStack <= 1
            DataStructures.StackAr stack = new DataStructures.StackAr(10);
            try {
                stack.push(1);
                stack.push(2);
                stack.push(3);
                stack.push(4);
                stack.pop();
            } catch (DataStructures.OverflowException | DataStructures.UnderflowException e) {
                fail("Unexpected exception: " + e.toString());
            }
            // We cannot check topOfStack because it is private, so check the top element
            assertEquals(3, stack.top());
        }

        @Test
        public void testPop_1() throws Throwable {
    // Spec: FuzzedInvariant ( Integer_Variable_0 <= 1 ) holds for: this.topOfStack
    // Spec: this.topOfStack <= 1
            DataStructures.StackAr stack = new DataStructures.StackAr(10);
            try {
                stack.push(1);
                stack.push(2);
                stack.push(3);
                stack.push(4);
                stack.pop();
            } catch (DataStructures.OverflowException | DataStructures.UnderflowException e) {
                fail("Unexpected exception: " + e.toString());
            }
            // We cannot check topOfStack because it is private, so check the top element
            stack.top();
        }

@Test
public void testPop_1() throws Throwable {
    // Spec: FuzzedInvariant ( Integer_Variable_0 <= 1 ) holds for: this.topOfStack
    // Spec: this.topOfStack <= 1
    DataStructures.StackAr stack = new DataStructures.StackAr(10);
    try {
        stack.push(1);
        stack.push(2);
        stack.push(3);
        stack.push(4);
        stack.pop();
    } catch (DataStructures.OverflowException | DataStructures.UnderflowException e) {
        fail("Unexpected exception: " + e.toString());
    }
    // Fix: Instead of checking the private field, check the public method top() to verify the top element after pop.
    assertEquals(3, stack.top());
}

@Test
public void testPop_1() throws Throwable {
    // Spec: FuzzedInvariant ( Integer_Variable_0 <= 1 ) holds for: this.topOfStack
    // Spec: this.topOfStack <= 1
    DataStructures.StackAr stack = new DataStructures.StackAr(10);
    try {
        stack.push(1);
        stack.push(2);
        stack.push(3);
        stack.push(4);
        stack.pop();
    } catch (DataStructures.OverflowException | DataStructures.UnderflowException e) {
        fail("Unexpected exception: " + e.toString());
    }
    // Fix: Instead of checking the private field, check the public method top() to verify the top element after pop.
    stack.top();
}

@Test
public void testPopPostconditionViolation() throws Throwable {
    // Spec: FuzzedInvariant ( Integer_Variable_0 <= 1 ) holds for: this.topOfStack
    // Spec: this.topOfStack <= 1
    // Setup: Stack with 4 elements -> topOfStack will be 3
    DataStructures.StackAr stack = new DataStructures.StackAr(10);
    try {
        stack.push(1);
        stack.push(2);
        stack.push(3);
        stack.push(4);
        stack.pop();  // After pop, topOfStack becomes 2
    } catch (DataStructures.OverflowException | DataStructures.UnderflowException e) {
        fail("Unexpected exception: " + e.toString());
    }

    // Use reflection to get the private field topOfStack
    java.lang.reflect.Field field = DataStructures.StackAr.class.getDeclaredField("topOfStack");
    field.setAccessible(true);
    int topIndex = (int) field.get(stack);

    // Check the postcondition: topIndex should be <= 1 -> 2 is invalid
    assertTrue("Violation: topOfStack = " + topIndex + " (expected <= 1)", topIndex <= 1);
}

@Test
public void testPopPostconditionViolation() throws Throwable {
    // Spec: FuzzedInvariant ( Integer_Variable_0 <= 1 ) holds for: this.topOfStack
    // Spec: this.topOfStack <= 1
    // Setup: Stack with 4 elements -> topOfStack will be 3
    DataStructures.StackAr stack = new DataStructures.StackAr(10);
    try {
        stack.push(1);
        stack.push(2);
        stack.push(3);
        stack.push(4);
        stack.pop();  // After pop, topOfStack becomes 2
    } catch (DataStructures.OverflowException | DataStructures.UnderflowException e) {
        fail("Unexpected exception: " + e.toString());
    }

    // Use reflection to get the private field topOfStack
    java.lang.reflect.Field field = DataStructures.StackAr.class.getDeclaredField("topOfStack");
    field.setAccessible(true);
    int topIndex = (int) field.get(stack);

    // Check the postcondition: topIndex should be <= 1 -> 2 is invalid
    // assertion removed: "Violation: topOfStack = " + topIndex + " (expected <= 1)", topIndex <= 1;
}