        @Test
        public void testInsertRight_1() throws Throwable {
    // Spec: this.left == this.right
    // Spec: this.left == this.right
            // Create three nodes: A, B, C
            examples.DoublyLinkedListNode A = new examples.DoublyLinkedListNode();
            examples.DoublyLinkedListNode B = new examples.DoublyLinkedListNode();
            examples.DoublyLinkedListNode C = new examples.DoublyLinkedListNode();

            // First, insert B to the right of A
            A.insertRight(B);

            // Now insert C to the right of A
            A.insertRight(C);

            // Using reflection to access the private field 'left' of A
            java.lang.reflect.Field leftField = examples.DoublyLinkedListNode.class.getDeclaredField("left");
            leftField.setAccessible(true);
            examples.DoublyLinkedListNode A_left = (examples.DoublyLinkedListNode) leftField.get(A);

            // Using reflection to access the private field 'right' of A
            java.lang.reflect.Field rightField = examples.DoublyLinkedListNode.class.getDeclaredField("right");
            rightField.setAccessible(true);
            examples.DoublyLinkedListNode A_right = (examples.DoublyLinkedListNode) rightField.get(A);

            // Now check the condition at A: should this.left == this.right? 
            // We expect A.left is B and A.right is C -> they are not equal.

            // The postcondition: this.left == this.right -> fails.

            // So we assert: 
        }

        @Test
        public void testInsertRight_1() throws Throwable {
    // Spec: this.left == this.right
    // Spec: this.left == this.right
            // Create three nodes: A, B, C
            examples.DoublyLinkedListNode A = new examples.DoublyLinkedListNode();
            examples.DoublyLinkedListNode B = new examples.DoublyLinkedListNode();
            examples.DoublyLinkedListNode C = new examples.DoublyLinkedListNode();

            // First, insert B to the right of A
            A.insertRight(B);

            // Now insert C to the right of A
            A.insertRight(C);

            // Using reflection to access the private field 'left' of A
            java.lang.reflect.Field leftField = examples.DoublyLinkedListNode.class.getDeclaredField("left");
            leftField.setAccessible(true);
            examples.DoublyLinkedListNode A_left = (examples.DoublyLinkedListNode) leftField.get(A);

            // Using reflection to access the private field 'right' of A
            java.lang.reflect.Field rightField = examples.DoublyLinkedListNode.class.getDeclaredField("right");
            rightField.setAccessible(true);
            examples.DoublyLinkedListNode A_right = (examples.DoublyLinkedListNode) rightField.get(A);

            // Now check the condition at A: should this.left == this.right? 
            // We expect A.left is B and A.right is C -> they are not equal.

            // The postcondition: this.left == this.right -> fails.

            // So we assert: 
            // assertion removed: A_left == A_right;
        }

            @Test
            public void testInsertRight() throws Throwable {
    // Spec: this.left == this.right
    // Spec: this.left == this.right
                // Create nodes: A (initially singleton)
                examples.DoublyLinkedListNode A = new examples.DoublyLinkedListNode();
                examples.DoublyLinkedListNode B = new examples.DoublyLinkedListNode();
                examples.DoublyLinkedListNode C = new examples.DoublyLinkedListNode();

                // First insert
                A.insertRight(B); 
                // Then insert C to the right of A (which will be between A and B)
                A.insertRight(C);

                // Now use reflection to get the left and right fields of A
                Field leftField = examples.DoublyLinkedListNode.class.getDeclaredField("left");
                leftField.setAccessible(true);
                Field rightField = examples.DoublyLinkedListNode.class.getDeclaredField("right");
                rightField.setAccessible(true);

                examples.DoublyLinkedListNode leftOfA = (DoublyLinkedListNode) leftField.get(A);
                examples.DoublyLinkedListNode rightOfA = (DoublyLinkedListNode) rightField.get(A);

                // We expect: leftOfA to be B, rightOfA to be C
            }

            @Test
            public void testInsertRight() throws Throwable {
    // Spec: this.left == this.right
    // Spec: this.left == this.right
                // Create nodes: A (initially singleton)
                examples.DoublyLinkedListNode A = new examples.DoublyLinkedListNode();
                examples.DoublyLinkedListNode B = new examples.DoublyLinkedListNode();
                examples.DoublyLinkedListNode C = new examples.DoublyLinkedListNode();

                // First insert
                A.insertRight(B); 
                // Then insert C to the right of A (which will be between A and B)
                A.insertRight(C);

                // Now use reflection to get the left and right fields of A
                Field leftField = examples.DoublyLinkedListNode.class.getDeclaredField("left");
                leftField.setAccessible(true);
                Field rightField = examples.DoublyLinkedListNode.class.getDeclaredField("right");
                rightField.setAccessible(true);

                examples.DoublyLinkedListNode leftOfA = (DoublyLinkedListNode) leftField.get(A);
                examples.DoublyLinkedListNode rightOfA = (DoublyLinkedListNode) rightField.get(A);

                // We expect: leftOfA to be B, rightOfA to be C
                // assertion removed: leftOfA == B && rightOfA == C;
            }

          @Test
          public void testInsertRight_1() throws Throwable {
    // Spec: this.left == this.right
    // Spec: this.left == this.right
              examples.DoublyLinkedListNode nodeA = new examples.DoublyLinkedListNode();
              examples.DoublyLinkedListNode nodeB = new examples.DoublyLinkedListNode();
              examples.DoublyLinkedListNode nodeC = new examples.DoublyLinkedListNode();

              nodeA.insertRight(nodeB);
              nodeA.insertRight(nodeC);

              // Use reflection to access private fields
              java.lang.reflect.Field leftField = examples.DoublyLinkedListNode.class.getDeclaredField("left");
              leftField.setAccessible(true);
              examples.DoublyLinkedListNode nodeALeft = (examples.DoublyLinkedListNode) leftField.get(nodeA);

              java.lang.reflect.Field rightField = examples.DoublyLinkedListNode.class.getDeclaredField("right");
              rightField.setAccessible(true);
              examples.DoublyLinkedListNode nodeARight = (examples.DoublyLinkedListNode) rightField.get(nodeA);

              // Now check the condition at nodeA
          }

          @Test
          public void testInsertRight_1() throws Throwable {
    // Spec: this.left == this.right
    // Spec: this.left == this.right
              examples.DoublyLinkedListNode nodeA = new examples.DoublyLinkedListNode();
              examples.DoublyLinkedListNode nodeB = new examples.DoublyLinkedListNode();
              examples.DoublyLinkedListNode nodeC = new examples.DoublyLinkedListNode();

              nodeA.insertRight(nodeB);
              nodeA.insertRight(nodeC);

              // Use reflection to access private fields
              java.lang.reflect.Field leftField = examples.DoublyLinkedListNode.class.getDeclaredField("left");
              leftField.setAccessible(true);
              examples.DoublyLinkedListNode nodeALeft = (examples.DoublyLinkedListNode) leftField.get(nodeA);

              java.lang.reflect.Field rightField = examples.DoublyLinkedListNode.class.getDeclaredField("right");
              rightField.setAccessible(true);
              examples.DoublyLinkedListNode nodeARight = (examples.DoublyLinkedListNode) rightField.get(nodeA);

              // Now check the condition at nodeA
              // assertion removed: nodeALeft == nodeARight;
          }

        @Test
        public void testInsertRight_1() throws Throwable {
    // Spec: this.left == this.right
    // Spec: this.left == this.right
            examples.DoublyLinkedListNode A = new examples.DoublyLinkedListNode();
            examples.DoublyLinkedListNode B = new examples.DoublyLinkedListNode();
            examples.DoublyLinkedListNode C = new examples.DoublyLinkedListNode();

            A.insertRight(B);
            A.insertRight(C);

            // Use reflection to access private fields
            java.lang.reflect.Field leftField = examples.DoublyLinkedListNode.class.getDeclaredField("left");
            leftField.setAccessible(true);
            examples.DoublyLinkedListNode aLeft = (examples.DoublyLinkedListNode) leftField.get(A);

            java.lang.reflect.Field rightField = examples.DoublyLinkedListNode.class.getDeclaredField("right");
            rightField.setAccessible(true);
            examples.DoublyLinkedListNode aRight = (examples.DoublyLinkedListNode) rightField.get(A);

            // After the two insertions, A's left should be B and A's right should be C
        }

        @Test
        public void testInsertRight_1() throws Throwable {
    // Spec: this.left == this.right
    // Spec: this.left == this.right
            examples.DoublyLinkedListNode A = new examples.DoublyLinkedListNode();
            examples.DoublyLinkedListNode B = new examples.DoublyLinkedListNode();
            examples.DoublyLinkedListNode C = new examples.DoublyLinkedListNode();

            A.insertRight(B);
            A.insertRight(C);

            // Use reflection to access private fields
            java.lang.reflect.Field leftField = examples.DoublyLinkedListNode.class.getDeclaredField("left");
            leftField.setAccessible(true);
            examples.DoublyLinkedListNode aLeft = (examples.DoublyLinkedListNode) leftField.get(A);

            java.lang.reflect.Field rightField = examples.DoublyLinkedListNode.class.getDeclaredField("right");
            rightField.setAccessible(true);
            examples.DoublyLinkedListNode aRight = (examples.DoublyLinkedListNode) rightField.get(A);

            // After the two insertions, A's left should be B and A's right should be C
            // assertion removed: aLeft;
            // assertion removed: aRight;
        }

          @Test
          public void testInsertRight_1() throws Throwable {
    // Spec: this.left == this.right
    // Spec: this.left == this.right
             examples.DoublyLinkedListNode A = new examples.DoublyLinkedListNode();
             examples.DoublyLinkedListNode B = new examples.DoublyLinkedListNode();

             A.insertRight(B);

             // Use fully qualified name for Field
             java.lang.reflect.Field leftField = examples.DoublyLinkedListNode.class.getDeclaredField("left");
             leftField.setAccessible(true);
             examples.DoublyLinkedListNode ALeft = (examples.DoublyLinkedListNode) leftField.get(A);

             java.lang.reflect.Field rightField = examples.DoublyLinkedListNode.class.getDeclaredField("right");
             rightField.setAccessible(true);
             examples.DoublyLinkedListNode ARight = (examples.DoublyLinkedListNode) rightField.get(A);

             // Check that A's left and right are the same? (which should be B after one insertion)
          }

          @Test
          public void testInsertRight_1() throws Throwable {
    // Spec: this.left == this.right
    // Spec: this.left == this.right
             examples.DoublyLinkedListNode A = new examples.DoublyLinkedListNode();
             examples.DoublyLinkedListNode B = new examples.DoublyLinkedListNode();

             A.insertRight(B);

             // Use fully qualified name for Field
             java.lang.reflect.Field leftField = examples.DoublyLinkedListNode.class.getDeclaredField("left");
             leftField.setAccessible(true);
             examples.DoublyLinkedListNode ALeft = (examples.DoublyLinkedListNode) leftField.get(A);

             java.lang.reflect.Field rightField = examples.DoublyLinkedListNode.class.getDeclaredField("right");
             rightField.setAccessible(true);
             examples.DoublyLinkedListNode ARight = (examples.DoublyLinkedListNode) rightField.get(A);

             // Check that A's left and right are the same? (which should be B after one insertion)
             // assertion removed: ALeft == ARight;
          }

        @Test
        public void testInsertRightPostcondition() throws Throwable {
    // Spec: this.left == this.right
    // Spec: this.left == this.right
            // Use reflection to access private fields
            java.lang.reflect.Field leftField = examples.DoublyLinkedListNode.class.getDeclaredField("left");
            leftField.setAccessible(true);
            java.lang.reflect.Field rightField = examples.DoublyLinkedListNode.class.getDeclaredField("right");
            rightField.setAccessible(true);

            // Create initial node A
            examples.DoublyLinkedListNode A = new examples.DoublyLinkedListNode();

            // Create two singleton nodes B and C
            examples.DoublyLinkedListNode B = new examples.DoublyLinkedListNode();
            examples.DoublyLinkedListNode C = new examples.DoublyLinkedListNode();

            // Precondition check: Both B and C are singletons before insertion
            examples.DoublyLinkedListNode B_left = (examples.DoublyLinkedListNode) leftField.get(B);
            examples.DoublyLinkedListNode B_right = (examples.DoublyLinkedListNode) rightField.get(B);

            examples.DoublyLinkedListNode C_left = (examples.DoublyLinkedListNode) leftField.get(C);
            examples.DoublyLinkedListNode C_right = (examples.DoublyLinkedListNode) rightField.get(C);

            // First insertion: B to the right of A
            A.insertRight(B);

            // Second insertion: C to the right of A (inserts between A and B)
            A.insertRight(C);

            // Postcondition check: A.left should equal A.right? 
            // Current state: 
            //   A.left remains unchanged from its state after the first insertion (i.e., B), 
            //   A.right is set to C after the second insertion, 
            examples.DoublyLinkedListNode A_left = (examples.DoublyLinkedListNode) leftField.get(A);
            examples.DoublyLinkedListNode A_right = (examples.DoublyLinkedListNode) rightField.get(A);
        }

        @Test
        public void testInsertRightPostcondition() throws Throwable {
    // Spec: this.left == this.right
    // Spec: this.left == this.right
            // Use reflection to access private fields
            java.lang.reflect.Field leftField = examples.DoublyLinkedListNode.class.getDeclaredField("left");
            leftField.setAccessible(true);
            java.lang.reflect.Field rightField = examples.DoublyLinkedListNode.class.getDeclaredField("right");
            rightField.setAccessible(true);

            // Create initial node A
            examples.DoublyLinkedListNode A = new examples.DoublyLinkedListNode();

            // Create two singleton nodes B and C
            examples.DoublyLinkedListNode B = new examples.DoublyLinkedListNode();
            examples.DoublyLinkedListNode C = new examples.DoublyLinkedListNode();

            // Precondition check: Both B and C are singletons before insertion
            examples.DoublyLinkedListNode B_left = (examples.DoublyLinkedListNode) leftField.get(B);
            examples.DoublyLinkedListNode B_right = (examples.DoublyLinkedListNode) rightField.get(B);
            // assertion removed: B_left == B && B_right == B;

            examples.DoublyLinkedListNode C_left = (examples.DoublyLinkedListNode) leftField.get(C);
            examples.DoublyLinkedListNode C_right = (examples.DoublyLinkedListNode) rightField.get(C);
            // assertion removed: C_left == C && C_right == C;

            // First insertion: B to the right of A
            A.insertRight(B);

            // Second insertion: C to the right of A (inserts between A and B)
            A.insertRight(C);

            // Postcondition check: A.left should equal A.right? 
            // Current state: 
            //   A.left remains unchanged from its state after the first insertion (i.e., B), 
            //   A.right is set to C after the second insertion, 
            examples.DoublyLinkedListNode A_left = (examples.DoublyLinkedListNode) leftField.get(A);
            examples.DoublyLinkedListNode A_right = (examples.DoublyLinkedListNode) rightField.get(A);
            // assertion removed: A_left == A_right;
        }

   @Test
   public void testClamp_1() throws Throwable {
    // Spec: this.right == n.right.left
    // Spec: this.right == n.right.left
        // Create two nodes
        examples.DoublyLinkedListNode nodeA = new examples.DoublyLinkedListNode();
        examples.DoublyLinkedListNode nodeB = new examples.DoublyLinkedListNode();

        // Insert nodeB to the right of nodeA
        nodeA.insertRight(nodeB);

        // Use reflection to access private fields
        Field leftField = examples.DoublyLinkedListNode.class.getDeclaredField("left");
        Field rightField = examples.DoublyLinkedListNode.class.getDeclaredField("right");
        leftField.setAccessible(true);
        rightField.setAccessible(true);

        // Check nodeA's right is nodeB
        examples.DoublyLinkedListNode nodeARight = (DoublyLinkedListNode) rightField.get(nodeA);

        // Check nodeB's left is nodeA
        examples.DoublyLinkedListNode nodeBLeft = (DoublyLinkedListNode) leftField.get(nodeB);

        // Check nodeB's right is nodeA (the old right of nodeA, which was nodeA)
        examples.DoublyLinkedListNode nodeBRight = (DoublyLinkedListNode) rightField.get(nodeB);

        // Check nodeA's left is nodeB
        examples.DoublyLinkedListNode nodeALeft = (DoublyLinkedListNode) leftField.get(nodeA);
   }

   @Test
   public void testClamp_1() throws Throwable {
    // Spec: this.right == n.right.left
    // Spec: this.right == n.right.left
        // Create two nodes
        examples.DoublyLinkedListNode nodeA = new examples.DoublyLinkedListNode();
        examples.DoublyLinkedListNode nodeB = new examples.DoublyLinkedListNode();

        // Insert nodeB to the right of nodeA
        nodeA.insertRight(nodeB);

        // Use reflection to access private fields
        Field leftField = examples.DoublyLinkedListNode.class.getDeclaredField("left");
        Field rightField = examples.DoublyLinkedListNode.class.getDeclaredField("right");
        leftField.setAccessible(true);
        rightField.setAccessible(true);

        // Check nodeA's right is nodeB
        examples.DoublyLinkedListNode nodeARight = (DoublyLinkedListNode) rightField.get(nodeA);
        // assertion removed: nodeARight;

        // Check nodeB's left is nodeA
        examples.DoublyLinkedListNode nodeBLeft = (DoublyLinkedListNode) leftField.get(nodeB);
        // assertion removed: nodeBLeft;

        // Check nodeB's right is nodeA (the old right of nodeA, which was nodeA)
        examples.DoublyLinkedListNode nodeBRight = (DoublyLinkedListNode) rightField.get(nodeB);
        // assertion removed: nodeBRight;

        // Check nodeA's left is nodeB
        examples.DoublyLinkedListNode nodeALeft = (DoublyLinkedListNode) leftField.get(nodeA);
        // assertion removed: nodeALeft;
   }

        @Test
        public void testInsertRight_1() throws Throwable {
    // Spec: this.left.right.right == this.right
    // Spec: this.left.right.right == this.right
          try {
            examples.DoublyLinkedListNode thisNode = new examples.DoublyLinkedListNode();
            examples.DoublyLinkedListNode A = new examples.DoublyLinkedListNode();
            examples.DoublyLinkedListNode R = new examples.DoublyLinkedListNode();
            examples.DoublyLinkedListNode n = new examples.DoublyLinkedListNode(); // must be a distinct node

            // Break the encapsulation: set thisNode's left and right using reflection.
            java.lang.reflect.Field leftField = examples.DoublyLinkedListNode.class.getDeclaredField("left");
            leftField.setAccessible(true);
            leftField.set(thisNode, A);

            java.lang.reflect.Field rightField = examples.DoublyLinkedListNode.class.getDeclaredField("right");
            rightField.setAccessible(true);
            rightField.set(thisNode, R);

            // Now call the method
            thisNode.insertRight(n);

            // Check the postcondition:

            // Check thisNode.left remains A
            examples.DoublyLinkedListNode actualLeftOfThis = (examples.DoublyLinkedListNode) leftField.get(thisNode);

            // Check thisNode.right should be n
            examples.DoublyLinkedListNode actualRightOfThis = (examples.DoublyLinkedListNode) rightField.get(thisNode);

            // Check n.left should be thisNode
            examples.DoublyLinkedListNode leftOfN = (examples.DoublyLinkedListNode) leftField.get(n);

            // Check n.right should be R
            examples.DoublyLinkedListNode rightOfN = (examples.DoublyLinkedListNode) rightField.get(n);

            // Check R.left should be n
            examples.DoublyLinkedListNode leftOfR = (examples.DoublyLinkedListNode) leftField.get(R);

            // Check R.right should be R (no change)
            examples.DoublyLinkedListNode rightOfR = (examples.DoublyLinkedListNode) rightField.get(R);

            // Also check A? The method does not change A, so:
            // A.left should be A and A.right should be A? 
            // But note: we set thisNode.left to A, but we never set A's right to thisNode? So that is broken? 
            // But the method does not require anything from A? And doesn't modify A? So A should remain as singleton?
            examples.DoublyLinkedListNode leftOfA = (examples.DoublyLinkedListNode) leftField.get(A);
            examples.DoublyLinkedListNode rightOfA = (examples.DoublyLinkedListNode) rightField.get(A);

          } catch (Exception e) {
          }
        }

        @Test
        public void testInsertRight_1() throws Throwable {
    // Spec: this.left.right.right == this.right
    // Spec: this.left.right.right == this.right
          try {
            examples.DoublyLinkedListNode thisNode = new examples.DoublyLinkedListNode();
            examples.DoublyLinkedListNode A = new examples.DoublyLinkedListNode();
            examples.DoublyLinkedListNode R = new examples.DoublyLinkedListNode();
            examples.DoublyLinkedListNode n = new examples.DoublyLinkedListNode(); // must be a distinct node

            // Break the encapsulation: set thisNode's left and right using reflection.
            java.lang.reflect.Field leftField = examples.DoublyLinkedListNode.class.getDeclaredField("left");
            leftField.setAccessible(true);
            leftField.set(thisNode, A);

            java.lang.reflect.Field rightField = examples.DoublyLinkedListNode.class.getDeclaredField("right");
            rightField.setAccessible(true);
            rightField.set(thisNode, R);

            // Now call the method
            thisNode.insertRight(n);

            // Check the postcondition:

            // Check thisNode.left remains A
            examples.DoublyLinkedListNode actualLeftOfThis = (examples.DoublyLinkedListNode) leftField.get(thisNode);
            // assertion removed: A, actualLeftOfThis;

            // Check thisNode.right should be n
            examples.DoublyLinkedListNode actualRightOfThis = (examples.DoublyLinkedListNode) rightField.get(thisNode);
            // assertion removed: n, actualRightOfThis;

            // Check n.left should be thisNode
            examples.DoublyLinkedListNode leftOfN = (examples.DoublyLinkedListNode) leftField.get(n);
            // assertion removed: thisNode, leftOfN;

            // Check n.right should be R
            examples.DoublyLinkedListNode rightOfN = (examples.DoublyLinkedListNode) rightField.get(n);
            // assertion removed: R, rightOfN;

            // Check R.left should be n
            examples.DoublyLinkedListNode leftOfR = (examples.DoublyLinkedListNode) leftField.get(R);
            // assertion removed: n, leftOfR;

            // Check R.right should be R (no change)
            examples.DoublyLinkedListNode rightOfR = (examples.DoublyLinkedListNode) rightField.get(R);
            // assertion removed: R, rightOfR;

            // Also check A? The method does not change A, so:
            // A.left should be A and A.right should be A? 
            // But note: we set thisNode.left to A, but we never set A's right to thisNode? So that is broken? 
            // But the method does not require anything from A? And doesn't modify A? So A should remain as singleton?
            examples.DoublyLinkedListNode leftOfA = (examples.DoublyLinkedListNode) leftField.get(A);
            examples.DoublyLinkedListNode rightOfA = (examples.DoublyLinkedListNode) rightField.get(A);
            // assertion removed: A, leftOfA;
            // assertion removed: A, rightOfA;

          } catch (Exception e) {
          }
        }

        @Test
        public void testInsertRight() throws Throwable {
    // Spec: this.left.right.right == this.right
    // Spec: this.left.right.right == this.right
            examples.DoublyLinkedListNode node1 = new examples.DoublyLinkedListNode();
            examples.DoublyLinkedListNode node2 = new examples.DoublyLinkedListNode();

            // node1 and node2 are singletons
            node1.insertRight(node2);

            // Check node1's right is node2
            java.lang.reflect.Field rightField = examples.DoublyLinkedListNode.class.getDeclaredField("right");
            rightField.setAccessible(true);

            // Check node2's left is node1
            java.lang.reflect.Field leftField = examples.DoublyLinkedListNode.class.getDeclaredField("left");
            leftField.setAccessible(true);

            // Check node2's right is node1's original right, which was node1

            // Check node1's left is node2
        }

        @Test
        public void testInsertRight() throws Throwable {
    // Spec: this.left.right.right == this.right
    // Spec: this.left.right.right == this.right
            examples.DoublyLinkedListNode node1 = new examples.DoublyLinkedListNode();
            examples.DoublyLinkedListNode node2 = new examples.DoublyLinkedListNode();

            // node1 and node2 are singletons
            node1.insertRight(node2);

            // Check node1's right is node2
            java.lang.reflect.Field rightField = examples.DoublyLinkedListNode.class.getDeclaredField("right");
            rightField.setAccessible(true);
            rightField.get(node1);

            // Check node2's left is node1
            java.lang.reflect.Field leftField = examples.DoublyLinkedListNode.class.getDeclaredField("left");
            leftField.setAccessible(true);
            leftField.get(node2);

            // Check node2's right is node1's original right, which was node1
            rightField.get(node2);

            // Check node1's left is node2
            leftField.get(node1);
        }

      @Test
      public void testInsertRight_1() throws Throwable {
    // Spec: this.left.right.right == this.right
    // Spec: this.left.right.right == this.right
          try {
            examples.DoublyLinkedListNode thisNode = new examples.DoublyLinkedListNode();
            examples.DoublyLinkedListNode A = new examples.DoublyLinkedListNode();
            examples.DoublyLinkedListNode R = new examples.DoublyLinkedListNode();
            examples.DoublyLinkedListNode n = new examples.DoublyLinkedListNode(); 

            // Use fully qualified name for Field
            java.lang.reflect.Field leftField = examples.DoublyLinkedListNode.class.getDeclaredField("left");
            leftField.setAccessible(true);
            leftField.set(thisNode, A);

            java.lang.reflect.Field rightField = examples.DoublyLinkedListNode.class.getDeclaredField("right");
            rightField.setAccessible(true);
            rightField.set(thisNode, R);

            thisNode.insertRight(n);

            // Now use reflection to get the values for the assertion

            // Get thisNode.left (A)
            examples.DoublyLinkedListNode leftNode = (examples.DoublyLinkedListNode) leftField.get(thisNode);
            // From leftNode (A), get its right
            examples.DoublyLinkedListNode leftNode_right = (examples.DoublyLinkedListNode) rightField.get(leftNode);
            // From leftNode_right, get its right
            examples.DoublyLinkedListNode leftNode_right_right = (examples.DoublyLinkedListNode) rightField.get(leftNode_right);
            // Get thisNode.right
            examples.DoublyLinkedListNode thisNode_right = (examples.DoublyLinkedListNode) rightField.get(thisNode);

            // Assert: leftNode_right_right (which is A.right.right = A) equal to thisNode_right (n) -> but note: they are different objects
          } catch (Exception e) {
          }
      }

      @Test
      public void testInsertRight_1() throws Throwable {
    // Spec: this.left.right.right == this.right
    // Spec: this.left.right.right == this.right
          try {
            examples.DoublyLinkedListNode thisNode = new examples.DoublyLinkedListNode();
            examples.DoublyLinkedListNode A = new examples.DoublyLinkedListNode();
            examples.DoublyLinkedListNode R = new examples.DoublyLinkedListNode();
            examples.DoublyLinkedListNode n = new examples.DoublyLinkedListNode(); 

            // Use fully qualified name for Field
            java.lang.reflect.Field leftField = examples.DoublyLinkedListNode.class.getDeclaredField("left");
            leftField.setAccessible(true);
            leftField.set(thisNode, A);

            java.lang.reflect.Field rightField = examples.DoublyLinkedListNode.class.getDeclaredField("right");
            rightField.setAccessible(true);
            rightField.set(thisNode, R);

            thisNode.insertRight(n);

            // Now use reflection to get the values for the assertion

            // Get thisNode.left (A)
            examples.DoublyLinkedListNode leftNode = (examples.DoublyLinkedListNode) leftField.get(thisNode);
            // From leftNode (A), get its right
            examples.DoublyLinkedListNode leftNode_right = (examples.DoublyLinkedListNode) rightField.get(leftNode);
            // From leftNode_right, get its right
            examples.DoublyLinkedListNode leftNode_right_right = (examples.DoublyLinkedListNode) rightField.get(leftNode_right);
            // Get thisNode.right
            examples.DoublyLinkedListNode thisNode_right = (examples.DoublyLinkedListNode) rightField.get(thisNode);

            // Assert: leftNode_right_right (which is A.right.right = A) equal to thisNode_right (n) -> but note: they are different objects
            // assertion removed: leftNode_right_right == thisNode_right;
          } catch (Exception e) {
          }
      }