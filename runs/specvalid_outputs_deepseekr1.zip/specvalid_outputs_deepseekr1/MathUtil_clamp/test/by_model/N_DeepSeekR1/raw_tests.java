   @Test
   public void testClamp() throws Throwable {
    // Spec: this != null
    // Spec: this != null
        int result = jts.MathUtil.clamp(5, 1, 10);
        assertEquals(5, result);
   }

   @Test
   public void testClamp() throws Throwable {
    // Spec: this != null
    // Spec: this != null
        int result = jts.MathUtil.clamp(5, 1, 10);
        // assertion removed: result;
   }

    @Test
    public void testClamp() throws Throwable {
    // Spec: this != null
    // Spec: this != null
        // Test when value is below min
        assertEquals(5, jts.MathUtil.clamp(3, 5, 10));
        // Test when value is above max
        assertEquals(10, jts.MathUtil.clamp(15, 5, 10));
        // Test when value is within the range
        assertEquals(7, jts.MathUtil.clamp(7, 5, 10));
        // Edge case: value equals min
        assertEquals(5, jts.MathUtil.clamp(5, 5, 10));
        // Edge case: value equals max
        assertEquals(10, jts.MathUtil.clamp(10, 5, 10));
    }

    @Test
    public void testClamp() throws Throwable {
    // Spec: this != null
    // Spec: this != null
        // Test when value is below min
        jts.MathUtil.clamp(3, 5, 10);
        // Test when value is above max
        jts.MathUtil.clamp(15, 5, 10);
        // Test when value is within the range
        jts.MathUtil.clamp(7, 5, 10);
        // Edge case: value equals min
        jts.MathUtil.clamp(5, 5, 10);
        // Edge case: value equals max
        jts.MathUtil.clamp(10, 5, 10);
    }