    @Test
    public void testCopySignInt() throws Throwable {
    // Spec: this != null
    // Spec: this != null
       ... call the static method ...
    }

    @Test
    public void testCopySignInt() throws Throwable {
    // Spec: this != null
    // Spec: this != null
       ... call the static method ...
       // assertion removed: this != null;
    }